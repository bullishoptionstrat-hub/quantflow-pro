import type { Config } from "tailwindcss";

/**
 * QuantFlow design tokens — "tape room, not dashboard template".
 * Ink-black base with a phosphor-amber signature (old quote terminals),
 * teal for bullish, signal-red for bearish. No purple gradients.
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { 950: "#08090C", 900: "#0C0E13", 850: "#10131A", 800: "#161A23", 700: "#212737", 600: "#2E3650" },
        line: "#1C2230",
        muted: "#6B7489",
        bright: "#E6EAF2",
        bull: { DEFAULT: "#2DD4A7", dim: "#103D33" },
        bear: { DEFAULT: "#F0524C", dim: "#3D1513" },
        amber: { DEFAULT: "#F5B73D", dim: "#3D2F10" },
      },
      fontFamily: {
        display: ["'Archivo'", "system-ui", "sans-serif"],
        mono: ["'IBM Plex Mono'", "ui-monospace", "monospace"],
      },
      keyframes: {
        goldpulse: {
          "0%, 100%": { boxShadow: "inset 3px 0 0 0 #F5B73D" },
          "50%": { boxShadow: "inset 3px 0 0 0 #F5B73D, 0 0 14px 0 rgba(245,183,61,0.25)" },
        },
        rowin: {
          from: { opacity: "0", transform: "translateY(-4px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        goldpulse: "goldpulse 1.6s ease-in-out infinite",
        rowin: "rowin 240ms ease-out",
      },
    },
  },
  plugins: [],
};
export default config;
