"use client";

import { useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import {
  WS_EVENTS,
  passesFilters,
  type FlowEvent,
  type PowerAlert,
  type FeedStatus,
} from "@quantflow/shared";
import { useFilters } from "@/stores/filters";
import { fmtPremium } from "@/lib/format";

const MAX_ROWS = 500;

let socket: Socket | null = null;
function getSocket(): Socket | null {
  const url = process.env.NEXT_PUBLIC_WS_URL;
  if (!url) return null;
  if (!socket) socket = io(url, { transports: ["websocket", "polling"] });
  return socket;
}

function speak(text: string): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1.1;
  window.speechSynthesis.speak(u);
}

export function useFlowFeed() {
  const [events, setEvents] = useState<FlowEvent[]>([]);
  const [powerAlerts, setPowerAlerts] = useState<PowerAlert[]>([]);
  const [feedStatus, setFeedStatus] = useState<FeedStatus | null>(null);
  const filters = useFilters();
  const filtersRef = useRef(filters);
  filtersRef.current = filters;

  // initial backfill from history API so the feed isn't empty on load
  useEffect(() => {
    fetch("/api/flow/history?limit=100")
      .then((r) => (r.ok ? r.json() : { events: [] }))
      .then((d: { events: FlowEvent[] }) => setEvents(d.events ?? []))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const s = getSocket();
    if (!s) return;

    const onFlow = (event: FlowEvent) => {
      const f = filtersRef.current;
      setEvents((prev) => [event, ...prev].slice(0, MAX_ROWS));
      if (f.voiceAlerts && event.is_unusual && event.order_type === "SWEEP" && passesFilters(event, f)) {
        speak(
          `Unusual ${event.sentiment.toLowerCase()} sweep. ${event.underlying} ` +
            `${event.strike} ${event.option_type}. ${fmtPremium(event.total_premium)} premium.`
        );
      }
    };

    const onPower = (alert: PowerAlert) => {
      setPowerAlerts((prev) => [alert, ...prev].slice(0, 50));
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        new Notification(`Power alert — ${alert.underlying}`, {
          body: `Score ${(alert.score * 100).toFixed(0)}% (${alert.scoring_mode})`,
        });
      }
      if (filtersRef.current.voiceAlerts) {
        speak(`Power alert on ${alert.underlying}. Score ${(alert.score * 100).toFixed(0)} percent.`);
      }
    };

    const onStatus = (st: FeedStatus) => setFeedStatus(st);

    s.on(WS_EVENTS.FLOW_UPDATE, onFlow);
    s.on(WS_EVENTS.POWER_ALERT, onPower);
    s.on(WS_EVENTS.FEED_STATUS, onStatus);
    return () => {
      s.off(WS_EVENTS.FLOW_UPDATE, onFlow);
      s.off(WS_EVENTS.POWER_ALERT, onPower);
      s.off(WS_EVENTS.FEED_STATUS, onStatus);
    };
  }, []);

  const filtered = events.filter((e) => passesFilters(e, filters));
  return { events: filtered, allEvents: events, powerAlerts, feedStatus };
}
