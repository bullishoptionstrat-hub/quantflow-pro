"use client";
import { create } from "zustand";
import type { FlowFilters, OrderType, Sentiment } from "@quantflow/shared";

interface FilterState extends FlowFilters {
  voiceAlerts: boolean;
  setMinPremium: (v: number) => void;
  toggleOrderType: (t: OrderType) => void;
  toggleSentiment: (s: Sentiment) => void;
  toggleUnusualOnly: () => void;
  setUnderlyings: (u: string[]) => void;
  toggleVoiceAlerts: () => void;
}

export const useFilters = create<FilterState>((set) => ({
  minPremium: 25_000,
  orderTypes: [],
  sentiments: [],
  unusualOnly: false,
  underlyings: [],
  voiceAlerts: false,
  setMinPremium: (minPremium) => set({ minPremium }),
  toggleOrderType: (t) =>
    set((s) => ({
      orderTypes: s.orderTypes.includes(t) ? s.orderTypes.filter((x) => x !== t) : [...s.orderTypes, t],
    })),
  toggleSentiment: (sen) =>
    set((s) => ({
      sentiments: s.sentiments.includes(sen) ? s.sentiments.filter((x) => x !== sen) : [...s.sentiments, sen],
    })),
  toggleUnusualOnly: () => set((s) => ({ unusualOnly: !s.unusualOnly })),
  setUnderlyings: (underlyings) => set({ underlyings }),
  toggleVoiceAlerts: () => set((s) => ({ voiceAlerts: !s.voiceAlerts })),
}));
