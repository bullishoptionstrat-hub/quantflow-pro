"use client";
import { useEffect, useState } from "react";
import type { FlowEvent } from "@quantflow/shared";
import { useFilters } from "@/stores/filters";
import { fmtPremium } from "@/lib/format";

interface SymbolPulse {
  underlying: string;
  net: number;
  total: number;
  lastPrice: number | null;
}

export function Watchlist({
  allEvents,
  onSelectSymbol,
  selected,
}: {
  allEvents: FlowEvent[];
  onSelectSymbol: (u: string) => void;
  selected: string | null;
}) {
  const { underlyings, setUnderlyings } = useFilters();
  const [pulses, setPulses] = useState<SymbolPulse[]>([]);

  useEffect(() => {
    const map = new Map<string, SymbolPulse>();
    for (const e of allEvents) {
      const cur = map.get(e.underlying) ?? { underlying: e.underlying, net: 0, total: 0, lastPrice: null };
      cur.total += e.total_premium;
      if (e.sentiment === "BULLISH") cur.net += e.total_premium;
      if (e.sentiment === "BEARISH") cur.net -= e.total_premium;
      if (cur.lastPrice === null && e.underlying_price) cur.lastPrice = e.underlying_price;
      map.set(e.underlying, cur);
    }
    setPulses([...map.values()].sort((a, b) => b.total - a.total).slice(0, 15));
  }, [allEvents]);

  return (
    <div className="panel p-3">
      <div className="eyebrow mb-2">Session flow by symbol</div>
      <div className="space-y-0.5">
        {pulses.length === 0 && <div className="py-4 text-center text-[11px] text-muted">Waiting for flow…</div>}
        {pulses.map((p) => {
          const isFiltered = underlyings.includes(p.underlying);
          return (
            <button
              key={p.underlying}
              onClick={() => onSelectSymbol(p.underlying)}
              onDoubleClick={() => setUnderlyings(isFiltered ? [] : [p.underlying])}
              className={`flex w-full items-center justify-between rounded px-2 py-1 text-left hover:bg-ink-850 ${
                selected === p.underlying ? "bg-ink-800" : ""
              } ${isFiltered ? "ring-1 ring-amber/50" : ""}`}
              title="Click: detail panel. Double-click: filter feed to this symbol."
            >
              <span className="font-semibold">{p.underlying}</span>
              <span className="flex items-center gap-3 text-[11px]">
                {p.lastPrice && <span className="text-muted">{p.lastPrice.toFixed(2)}</span>}
                <span className={p.net > 0 ? "text-bull" : p.net < 0 ? "text-bear" : "text-muted"}>
                  {p.net >= 0 ? "+" : "−"}{fmtPremium(Math.abs(p.net))}
                </span>
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
