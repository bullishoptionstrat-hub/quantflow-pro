"use client";

import { useEffect, useState } from "react";
import type { FlowLevel, GexLevel, SymbolAnalytics } from "@quantflow/shared";
import { PriceChart, type Candle } from "./PriceChart";
import { fmtPremium } from "@/lib/format";

export function SymbolDetail({ underlying }: { underlying: string }) {
  const [analytics, setAnalytics] = useState<SymbolAnalytics | null>(null);
  const [candles, setCandles] = useState<Candle[]>([]);
  const [levels, setLevels] = useState<FlowLevel[]>([]);
  const [gex, setGex] = useState<GexLevel[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setError(null);
    setAnalytics(null);
    Promise.all([
      fetch(`/api/analytics/${underlying}`).then((r) => (r.ok ? r.json() : Promise.reject(r.status))),
      fetch(`/api/levels/${underlying}`).then((r) => (r.ok ? r.json() : { levels: [], candles: [] })),
      fetch(`/api/gex/${underlying}`).then((r) => (r.ok ? r.json() : { levels: [] })),
    ])
      .then(
        ([a, l, g]: [
          SymbolAnalytics,
          { levels: FlowLevel[]; candles: Candle[] },
          { levels: GexLevel[] },
        ]) => {
          setAnalytics(a);
          setLevels(l.levels ?? []);
          setCandles(l.candles ?? []);
          setGex(g.levels ?? []);
        }
      )
      .catch(() => setError("Couldn't load symbol data. Check API routes and Supabase env."));
  }, [underlying]);

  if (error) return <div className="panel p-3 text-[12px] text-bear">{error}</div>;
  if (!analytics) return <div className="panel p-3 text-[12px] text-muted">Loading {underlying}…</div>;

  const ratio = analytics.bull_bear_ratio;
  const gaugePct = Math.max(0, Math.min(100, (ratio / (ratio + 1)) * 100));

  return (
    <div className="panel space-y-4 p-3">
      <div className="flex items-baseline justify-between">
        <span className="font-display text-base font-bold">{underlying}</span>
        <span className="text-[11px] text-muted">{analytics.event_count} events today</span>
      </div>

      {gex.length > 0 && (() => {
        const total = gex.reduce((s, g) => s + g.net_gex, 0);
        const flip = gex.find((g) => g.level_type === "flip");
        const neg = total < 0;
        return (
          <div className="flex items-center justify-between rounded bg-ink-900 px-2 py-1.5 text-[11px]">
            <span>
              Γ regime{" "}
              <span className={`font-display font-bold ${neg ? "text-bear" : "text-bull"}`}>
                {neg ? "NEGATIVE" : "POSITIVE"}
              </span>
              <span className="ml-1 text-muted">{neg ? "(moves amplify)" : "(moves dampen)"}</span>
            </span>
            <span className="text-muted">
              flip <span className="font-display font-bold text-amber">{flip?.strike ?? "—"}</span>
            </span>
          </div>
        );
      })()}

      {candles.length > 0 ? (
        <PriceChart candles={candles} levels={levels} height={220} />
      ) : (
        <div className="flex h-[220px] items-center justify-center text-[11px] text-muted">
          No price history available (Tradier history endpoint not reachable from web env).
        </div>
      )}

      <div>
        <div className="eyebrow mb-1.5">Flow score</div>
        <div className="h-2 w-full overflow-hidden rounded bg-bear-dim">
          <div className="h-full bg-bull transition-all" style={{ width: `${gaugePct}%` }} />
        </div>
        <div className="mt-1 flex justify-between text-[11px]">
          <span className="text-bull">{fmtPremium(analytics.bull_premium)} bull</span>
          <span className="text-muted">{ratio.toFixed(2)} : 1</span>
          <span className="text-bear">{fmtPremium(analytics.bear_premium)} bear</span>
        </div>
      </div>

      <div>
        <div className="eyebrow mb-1.5">Top strikes by premium</div>
        <div className="space-y-1">
          {analytics.top_strikes.length === 0 && (
            <div className="text-[11px] text-muted">No directional flow yet.</div>
          )}
          {analytics.top_strikes.map((s, i) => {
            const max = analytics.top_strikes[0]?.premium ?? 1;
            return (
              <div key={`${s.strike}-${s.option_type}-${i}`} className="flex items-center gap-2 text-[11px]">
                <span className="w-14">{s.strike}{s.option_type === "call" ? "C" : "P"}</span>
                <div className="h-3 flex-1 overflow-hidden rounded-sm bg-ink-800">
                  <div
                    className={`h-full ${s.option_type === "call" ? "bg-bull/70" : "bg-bear/70"}`}
                    style={{ width: `${(s.premium / max) * 100}%` }}
                  />
                </div>
                <span className="w-16 text-right text-muted">{fmtPremium(s.premium)}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex justify-between border-t border-line pt-2 text-[11px]">
        <span className="text-muted">Net flow</span>
        <span className={analytics.net_flow >= 0 ? "text-bull" : "text-bear"}>
          {analytics.net_flow >= 0 ? "+" : "−"}{fmtPremium(Math.abs(analytics.net_flow))}
        </span>
      </div>
      <div className="flex justify-between text-[11px]">
        <span className="text-muted">Unusual prints</span>
        <span className="text-amber">{analytics.unusual_count}</span>
      </div>
    </div>
  );
}
