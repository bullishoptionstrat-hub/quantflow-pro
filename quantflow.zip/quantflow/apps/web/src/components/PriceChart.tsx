"use client";

import { useEffect, useRef } from "react";
import { createChart, ColorType, type IChartApi, LineStyle } from "lightweight-charts";
import type { FlowLevel } from "@quantflow/shared";

export interface Candle {
  time: string; // yyyy-mm-dd
  open: number;
  high: number;
  low: number;
  close: number;
}

const LEVEL_COLORS: Record<FlowLevel["level_type"], string> = {
  support: "#2DD4A7",
  resistance: "#F0524C",
  accumulation: "#F5B73D",
};

export function PriceChart({
  candles,
  levels = [],
  height = 280,
}: {
  candles: Candle[];
  levels?: FlowLevel[];
  height?: number;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const chart = createChart(el, {
      height,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#6B7489",
        fontFamily: "'IBM Plex Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "#161A23" },
        horzLines: { color: "#161A23" },
      },
      rightPriceScale: { borderColor: "#1C2230" },
      timeScale: { borderColor: "#1C2230" },
      crosshair: { mode: 0 },
    });
    chartRef.current = chart;

    const series = chart.addCandlestickSeries({
      upColor: "#2DD4A7",
      downColor: "#F0524C",
      borderUpColor: "#2DD4A7",
      borderDownColor: "#F0524C",
      wickUpColor: "#2DD4A7",
      wickDownColor: "#F0524C",
    });
    series.setData(candles);

    for (const lvl of levels) {
      series.createPriceLine({
        price: lvl.price_level,
        color: LEVEL_COLORS[lvl.level_type],
        lineWidth: 1,
        lineStyle: lvl.level_type === "accumulation" ? LineStyle.Solid : LineStyle.Dashed,
        axisLabelVisible: true,
        title: lvl.level_type.slice(0, 3).toUpperCase(),
      });
    }

    chart.timeScale().fitContent();

    const onResize = () => chart.applyOptions({ width: el.clientWidth });
    onResize();
    const ro = new ResizeObserver(onResize);
    ro.observe(el);

    return () => {
      ro.disconnect();
      chart.remove();
      chartRef.current = null;
    };
  }, [candles, levels, height]);

  return <div ref={containerRef} className="w-full" />;
}
