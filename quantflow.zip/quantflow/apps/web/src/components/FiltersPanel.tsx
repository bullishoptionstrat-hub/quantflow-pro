"use client";
import { useFilters } from "@/stores/filters";
import type { OrderType, Sentiment } from "@quantflow/shared";

const ORDER_TYPES: OrderType[] = ["SWEEP", "BLOCK", "SPLIT"];
const SENTIMENTS: Sentiment[] = ["BULLISH", "BEARISH", "NEUTRAL"];
const PREMIUM_STEPS = [0, 25_000, 100_000, 250_000, 500_000, 1_000_000];

export function FiltersPanel() {
  const f = useFilters();
  return (
    <div className="panel space-y-4 p-3">
      <div>
        <div className="eyebrow mb-1.5">Min premium</div>
        <div className="flex flex-wrap gap-1">
          {PREMIUM_STEPS.map((p) => (
            <button
              key={p}
              onClick={() => f.setMinPremium(p)}
              className={`rounded px-2 py-1 text-[11px] ${
                f.minPremium === p ? "bg-amber-dim font-bold text-amber" : "bg-ink-800 text-muted hover:text-bright"
              }`}
            >
              {p === 0 ? "All" : p >= 1_000_000 ? "$1M+" : `$${p / 1000}K+`}
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="eyebrow mb-1.5">Order type</div>
        <div className="flex gap-1">
          {ORDER_TYPES.map((t) => (
            <Toggle key={t} active={f.orderTypes.includes(t)} onClick={() => f.toggleOrderType(t)} label={t} />
          ))}
        </div>
      </div>
      <div>
        <div className="eyebrow mb-1.5">Sentiment</div>
        <div className="flex gap-1">
          {SENTIMENTS.map((s) => (
            <Toggle key={s} active={f.sentiments.includes(s)} onClick={() => f.toggleSentiment(s)} label={s.slice(0, 4)} />
          ))}
        </div>
      </div>
      <div className="space-y-2">
        <label className="flex cursor-pointer items-center gap-2 text-[12px]">
          <input type="checkbox" checked={f.unusualOnly} onChange={f.toggleUnusualOnly} className="accent-amber" />
          Unusual only
        </label>
        <label className="flex cursor-pointer items-center gap-2 text-[12px]">
          <input type="checkbox" checked={f.voiceAlerts} onChange={f.toggleVoiceAlerts} className="accent-amber" />
          Voice alerts on unusual sweeps
        </label>
      </div>
    </div>
  );
}

function Toggle({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`rounded px-2 py-1 text-[11px] ${active ? "bg-ink-700 font-bold text-bright" : "bg-ink-800 text-muted hover:text-bright"}`}
    >
      {label}
    </button>
  );
}
