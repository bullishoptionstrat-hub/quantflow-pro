"use client";
import type { FeedStatus } from "@quantflow/shared";
import { FreshnessBadge } from "./FreshnessBadge";

export function FeedStatusBar({ status }: { status: FeedStatus | null }) {
  if (!status) {
    return (
      <div className="panel flex items-center gap-2 px-3 py-1.5 text-[11px] text-muted">
        <span className="inline-block h-1.5 w-1.5 rounded-full bg-muted" />
        Connecting to relay… If this persists, set NEXT_PUBLIC_WS_URL to the ingest service URL.
      </div>
    );
  }
  return (
    <div className="panel flex items-center gap-3 px-3 py-1.5 text-[11px]">
      <span className={`inline-block h-1.5 w-1.5 rounded-full ${status.connected ? "bg-bull" : "bg-bear"}`} />
      <span className="text-muted">{status.provider}</span>
      <FreshnessBadge freshness={status.freshness} />
      {status.freshness === "DEMO" && (
        <span className="font-bold text-bear">SYNTHETIC DATA — DEVELOPMENT ONLY</span>
      )}
      {status.freshness === "DELAYED" && (
        <span className="text-amber">Sandbox feed — quotes delayed, sweep attribution degraded</span>
      )}
      {status.last_event_at && (
        <span className="ml-auto text-muted">
          last event {new Date(status.last_event_at).toLocaleTimeString("en-US", { hour12: false })}
        </span>
      )}
    </div>
  );
}
