"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "Flow" },
  { href: "/screener", label: "Screener" },
  { href: "/darkpool", label: "ATS Volume" },
  { href: "/levels/SPY", label: "Levels" },
  { href: "/calculator", label: "Calculator" },
  { href: "/alerts", label: "Alerts" },
];

export function Nav() {
  const path = usePathname();
  return (
    <header className="sticky top-0 z-40 flex items-center gap-6 border-b border-line bg-ink-950/95 px-4 py-2.5 backdrop-blur">
      <Link href="/" className="font-display text-sm font-extrabold tracking-tight">
        QUANT<span className="text-amber">FLOW</span>
        <span className="ml-2 align-middle text-[9px] font-bold tracking-[0.2em] text-muted">TERMINAL</span>
      </Link>
      <nav className="flex gap-1">
        {LINKS.map((l) => {
          const active = l.href === "/" ? path === "/" : path.startsWith(l.href.split("/").slice(0, 2).join("/"));
          return (
            <Link
              key={l.href}
              href={l.href}
              className={`rounded px-3 py-1 font-display text-xs font-semibold tracking-wide transition-colors ${
                active ? "bg-ink-800 text-bright" : "text-muted hover:text-bright"
              }`}
            >
              {l.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
