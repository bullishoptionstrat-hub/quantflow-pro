"use client";

import { useState } from "react";
import type { FlowEvent } from "@quantflow/shared";
import { fmtExp, fmtNum, fmtPremium, fmtTime } from "@/lib/format";
import { FreshnessBadge } from "./FreshnessBadge";

const HEADERS = ["Time", "Sym", "Exp", "Strike", "C/P", "Type", "Size", "Premium", "Heat", "Sent", ""];

/** Heat as a colored number (gray → blue → orange → gold), never a bar. */
function heatClass(score: number): string {
  if (score >= 80) return "text-amber font-bold";
  if (score >= 60) return "text-[#f97316]";
  if (score >= 40) return "text-[#3b82f6]";
  return "text-muted";
}

function sentimentClass(e: FlowEvent): string {
  if (e.sentiment === "BULLISH") return "text-bull";
  if (e.sentiment === "BEARISH") return "text-bear";
  return "text-muted";
}

function rowGlow(e: FlowEvent): string {
  if (e.is_unusual) return "animate-goldpulse";
  if (e.sentiment === "BULLISH") return "shadow-[inset_3px_0_0_0_theme(colors.bull.DEFAULT)]";
  if (e.sentiment === "BEARISH") return "shadow-[inset_3px_0_0_0_theme(colors.bear.DEFAULT)]";
  return "";
}

export function FlowTable({
  events,
  onSelectSymbol,
}: {
  events: FlowEvent[];
  onSelectSymbol?: (underlying: string) => void;
}) {
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div className="panel overflow-hidden">
      <table className="w-full table-fixed text-left">
        <thead>
          <tr className="border-b border-line">
            {HEADERS.map((h, i) => (
              <th
                key={h || i}
                className={`eyebrow px-2 py-2 ${i === 0 ? "w-[72px]" : i === 6 || i === 7 || i === 8 ? "text-right" : ""} ${i === 10 ? "w-8" : ""}`}
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {events.length === 0 && (
            <tr>
              <td colSpan={11} className="px-3 py-10 text-center text-muted">
                No flow matching current filters. Loosen the premium floor or wait for the next print.
              </td>
            </tr>
          )}
          {events.map((e) => (
            <FlowRow
              key={e.id}
              event={e}
              expanded={expanded === e.id}
              onToggle={() => setExpanded(expanded === e.id ? null : e.id)}
              onSelectSymbol={onSelectSymbol}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FlowRow({
  event: e,
  expanded,
  onToggle,
  onSelectSymbol,
}: {
  event: FlowEvent;
  expanded: boolean;
  onToggle: () => void;
  onSelectSymbol?: (u: string) => void;
}) {
  return (
    <>
      <tr
        className={`animate-rowin cursor-pointer border-b border-line/50 transition-colors hover:bg-ink-850 ${rowGlow(e)}`}
        onClick={onToggle}
      >
        <td className="px-2 py-1.5 text-muted">{fmtTime(e.created_at)}</td>
        <td className="px-2 py-1.5">
          <button
            className="font-semibold hover:text-amber"
            onClick={(ev) => {
              ev.stopPropagation();
              onSelectSymbol?.(e.underlying);
            }}
          >
            {e.underlying}
          </button>
        </td>
        <td className="px-2 py-1.5 text-muted">{fmtExp(e.expiration)}</td>
        <td className="px-2 py-1.5">{e.strike}</td>
        <td className={`px-2 py-1.5 font-semibold ${e.option_type === "call" ? "text-bull" : "text-bear"}`}>
          {e.option_type === "call" ? "C" : "P"}
        </td>
        <td className="px-2 py-1.5">
          <span
            className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
              e.order_type === "SWEEP"
                ? "bg-amber-dim text-amber"
                : e.order_type === "BLOCK"
                  ? "bg-ink-700 text-bright"
                  : "bg-ink-800 text-muted"
            }`}
          >
            {e.order_type}
          </span>
        </td>
        <td className="px-2 py-1.5 text-right">{fmtNum(e.total_size)}</td>
        <td className="px-2 py-1.5 text-right font-semibold">{fmtPremium(e.total_premium)}</td>
        <td className={`px-2 py-1.5 text-right ${heatClass(e.heat_score)}`}>{e.heat_score}</td>
        <td className={`px-2 py-1.5 font-semibold ${sentimentClass(e)}`}>
          {e.sentiment === "NEUTRAL" ? "—" : e.sentiment.slice(0, 4)}
        </td>
        <td className="px-2 py-1.5 text-center text-muted">{expanded ? "▾" : "▸"}</td>
      </tr>
      {expanded && (
        <tr className="border-b border-line bg-ink-850">
          <td colSpan={11} className="px-4 py-3">
            <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-[12px] md:grid-cols-4">
              <Detail label="Contract" value={e.symbol} />
              <Detail label="Avg fill" value={`$${e.avg_price.toFixed(2)}`} />
              <Detail label="Venues" value={String(e.exchange_count)} />
              <Detail label="DTE" value={`${e.days_to_expiry}d`} />
              <Detail
                label="Underlying"
                value={e.underlying_price ? `$${e.underlying_price.toFixed(2)}` : "n/a"}
              />
              <Detail
                label="OTM"
                value={e.otm_percentage !== null ? `${e.otm_percentage.toFixed(1)}%` : "n/a"}
              />
              <Detail label="Unusual" value={e.is_unusual ? "YES — >3× 20d avg" : "no"} />
              <Detail label="Heat" value={`${e.heat_score}/100 fill aggression`} />
              <div className="flex items-center gap-2">
                <span className="eyebrow">Data</span>
                <FreshnessBadge freshness={e.freshness} />
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline gap-2">
      <span className="eyebrow">{label}</span>
      <span>{value}</span>
    </div>
  );
}
