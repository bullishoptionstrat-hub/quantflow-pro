import type { DataFreshness } from "@quantflow/shared";

/** Data provenance is always visible. DEMO and DELAYED are never hidden. */
export function FreshnessBadge({ freshness }: { freshness: DataFreshness }) {
  const styles: Record<DataFreshness, string> = {
    REALTIME: "bg-bull-dim text-bull",
    DELAYED: "bg-amber-dim text-amber",
    DEMO: "bg-bear-dim text-bear",
  };
  return (
    <span className={`rounded px-1.5 py-0.5 text-[9px] font-bold tracking-widest ${styles[freshness]}`}>
      {freshness}
    </span>
  );
}
