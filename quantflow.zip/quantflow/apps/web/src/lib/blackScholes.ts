/**
 * Black-Scholes-Merton — client-side, no API calls.
 *
 * NOTE on the reference implementation this replaces: the commonly circulated
 * "BlackScholesJS" snippet computes gamma, vega, and the first theta term with
 * the normal CDF N(d1). That is wrong — those greeks use the normal PDF φ(d1).
 * The CDF version overstates gamma/vega for ITM options by up to ~2× and makes
 * the Newton-Raphson IV solver converge to wrong vols. Corrected here.
 */

/** Standard normal PDF φ(x). */
export function normPDF(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/** Standard normal CDF N(x) — Abramowitz & Stegun 7.1.26, |ε| < 1.5e-7. */
export function normCDF(x: number): number {
  const a1 = 0.254829592,
    a2 = -0.284496736,
    a3 = 1.421413741,
    a4 = -1.453152027,
    a5 = 1.061405429,
    p = 0.3275911;
  const sign = x < 0 ? -1 : 1;
  const ax = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + p * ax);
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-ax * ax);
  return 0.5 * (1 + sign * y);
}

export interface BSInputs {
  S: number; // underlying price
  K: number; // strike
  T: number; // time to expiration in years
  r: number; // risk-free rate, decimal
  sigma: number; // implied vol, decimal
  q?: number; // dividend yield, decimal
}

export interface BSOutput {
  price: number;
  delta: number;
  gamma: number;
  theta: number; // per calendar day
  vega: number; // per 1 vol point (1%)
  rho: number; // per 1% rate move
}

export function blackScholes(type: "call" | "put", inputs: BSInputs): BSOutput {
  const { S, K, T, r, sigma, q = 0 } = inputs;

  // Expiration / degenerate handling: intrinsic value, zero greeks.
  if (T <= 0 || sigma <= 0 || S <= 0 || K <= 0) {
    const intrinsic = type === "call" ? Math.max(0, S - K) : Math.max(0, K - S);
    return { price: intrinsic, delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0 };
  }

  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;
  const pdfD1 = normPDF(d1);
  const eqT = Math.exp(-q * T);
  const erT = Math.exp(-r * T);

  const price =
    type === "call"
      ? S * eqT * normCDF(d1) - K * erT * normCDF(d2)
      : K * erT * normCDF(-d2) - S * eqT * normCDF(-d1);

  const delta = type === "call" ? eqT * normCDF(d1) : -eqT * normCDF(-d1);
  const gamma = (eqT * pdfD1) / (S * sigma * sqrtT); // PDF, not CDF
  const vega = (S * eqT * pdfD1 * sqrtT) / 100; // PDF, not CDF

  const thetaAnnual =
    type === "call"
      ? -(S * sigma * eqT * pdfD1) / (2 * sqrtT) - r * K * erT * normCDF(d2) + q * S * eqT * normCDF(d1)
      : -(S * sigma * eqT * pdfD1) / (2 * sqrtT) + r * K * erT * normCDF(-d2) - q * S * eqT * normCDF(-d1);
  const theta = thetaAnnual / 365;

  const rho =
    type === "call" ? (K * T * erT * normCDF(d2)) / 100 : -(K * T * erT * normCDF(-d2)) / 100;

  return { price, delta, gamma, theta, vega, rho };
}

/**
 * Newton-Raphson IV solver with bisection fallback.
 * Returns null when no vol reproduces the price (e.g. price below intrinsic) —
 * callers must handle null instead of trusting a garbage vol.
 */
export function impliedVolatility(
  type: "call" | "put",
  marketPrice: number,
  inputs: Omit<BSInputs, "sigma">
): number | null {
  if (marketPrice <= 0) return null;
  const intrinsic =
    type === "call" ? Math.max(0, inputs.S - inputs.K) : Math.max(0, inputs.K - inputs.S);
  if (marketPrice < intrinsic * Math.exp(-inputs.r * inputs.T) * 0.99) return null;

  let sigma = 0.3;
  for (let i = 0; i < 60; i++) {
    const { price, vega } = blackScholes(type, { ...inputs, sigma });
    const diff = marketPrice - price;
    if (Math.abs(diff) < 1e-5) return sigma;
    const vegaRaw = vega * 100; // back to per-1.0-vol units for the Newton step
    if (vegaRaw < 1e-8) break; // flat vega → Newton diverges; go bisect
    sigma += diff / vegaRaw;
    if (sigma <= 0.001 || sigma > 10 || !Number.isFinite(sigma)) break;
  }

  // Bisection fallback over [0.1%, 1000%]
  let lo = 0.001,
    hi = 10;
  const pLo = blackScholes(type, { ...inputs, sigma: lo }).price;
  const pHi = blackScholes(type, { ...inputs, sigma: hi }).price;
  if (marketPrice < pLo || marketPrice > pHi) return null;
  for (let i = 0; i < 80; i++) {
    const mid = (lo + hi) / 2;
    const p = blackScholes(type, { ...inputs, sigma: mid }).price;
    if (Math.abs(p - marketPrice) < 1e-5) return mid;
    if (p < marketPrice) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

// ============================================================
// Multi-leg strategy math
// ============================================================

export interface LegInput {
  option_type: "call" | "put";
  side: "long" | "short";
  strike: number;
  quantity: number;
  entry_price: number; // per share
  iv: number; // decimal
  T: number; // years to this leg's expiration as of the valuation date
}

/** P/L of a position at a given underlying price and time (model value − entry). */
export function strategyValue(legs: LegInput[], S: number, r: number): number {
  let value = 0;
  for (const leg of legs) {
    const sign = leg.side === "long" ? 1 : -1;
    const { price } = blackScholes(leg.option_type, {
      S,
      K: leg.strike,
      T: Math.max(0, leg.T),
      r,
      sigma: leg.iv,
    });
    value += sign * price * leg.quantity * 100;
  }
  return value;
}

export function strategyEntryCost(legs: LegInput[]): number {
  return legs.reduce(
    (s, l) => s + (l.side === "long" ? 1 : -1) * l.entry_price * l.quantity * 100,
    0
  );
}

export function strategyPnL(legs: LegInput[], S: number, r: number): number {
  return strategyValue(legs, S, r) - strategyEntryCost(legs);
}

/** Aggregate position greeks (per share × 100 × qty, signed). */
export function strategyGreeks(legs: LegInput[], S: number, r: number): BSOutput {
  const agg: BSOutput = { price: 0, delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0 };
  for (const leg of legs) {
    const sign = leg.side === "long" ? 1 : -1;
    const g = blackScholes(leg.option_type, {
      S,
      K: leg.strike,
      T: Math.max(0, leg.T),
      r,
      sigma: leg.iv,
    });
    const mult = sign * leg.quantity * 100;
    agg.price += g.price * mult;
    agg.delta += g.delta * mult;
    agg.gamma += g.gamma * mult;
    agg.theta += g.theta * mult;
    agg.vega += g.vega * mult;
    agg.rho += g.rho * mult;
  }
  return agg;
}

/**
 * Probability of profit at expiration under a lognormal terminal distribution
 * (risk-neutral drift, ATM-ish vol supplied by caller). Numerical integration
 * over a price grid. This is a MODEL estimate — it inherits every Black-Scholes
 * assumption (constant vol, no skew, lognormal terminal). Label it as such.
 */
export function probabilityOfProfit(
  legs: LegInput[],
  spot: number,
  r: number,
  sigma: number,
  Tyears: number
): number | null {
  if (spot <= 0 || sigma <= 0 || Tyears <= 0) return null;
  const mu = Math.log(spot) + (r - 0.5 * sigma * sigma) * Tyears;
  const sd = sigma * Math.sqrt(Tyears);

  // P/L at expiration = intrinsic-only (set every leg's T to 0)
  const expLegs = legs.map((l) => ({ ...l, T: 0 }));
  const entry = strategyEntryCost(legs);

  const N = 600;
  const lo = mu - 5 * sd;
  const hi = mu + 5 * sd;
  const dx = (hi - lo) / N;
  let pop = 0;
  for (let i = 0; i <= N; i++) {
    const x = lo + i * dx; // log-price
    const S = Math.exp(x);
    const pdf = normPDF((x - mu) / sd) / sd;
    const pnl = strategyValue(expLegs, S, r) - entry;
    const w = i === 0 || i === N ? 0.5 : 1; // trapezoid
    if (pnl > 0) pop += pdf * dx * w;
  }
  return Math.min(1, Math.max(0, pop));
}

/** Scan a price grid at expiration for max profit / max loss / breakevens. */
export function expirationProfile(
  legs: LegInput[],
  spot: number,
  r: number
): { maxProfit: number | null; maxLoss: number | null; breakevens: number[] } {
  const expLegs = legs.map((l) => ({ ...l, T: 0 }));
  const entry = strategyEntryCost(legs);
  const lo = spot * 0.4;
  const hi = spot * 1.8;
  const N = 800;
  const step = (hi - lo) / N;

  let maxP = -Infinity;
  let maxL = Infinity;
  const breakevens: number[] = [];
  let prevPnl: number | null = null;
  let prevS = lo;

  for (let i = 0; i <= N; i++) {
    const S = lo + i * step;
    const pnl = strategyValue(expLegs, S, r) - entry;
    if (pnl > maxP) maxP = pnl;
    if (pnl < maxL) maxL = pnl;
    if (prevPnl !== null && ((prevPnl < 0 && pnl >= 0) || (prevPnl >= 0 && pnl < 0))) {
      const t = Math.abs(prevPnl) / (Math.abs(prevPnl) + Math.abs(pnl));
      breakevens.push(prevS + t * step);
    }
    prevPnl = pnl;
    prevS = S;
  }

  // Downside is ALWAYS bounded — the underlying stops at zero. Evaluate S→0
  // explicitly and fold it into the extremes. Only the upside can be unbounded.
  const pnlAtZero = strategyValue(expLegs, 0.01, r) - entry;
  if (pnlAtZero > maxP) maxP = pnlAtZero;
  if (pnlAtZero < maxL) maxL = pnlAtZero;

  const eps = spot * 0.01;
  const slopeHigh = strategyValue(expLegs, hi, r) - strategyValue(expLegs, hi - eps, r);
  const edgeHigh = strategyValue(expLegs, hi, r) - entry;
  const unboundedProfit = Math.abs(slopeHigh) > 1e-6 && edgeHigh >= maxP && maxP > 0;
  const unboundedLoss = Math.abs(slopeHigh) > 1e-6 && edgeHigh <= maxL && maxL < 0;

  return {
    maxProfit: unboundedProfit ? null : maxP,
    maxLoss: unboundedLoss ? null : maxL,
    breakevens: breakevens.map((b) => Number(b.toFixed(2))),
  };
}

/**
 * POP and expected value at expiration in one lognormal integration pass.
 * Intrinsic-only payoff (T=0 per leg) weighted by the risk-neutral terminal
 * density. EV is the probability-weighted P/L — the number ROI-at-target
 * ignores. A high-ROI candidate with negative EV is a lottery ticket priced
 * like one; surfacing EV is what separates an optimizer from a slot machine.
 * Model caveats identical to probabilityOfProfit: constant vol, no skew.
 */
export function popAndExpectedValue(
  legs: LegInput[],
  spot: number,
  r: number,
  sigma: number,
  Tyears: number
): { pop: number; ev: number } | null {
  if (spot <= 0 || sigma <= 0 || Tyears <= 0) return null;
  const mu = Math.log(spot) + (r - 0.5 * sigma * sigma) * Tyears;
  const sd = sigma * Math.sqrt(Tyears);
  const entry = strategyEntryCost(legs);

  const N = 900;
  const lo = mu - 7 * sd;
  const hi = mu + 7 * sd;
  const dx = (hi - lo) / N;
  let pop = 0;
  let ev = 0;
  for (let i = 0; i <= N; i++) {
    const x = lo + i * dx;
    const S = Math.exp(x);
    const pdf = normPDF((x - mu) / sd) / sd;
    // intrinsic-only payoff at expiration
    let payoff = 0;
    for (const l of legs) {
      const intrinsic =
        l.option_type === "call" ? Math.max(0, S - l.strike) : Math.max(0, l.strike - S);
      payoff += (l.side === "long" ? 1 : -1) * intrinsic * l.quantity * 100;
    }
    const pnl = payoff - entry;
    const w = (i === 0 || i === N ? 0.5 : 1) * pdf * dx;
    ev += pnl * w;
    if (pnl > 0) pop += w;
  }
  return { pop: Math.min(1, Math.max(0, pop)), ev };
}

// ============================================================
// Market-implied density (Breeden–Litzenberger)
// ============================================================

export interface SmilePoint {
  strike: number;
  iv: number; // decimal
}

/**
 * Fits a smooth quadratic smile in log-moneyness: sigma(k) = a + b·k + c·k²,
 * k = ln(K/F). Least squares on observed points.
 *
 * Why quadratic and not interpolation: Breeden–Litzenberger differentiates
 * C(K) twice. A piecewise-linear smile has slope kinks at every strike knot,
 * and each kink becomes a vega-scaled ±delta-spike pair in d²C/dK² —
 * clipping the negatives then leaves aliased garbage (observed live: density
 * mean 874 vs parity forward 726 before this fix). A C∞ parametric fit makes
 * the density well-behaved by construction.
 *
 * Returns null when <8 points or <10% strike span — callers fall back to
 * lognormal and label it.
 */
export function buildSmile(points: SmilePoint[], forward: number): ((K: number) => number) | null {
  const pts = points.filter((p) => p.iv > 0.01 && p.iv < 5 && p.strike > 0);
  if (pts.length < 8) return null;
  const strikes = pts.map((p) => p.strike);
  if (Math.max(...strikes) - Math.min(...strikes) < forward * 0.1) return null;

  // Least squares for sigma = a + b·k + c·k², k = ln(K/F)
  let s0 = 0, s1 = 0, s2 = 0, s3 = 0, s4 = 0, t0 = 0, t1 = 0, t2 = 0;
  for (const p of pts) {
    const k = Math.log(p.strike / forward);
    const k2 = k * k;
    s0 += 1; s1 += k; s2 += k2; s3 += k2 * k; s4 += k2 * k2;
    t0 += p.iv; t1 += p.iv * k; t2 += p.iv * k2;
  }
  // Solve 3x3 normal equations via Cramer's rule
  const det =
    s0 * (s2 * s4 - s3 * s3) - s1 * (s1 * s4 - s2 * s3) + s2 * (s1 * s3 - s2 * s2);
  if (Math.abs(det) < 1e-12) return null;
  const a =
    (t0 * (s2 * s4 - s3 * s3) - s1 * (t1 * s4 - t2 * s3) + s2 * (t1 * s3 - t2 * s2)) / det;
  const b =
    (s0 * (t1 * s4 - t2 * s3) - t0 * (s1 * s4 - s2 * s3) + s2 * (s1 * t2 - s2 * t1)) / det;
  const c =
    (s0 * (s2 * t2 - s3 * t1) - s1 * (s1 * t2 - s2 * t1) + t0 * (s1 * s3 - s2 * s2)) / det;
  if (!Number.isFinite(a) || !Number.isFinite(b) || !Number.isFinite(c)) return null;

  // Evaluate with k saturating SMOOTHLY to the observed range. A hard clamp
  // creates a slope kink at the data boundary, and BL turns every smile kink
  // into a vega-scaled negative-density lobe (observed live: negMass exactly
  // at the boundary strikes). Softplus saturation is C-infinity:
  //   k → k inside the range, k → boundary asymptotically outside it.
  const kMin = Math.log(Math.min(...strikes) / forward);
  const kMax = Math.log(Math.max(...strikes) / forward);
  const w = Math.max((kMax - kMin) * 0.05, 1e-4);
  const softMin = (k: number) => kMax - w * Math.log(1 + Math.exp((kMax - k) / w)); // saturates above
  const softMax = (k: number) => kMin + w * Math.log(1 + Math.exp((k - kMin) / w)); // saturates below
  return (K: number): number => {
    const kRaw = Math.log(Math.max(K, 1e-9) / forward);
    // apply upper then lower saturation (ranges far apart relative to w)
    let k = kRaw < (kMin + kMax) / 2 ? softMax(kRaw) : softMin(kRaw);
    if (!Number.isFinite(k)) k = Math.min(kMax, Math.max(kMin, kRaw));
    const sig = a + b * k + c * k * k;
    return Math.min(3, Math.max(0.03, sig));
  };
}

/**
 * POP + EV at expiration under the MARKET-IMPLIED risk-neutral density.
 *
 * Breeden–Litzenberger (1978): f(K) = e^{rT} · ∂²C/∂K². Call prices are
 * generated from the smoothed smile via Black-Scholes (smooth in K, so the
 * second difference is stable), the density is clipped at zero and
 * renormalized. This prices skew — the thing flat-vol EV cannot see.
 *
 * Fallback contract: returns null when the recovered density loses mass
 * (pre-clip integral outside [0.85, 1.15]) — a sign of a broken smile —
 * and the caller MUST fall back to lognormal and label which model ran.
 */
export function marketImpliedPopEv(
  legs: LegInput[],
  spot: number,
  r: number,
  T: number,
  smile: (K: number) => number
): { pop: number; ev: number; mass: number } | null {
  if (spot <= 0 || T <= 0) return null;
  const forward = spot * Math.exp(r * T);
  const lo = spot * 0.4;
  const hi = spot * 2.2;
  const N = 900;
  const dK = (hi - lo) / N;
  const erT = Math.exp(r * T);

  // Call prices on the grid from the smooth smile
  const C: number[] = new Array(N + 1);
  for (let i = 0; i <= N; i++) {
    const K = lo + i * dK;
    C[i] = blackScholes("call", { S: spot, K, T, r, sigma: smile(K) }).price;
  }

  // Density via central second difference.
  // NOTE: ∫ d²C/dK² dK ≡ C'(hi) − C'(lo) ≈ 1 for ANY C — total mass is a
  // vacuous check. The real health checks are (a) negative-mass fraction
  // (butterfly-arbitrage in the fit) and (b) density mean vs the forward.
  const f: number[] = new Array(N + 1).fill(0);
  let negMass = 0;
  for (let i = 1; i < N; i++) {
    const d2 = (C[i - 1] - 2 * C[i] + C[i + 1]) / (dK * dK);
    const fi = erT * d2;
    if (fi < 0) negMass += -fi * dK;
    f[i] = Math.max(0, fi);
  }
  if (negMass > 0.05) return null; // fit admits arbitrage → caller falls back

  let mass = 0;
  for (let i = 0; i <= N; i++) mass += f[i] * dK;
  if (mass <= 0.5) return null;

  let mean = 0;
  for (let i = 1; i < N; i++) mean += (lo + i * dK) * (f[i] / mass) * dK;
  // Risk-neutral mean must sit at the forward (martingale). Allow 3% drift
  // for grid truncation + fit error; beyond that the density is not trustworthy.
  if (Math.abs(mean - forward) / forward > 0.03) return null;

  const entry = strategyEntryCost(legs);
  let pop = 0;
  let ev = 0;
  for (let i = 1; i < N; i++) {
    const K = lo + i * dK;
    let payoff = 0;
    for (const l of legs) {
      const intrinsic =
        l.option_type === "call" ? Math.max(0, K - l.strike) : Math.max(0, l.strike - K);
      payoff += (l.side === "long" ? 1 : -1) * intrinsic * l.quantity * 100;
    }
    const pnl = payoff - entry;
    const w = (f[i] / mass) * dK;
    ev += pnl * w;
    if (pnl > 0) pop += w;
  }
  return { pop: Math.min(1, Math.max(0, pop)), ev, mass: negMass };
}
