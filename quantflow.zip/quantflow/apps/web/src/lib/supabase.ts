import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/** Browser/RSC read-only client (anon key, RLS-enforced). */
export function supabaseAnon(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error("NEXT_PUBLIC_SUPABASE_URL / ANON_KEY not set");
  return createClient(url, key, { auth: { persistSession: false } });
}

/** Server-only client for API routes that write (alert rules). Never import in client components. */
export function supabaseService(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("SUPABASE_SERVICE_ROLE_KEY not set (server env)");
  return createClient(url, key, { auth: { persistSession: false } });
}
