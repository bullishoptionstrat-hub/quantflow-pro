/**
 * Server-side Tradier helpers shared by /api/chain and /api/optimizer.
 * Key never reaches the browser. Sandbox = DELAYED, production = REALTIME.
 */

export interface ChainContract {
  symbol: string;
  strike: number;
  option_type: "call" | "put";
  bid: number;
  ask: number;
  mid: number;
  last: number | null;
  volume: number;
  open_interest: number;
  iv: number | null; // decimal
}

export interface ChainResult {
  symbol: string;
  spot: number | null;
  expiration: string;
  expirations: string[];
  freshness: "REALTIME" | "DELAYED";
  contracts: ChainContract[];
}

interface TradierGreeks {
  mid_iv?: number;
}
interface TradierOption {
  symbol: string;
  strike: number;
  option_type: "call" | "put";
  bid: number | null;
  ask: number | null;
  last: number | null;
  volume: number | null;
  open_interest: number | null;
  greeks?: TradierGreeks | null;
}

export class TradierError extends Error {
  constructor(
    message: string,
    public status: number
  ) {
    super(message);
  }
}

export async function fetchChain(symbol: string, expiration?: string | null): Promise<ChainResult> {
  const key = process.env.TRADIER_API_KEY;
  if (!key) {
    throw new TradierError("TRADIER_API_KEY not configured on the web app — chain data unavailable.", 503);
  }
  const base =
    process.env.TRADIER_ENV === "production"
      ? "https://api.tradier.com/v1"
      : "https://sandbox.tradier.com/v1";
  const headers = { Authorization: `Bearer ${key}`, Accept: "application/json" };
  const freshness = process.env.TRADIER_ENV === "production" ? ("REALTIME" as const) : ("DELAYED" as const);

  const [quoteRes, expRes] = await Promise.all([
    fetch(`${base}/markets/quotes?symbols=${symbol}`, { headers, next: { revalidate: 60 } }),
    fetch(`${base}/markets/options/expirations?symbol=${symbol}`, { headers, next: { revalidate: 300 } }),
  ]);
  if (!quoteRes.ok || !expRes.ok) {
    throw new TradierError(`Tradier upstream error (${quoteRes.status}/${expRes.status})`, 502);
  }

  const quoteBody = (await quoteRes.json()) as {
    quotes?: { quote?: { last?: number } | { last?: number }[] };
  };
  const q = quoteBody.quotes?.quote;
  const spot = (Array.isArray(q) ? q[0]?.last : q?.last) ?? null;

  const expBody = (await expRes.json()) as { expirations?: { date?: string[] | string } };
  const d = expBody.expirations?.date;
  const expirations = Array.isArray(d) ? d : d ? [d] : [];
  if (expirations.length === 0) throw new TradierError(`No listed options for ${symbol}.`, 404);

  const exp = expiration && expirations.includes(expiration) ? expiration : expirations[0];

  const chainRes = await fetch(
    `${base}/markets/options/chains?symbol=${symbol}&expiration=${exp}&greeks=true`,
    { headers, next: { revalidate: 60 } }
  );
  if (!chainRes.ok) throw new TradierError(`Tradier chain error (${chainRes.status})`, 502);

  const chainBody = (await chainRes.json()) as {
    options?: { option?: TradierOption[] | TradierOption };
  };
  const raw = chainBody.options?.option;
  const options = Array.isArray(raw) ? raw : raw ? [raw] : [];

  const contracts: ChainContract[] = options.map((o) => {
    const bid = o.bid ?? 0;
    const ask = o.ask ?? 0;
    return {
      symbol: o.symbol,
      strike: o.strike,
      option_type: o.option_type,
      bid,
      ask,
      mid: bid > 0 && ask > 0 ? Number(((bid + ask) / 2).toFixed(4)) : (o.last ?? 0),
      last: o.last,
      volume: o.volume ?? 0,
      open_interest: o.open_interest ?? 0,
      iv: o.greeks?.mid_iv && o.greeks.mid_iv > 0 ? o.greeks.mid_iv : null,
    };
  });

  return { symbol, spot, expiration: exp, expirations: expirations.slice(0, 24), freshness, contracts };
}
