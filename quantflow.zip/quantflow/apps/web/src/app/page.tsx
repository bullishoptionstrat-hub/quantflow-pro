"use client";

import { useState } from "react";
import { useFlowFeed } from "@/hooks/useFlowFeed";
import { FlowTable } from "@/components/FlowTable";
import { FiltersPanel } from "@/components/FiltersPanel";
import { Watchlist } from "@/components/Watchlist";
import { SymbolDetail } from "@/components/SymbolDetail";
import { FeedStatusBar } from "@/components/FeedStatusBar";

export default function DashboardPage() {
  const { events, allEvents, powerAlerts, feedStatus } = useFlowFeed();
  const [selected, setSelected] = useState<string | null>("SPY");

  return (
    <div className="space-y-2">
      <FeedStatusBar status={feedStatus} />

      {powerAlerts.length > 0 && (
        <div className="panel border-amber/40 px-3 py-2 text-[12px]">
          <span className="eyebrow mr-3 text-amber">Power alert</span>
          {powerAlerts[0].underlying} — score {(powerAlerts[0].score * 100).toFixed(0)}%{" "}
          <span className="text-muted">({powerAlerts[0].scoring_mode})</span>
        </div>
      )}

      <div className="grid grid-cols-12 gap-2">
        <aside className="col-span-12 space-y-2 lg:col-span-2">
          <Watchlist allEvents={allEvents} onSelectSymbol={setSelected} selected={selected} />
          <FiltersPanel />
        </aside>

        <section className="col-span-12 lg:col-span-7">
          <FlowTable events={events} onSelectSymbol={setSelected} />
        </section>

        <aside className="col-span-12 lg:col-span-3">
          {selected ? (
            <SymbolDetail underlying={selected} />
          ) : (
            <div className="panel p-3 text-[12px] text-muted">Select a symbol to inspect its flow.</div>
          )}
        </aside>
      </div>
    </div>
  );
}
