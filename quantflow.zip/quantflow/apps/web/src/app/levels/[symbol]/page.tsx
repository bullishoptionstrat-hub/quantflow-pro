"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import type { DataFreshness, FlowLevel, GexLevel } from "@quantflow/shared";
import { FreshnessBadge } from "@/components/FreshnessBadge";
import { PriceChart, type Candle } from "@/components/PriceChart";
import { fmtNum } from "@/lib/format";

const QUICK_SYMBOLS = ["SPY", "QQQ", "TSLA", "NVDA", "AAPL", "MSFT", "AMZN", "META", "AMD", "GOOGL"];

const TYPE_STYLE: Record<FlowLevel["level_type"], { dot: string; label: string }> = {
  support: { dot: "bg-bull", label: "Support" },
  resistance: { dot: "bg-bear", label: "Resistance" },
  accumulation: { dot: "bg-amber", label: "Accumulation" },
};

export default function LevelsPage() {
  const params = useParams<{ symbol: string }>();
  const router = useRouter();
  const symbol = (params.symbol ?? "SPY").toUpperCase();

  const [levels, setLevels] = useState<FlowLevel[]>([]);
  const [candles, setCandles] = useState<Candle[]>([]);
  const [gex, setGex] = useState<GexLevel[]>([]);
  const [gexComputedAt, setGexComputedAt] = useState<string | null>(null);
  const [input, setInput] = useState(symbol);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetch(`/api/levels/${symbol}`, { cache: "no-store" })
      .then(async (res) => {
        const body = (await res.json()) as { levels?: FlowLevel[]; candles?: Candle[]; error?: string };
        if (!res.ok || body.error) throw new Error(body.error ?? `HTTP ${res.status}`);
        if (cancelled) return;
        setLevels(body.levels ?? []);
        setCandles(body.candles ?? []);
      })
      .catch((e) => !cancelled && setError(e instanceof Error ? e.message : "Failed to load"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [symbol]);

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/gex/${symbol}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((b: { levels?: GexLevel[]; computed_at?: string | null }) => {
        if (cancelled) return;
        setGex(b.levels ?? []);
        setGexComputedAt(b.computed_at ?? null);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [symbol]);

  // GEX → chart overlay: flip + top walls become price lines. Mapped onto the
  // FlowLevel type the chart already accepts (flip→accumulation/amber,
  // wall→support/resistance by gamma sign).
  const gexChartLevels: FlowLevel[] = useMemo(() => {
    const picks = gex
      .filter((g) => g.level_type === "flip" || g.level_type === "wall")
      .sort((a, b) => Math.abs(b.net_gex) - Math.abs(a.net_gex))
      .slice(0, 6);
    return picks.map((g) => ({
      id: `gex-${g.id}`,
      symbol: g.underlying,
      price_level: g.strike,
      total_volume: Math.abs(Math.round(g.net_gex / 1e6)),
      level_type: g.level_type === "flip" ? "accumulation" : g.net_gex >= 0 ? "support" : "resistance",
      last_updated: g.computed_at,
    }));
  }, [gex]);

  const gexRegime = useMemo(() => {
    if (gex.length === 0) return null;
    const total = gex.reduce((s, g) => s + g.net_gex, 0);
    const flip = gex.find((g) => g.level_type === "flip") ?? null;
    const spot = gex[0]?.spot_price ?? null;
    const walls = gex.filter((g) => g.level_type === "wall");
    const nearestWall = spot
      ? [...walls].sort((a, b) => Math.abs(a.strike - spot) - Math.abs(b.strike - spot))[0] ?? null
      : null;
    return { total, flip, spot, nearestWall, negative: total < 0 };
  }, [gex]);

  const maxVol = Math.max(...levels.map((l) => l.total_volume), 1);
  const sorted = [...levels].sort((a, b) => b.price_level - a.price_level);

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-bold tracking-tight">
            Flow Levels · <span className="text-amber">{symbol}</span>
          </h1>
          <p className="mt-1 text-xs text-muted">
            Volume-at-price computed from the last 30 days of recorded options flow (underlying price binned by traded
            premium volume). Recomputed hourly by the ingest service.
          </p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const s = input.toUpperCase().trim();
            if (s && s !== symbol) router.push(`/levels/${s}`);
          }}
          className="flex items-center gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value.toUpperCase())}
            className="w-28 rounded border border-line bg-ink-900 px-2 py-1 text-xs outline-none focus:border-amber"
            maxLength={6}
            aria-label="Symbol"
          />
          <button type="submit" className="rounded bg-ink-800 px-3 py-1 font-display text-xs font-semibold hover:bg-ink-700">
            Load
          </button>
        </form>
      </div>

      <div className="mb-4 flex flex-wrap gap-1">
        {QUICK_SYMBOLS.map((s) => (
          <button
            key={s}
            onClick={() => router.push(`/levels/${s}`)}
            className={`rounded px-2.5 py-1 font-display text-[11px] font-semibold ${
              s === symbol ? "bg-amber-dim text-amber" : "text-muted hover:text-bright"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {error && <div className="panel mb-4 px-4 py-3 text-xs text-bear">{error}</div>}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <section className="panel p-4 lg:col-span-8">
          <div className="mb-2 flex items-center justify-between">
            <span className="eyebrow">Daily · 90 sessions · levels overlaid</span>
            <span className="flex gap-3 text-[10px] text-muted">
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-bull" />Support</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-bear" />Resistance</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-amber" />Accumulation / GEX flip</span>
              <span className="text-muted">· GEX walls overlaid as S/R by gamma sign</span>
            </span>
          </div>
          {candles.length > 0 ? (
            <PriceChart candles={candles} levels={[...levels, ...gexChartLevels]} height={420} />
          ) : (
            <div className="flex h-[420px] items-center justify-center text-center text-xs text-muted">
              {loading
                ? "Loading…"
                : "No candles. Set TRADIER_API_KEY in the web app environment to enable charting — levels below still work without it."}
            </div>
          )}
        </section>

        <section className="panel overflow-hidden lg:col-span-4">
          <div className="border-b border-line px-3 py-2">
            <span className="eyebrow">Levels by flow volume</span>
          </div>
          {sorted.length === 0 && !loading && (
            <div className="px-3 py-10 text-center text-xs text-muted">
              No levels computed for {symbol} yet. Levels need ≥30 days of flow history (or at least some) and the
              hourly recompute job to have run.
            </div>
          )}
          <ul>
            {sorted.map((l) => {
              const s = TYPE_STYLE[l.level_type];
              return (
                <li key={l.id} className="border-b border-line/60 px-3 py-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2">
                      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
                      <span className="font-display font-bold">{l.price_level.toFixed(2)}</span>
                      <span className="text-[10px] uppercase tracking-wider text-muted">{s.label}</span>
                    </span>
                    <span className="text-muted">{fmtNum(l.total_volume)}</span>
                  </div>
                  <div className="mt-1 h-1 rounded bg-ink-800">
                    <div
                      className={`h-1 rounded ${s.dot}`}
                      style={{ width: `${Math.max((l.total_volume / maxVol) * 100, 2)}%`, opacity: 0.7 }}
                    />
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      </div>

      {gexRegime && (
        <section className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="panel p-3">
            <div className="eyebrow">Gamma regime</div>
            <div className={`mt-1 font-display text-base font-bold ${gexRegime.negative ? "text-bear" : "text-bull"}`}>
              {gexRegime.negative ? "NEGATIVE" : "POSITIVE"}
            </div>
            <div className="mt-0.5 text-[10px] text-muted">
              {gexRegime.negative ? "dealers chase moves — expect amplification" : "dealers fade moves — expect dampening"}
            </div>
          </div>
          <div className="panel p-3">
            <div className="eyebrow">Net GEX (Σ strikes)</div>
            <div className="mt-1 font-display text-base font-bold">
              {Math.abs(gexRegime.total) >= 1e9 ? `${(gexRegime.total / 1e9).toFixed(2)}B` : `${(gexRegime.total / 1e6).toFixed(0)}M`}
            </div>
            <div className="mt-0.5 text-[10px] text-muted">per 1% move · 3 near expirations</div>
          </div>
          <div className="panel p-3">
            <div className="eyebrow">Gamma flip</div>
            <div className="mt-1 font-display text-base font-bold text-amber">{gexRegime.flip?.strike ?? "—"}</div>
            <div className="mt-0.5 text-[10px] text-muted">
              {gexRegime.flip && gexRegime.spot
                ? `spot ${gexRegime.spot < gexRegime.flip.strike ? "below" : "above"} flip (${gexRegime.spot.toFixed(2)})`
                : ""}
            </div>
          </div>
          <div className="panel p-3">
            <div className="eyebrow">Nearest wall</div>
            <div className="mt-1 font-display text-base font-bold">{gexRegime.nearestWall?.strike ?? "—"}</div>
            <div className="mt-0.5 text-[10px] text-muted">
              {gexRegime.nearestWall
                ? `${(Math.abs(gexRegime.nearestWall.net_gex) / 1e6).toFixed(0)}M ${gexRegime.nearestWall.net_gex >= 0 ? "support-side" : "resistance-side"}`
                : ""}
            </div>
          </div>
        </section>
      )}

      {gex.length > 0 && (
        <section className="panel mt-4 p-4">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <span className="eyebrow">
              Gamma exposure (GEX) by strike
              {gexComputedAt ? ` · computed ${new Date(gexComputedAt).toLocaleTimeString("en-US", { hour12: false, timeZone: "America/New_York", hour: "2-digit", minute: "2-digit" })} ET` : ""}
            </span>
            <span className="flex items-center gap-2 text-[10px] text-muted">
              <FreshnessBadge freshness={(gex[0]?.freshness ?? "DELAYED") as DataFreshness} />
              <span>ORATS greeks · ~hourly · positioning map, not a signal</span>
            </span>
          </div>
          {(() => {
            const sortedG = [...gex].sort((a, b) => a.strike - b.strike);
            const maxAbs = Math.max(...sortedG.map((g) => Math.abs(g.net_gex)), 1);
            return (
              <div className="grid grid-cols-1 gap-x-8 gap-y-1 md:grid-cols-2">
                {sortedG.map((g) => (
                  <div key={g.id} className="flex items-center gap-2 text-[11px]">
                    <span className={`w-16 text-right font-display font-bold ${g.level_type === "flip" ? "text-amber" : ""}`}>
                      {g.strike}
                    </span>
                    <div className="relative h-2.5 flex-1 rounded bg-ink-800">
                      <div className="absolute inset-y-0 left-1/2 w-px bg-ink-600" />
                      {g.net_gex >= 0 ? (
                        <div className="absolute inset-y-0 left-1/2 rounded-r bg-bull/70" style={{ width: `${(g.net_gex / maxAbs) * 50}%` }} />
                      ) : (
                        <div className="absolute inset-y-0 rounded-l bg-bear/70" style={{ right: "50%", width: `${(Math.abs(g.net_gex) / maxAbs) * 50}%` }} />
                      )}
                    </div>
                    <span className="w-24 text-right text-muted">
                      {Math.abs(g.net_gex) >= 1e9 ? `${(g.net_gex / 1e9).toFixed(2)}B` : `${(g.net_gex / 1e6).toFixed(0)}M`}
                    </span>
                    <span className={`w-16 text-[9px] uppercase tracking-wider ${g.level_type === "wall" ? "text-amber" : g.level_type === "flip" ? "text-amber font-bold" : "text-muted"}`}>
                      {g.level_type}
                    </span>
                  </div>
                ))}
              </div>
            );
          })()}
          <p className="mt-2 text-[10px] leading-relaxed text-muted">
            GEX = gamma × OI × 100 × spot² × 1% per strike, calls positive / puts negative under the standard
            dealer short-call/long-put heuristic. Actual dealer books are unobservable — every retail GEX product
            makes this same assumption. Positive zones tend to dampen moves, negative zones accelerate them.
          </p>
        </section>
      )}

      <p className="mt-3 text-[11px] text-muted">
        These are flow-concentration levels, not order-book levels. They mark where options premium has clustered by
        underlying price — useful as reaction-zone context, not as standalone entries.
      </p>
    </main>
  );
}
