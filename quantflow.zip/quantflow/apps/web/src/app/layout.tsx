import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "QuantFlow Terminal",
  description: "Options flow scanner — sweeps, blocks, unusual activity, ATS volume, levels.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <Nav />
          <div className="px-3 pb-6 pt-2">{children}</div>
        </Providers>
      </body>
    </html>
  );
}
