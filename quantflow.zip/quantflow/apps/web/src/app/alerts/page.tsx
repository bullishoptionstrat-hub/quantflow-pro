"use client";

import { useCallback, useEffect, useState } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import type { AlertRule, OrderType, Sentiment } from "@quantflow/shared";
import { fmtPremium, fmtTime } from "@/lib/format";

interface AlertLogRow {
  id: string;
  created_at: string;
  rule_id: string;
  flow_event_id: string | null;
  delivered: boolean;
  channel: "browser" | "webhook";
}

const ORDER_TYPES: OrderType[] = ["SWEEP", "BLOCK", "SPLIT"];
const SENTIMENTS: Sentiment[] = ["BULLISH", "BEARISH", "NEUTRAL"];

export default function AlertsPage() {
  const { data: session, status } = useSession();
  const [rules, setRules] = useState<AlertRule[]>([]);
  const [log, setLog] = useState<AlertLogRow[]>([]);
  const [notifPerm, setNotifPerm] = useState<NotificationPermission | "unsupported">("default");

  // Form state
  const [underlying, setUnderlying] = useState("");
  const [minPremium, setMinPremium] = useState(500_000);
  const [orderTypes, setOrderTypes] = useState<OrderType[]>(["SWEEP"]);
  const [sentiments, setSentiments] = useState<Sentiment[]>(["BULLISH"]);
  const [unusualOnly, setUnusualOnly] = useState(true);
  const [webhookUrl, setWebhookUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    setNotifPerm(typeof Notification === "undefined" ? "unsupported" : Notification.permission);
  }, []);

  const load = useCallback(async () => {
    const res = await fetch("/api/alerts/subscribe", { cache: "no-store" });
    if (!res.ok) return;
    const body = (await res.json()) as { rules: AlertRule[]; log: AlertLogRow[] };
    setRules(body.rules ?? []);
    setLog(body.log ?? []);
  }, []);

  useEffect(() => {
    if (status === "authenticated") void load();
  }, [status, load]);

  async function createRule(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setFormError(null);
    try {
      const res = await fetch("/api/alerts/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          underlying: underlying.trim() ? underlying.trim().toUpperCase() : null,
          min_premium: minPremium,
          order_types: orderTypes,
          sentiments,
          unusual_only: unusualOnly,
          webhook_url: webhookUrl.trim() ? webhookUrl.trim() : null,
        }),
      });
      const body = await res.json();
      if (!res.ok) {
        const msg =
          typeof body.error === "string"
            ? body.error
            : body.error?.fieldErrors
              ? Object.entries(body.error.fieldErrors as Record<string, string[]>)
                  .map(([k, v]) => `${k}: ${v.join(", ")}`)
                  .join(" · ")
              : "Failed to create rule";
        throw new Error(msg);
      }
      setUnderlying("");
      setWebhookUrl("");
      await load();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Failed to create rule");
    } finally {
      setSubmitting(false);
    }
  }

  async function deleteRule(id: string) {
    await fetch(`/api/alerts/subscribe?id=${id}`, { method: "DELETE" });
    await load();
  }

  function describeRule(r: AlertRule): string {
    const parts = [
      r.underlying ?? "Any symbol",
      r.order_types.length ? r.order_types.join("/") : "any type",
      `≥ ${fmtPremium(r.min_premium)}`,
      r.sentiments.length ? r.sentiments.join("/").toLowerCase() : "any sentiment",
    ];
    if (r.unusual_only) parts.push("unusual only");
    return parts.join(" · ");
  }

  if (status === "loading") {
    return <main className="mx-auto max-w-4xl px-4 py-10 text-center text-xs text-muted">Loading session…</main>;
  }

  if (!session) {
    return (
      <main className="mx-auto max-w-4xl px-4 py-6">
        <h1 className="font-display text-lg font-bold tracking-tight">Alerts</h1>
        <div className="panel mt-4 px-5 py-8 text-center">
          <p className="text-sm">Sign in to create alert rules and view your alert history.</p>
          <p className="mt-2 text-xs text-muted">
            Rules are evaluated server-side by the ingest service on every finalized flow event, so webhook alerts fire
            even when your browser is closed.
          </p>
          <button
            onClick={() => signIn()}
            className="mt-5 rounded bg-amber px-5 py-2 font-display text-xs font-bold text-ink-950 hover:bg-amber/90"
          >
            Sign in
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-4 flex items-end justify-between">
        <div>
          <h1 className="font-display text-lg font-bold tracking-tight">Alerts</h1>
          <p className="mt-1 text-xs text-muted">
            Signed in as {session.user?.email} ·{" "}
            <button onClick={() => signOut()} className="underline underline-offset-2 hover:text-bright">
              sign out
            </button>
          </p>
        </div>
        {notifPerm !== "unsupported" && notifPerm !== "granted" && (
          <button
            onClick={async () => setNotifPerm(await Notification.requestPermission())}
            className="rounded border border-amber/50 px-3 py-1.5 font-display text-[11px] font-semibold text-amber hover:bg-amber-dim"
          >
            Enable browser notifications
          </button>
        )}
        {notifPerm === "granted" && <span className="text-[11px] text-bull">Browser notifications enabled</span>}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Rule builder */}
        <section className="panel p-4 lg:col-span-5">
          <div className="eyebrow mb-3">New rule</div>
          <form onSubmit={createRule} className="space-y-3 text-xs">
            <div className="flex gap-3">
              <label className="flex-1">
                <span className="mb-1 block text-muted">Symbol (blank = all)</span>
                <input
                  value={underlying}
                  onChange={(e) => setUnderlying(e.target.value.toUpperCase())}
                  placeholder="TSLA"
                  maxLength={6}
                  className="w-full rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber"
                />
              </label>
              <label className="flex-1">
                <span className="mb-1 block text-muted">Min premium (USD)</span>
                <input
                  type="number"
                  min={0}
                  step={1000}
                  value={minPremium}
                  onChange={(e) => setMinPremium(Number(e.target.value))}
                  className="w-full rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber"
                />
              </label>
            </div>

            <div>
              <span className="mb-1 block text-muted">Order types</span>
              <div className="flex gap-1">
                {ORDER_TYPES.map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() =>
                      setOrderTypes((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]))
                    }
                    className={`rounded px-2.5 py-1 font-display text-[11px] font-semibold ${
                      orderTypes.includes(t) ? "bg-ink-700 text-bright" : "text-muted hover:text-bright"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="mb-1 block text-muted">Sentiment</span>
              <div className="flex gap-1">
                {SENTIMENTS.map((s) => (
                  <button
                    type="button"
                    key={s}
                    onClick={() =>
                      setSentiments((cur) => (cur.includes(s) ? cur.filter((x) => x !== s) : [...cur, s]))
                    }
                    className={`rounded px-2.5 py-1 font-display text-[11px] font-semibold ${
                      sentiments.includes(s)
                        ? s === "BULLISH"
                          ? "bg-bull-dim text-bull"
                          : s === "BEARISH"
                            ? "bg-bear-dim text-bear"
                            : "bg-ink-700 text-bright"
                        : "text-muted hover:text-bright"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <label className="flex items-center gap-2">
              <input type="checkbox" checked={unusualOnly} onChange={() => setUnusualOnly((v) => !v)} className="accent-amber" />
              <span>Unusual flow only (≥3× 20-day contract volume)</span>
            </label>

            <label className="block">
              <span className="mb-1 block text-muted">Webhook URL (optional — Discord or Telegram only)</span>
              <input
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="https://discord.com/api/webhooks/…"
                className="w-full rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber"
              />
            </label>

            {formError && <p className="text-bear">{formError}</p>}

            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded bg-amber px-4 py-2 font-display text-xs font-bold text-ink-950 hover:bg-amber/90 disabled:opacity-50"
            >
              {submitting ? "Creating…" : "Create rule"}
            </button>
            <p className="text-[10px] leading-relaxed text-muted">
              Example: TSLA · SWEEP · ≥ $500K · bullish · unusual only. Rules match against finalized flow events as
              the ingest service writes them. Browser notifications additionally require this tab (or any QuantFlow
              tab) to be open; webhooks fire regardless.
            </p>
          </form>
        </section>

        {/* Active rules + history */}
        <div className="space-y-4 lg:col-span-7">
          <section className="panel overflow-hidden">
            <div className="border-b border-line px-3 py-2">
              <span className="eyebrow">Active rules ({rules.length})</span>
            </div>
            {rules.length === 0 && <div className="px-3 py-8 text-center text-xs text-muted">No rules yet.</div>}
            <ul>
              {rules.map((r) => (
                <li key={r.id} className="flex items-center justify-between border-b border-line/60 px-3 py-2.5 text-xs">
                  <div>
                    <span className="font-display font-bold">{r.underlying ?? "ALL"}</span>
                    <span className="ml-2 text-muted">{describeRule(r)}</span>
                    {r.webhook_url && (
                      <span className="ml-2 rounded bg-ink-800 px-1.5 py-0.5 text-[10px] text-muted">
                        {r.webhook_url.includes("discord") ? "Discord" : "Telegram"}
                      </span>
                    )}
                  </div>
                  <button onClick={() => void deleteRule(r.id)} className="text-[11px] text-muted hover:text-bear">
                    Delete
                  </button>
                </li>
              ))}
            </ul>
          </section>

          <section className="panel overflow-hidden">
            <div className="border-b border-line px-3 py-2">
              <span className="eyebrow">Alert history (last 100)</span>
            </div>
            {log.length === 0 && (
              <div className="px-3 py-8 text-center text-xs text-muted">
                Nothing fired yet. History fills as rules match live flow.
              </div>
            )}
            <ul className="max-h-[360px] overflow-y-auto">
              {log.map((l) => (
                <li key={l.id} className="flex items-center justify-between border-b border-line/60 px-3 py-2 text-xs">
                  <span className="text-muted">{fmtTime(l.created_at)} ET</span>
                  <span className="rounded bg-ink-800 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-muted">
                    {l.channel}
                  </span>
                  <span className={l.delivered ? "text-bull" : "text-bear"}>
                    {l.delivered ? "delivered" : "failed"}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>
    </main>
  );
}
