"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { fmtNum, fmtPremium } from "@/lib/format";

type SortKey = "total_premium" | "unusual_count" | "net_flow";

interface ScreenerRow {
  underlying: string;
  total_premium: number;
  unusual_count: number;
  net_flow: number;
  event_count: number;
  spark: number[];
}

const SORTS: { key: SortKey; label: string }[] = [
  { key: "total_premium", label: "Total Premium" },
  { key: "unusual_count", label: "Unusual Count" },
  { key: "net_flow", label: "Net Flow" },
];

const PREMIUM_STEPS = [0, 25_000, 100_000, 250_000, 1_000_000];

function Sparkline({ data }: { data: number[] }) {
  const w = 96;
  const h = 22;
  const max = Math.max(...data.map((v) => Math.abs(v)), 1);
  const mid = h / 2;
  const step = w / (data.length - 1 || 1);
  const points = data.map((v, i) => `${(i * step).toFixed(1)},${(mid - (v / max) * (mid - 2)).toFixed(1)}`).join(" ");
  const last = data[data.length - 1] ?? 0;
  return (
    <svg width={w} height={h} className="block" aria-hidden>
      <line x1={0} y1={mid} x2={w} y2={mid} stroke="#212737" strokeWidth={1} />
      <polyline points={points} fill="none" strokeWidth={1.5} stroke={last >= 0 ? "#2DD4A7" : "#F0524C"} />
    </svg>
  );
}

export default function ScreenerPage() {
  const [sort, setSort] = useState<SortKey>("total_premium");
  const [minPremium, setMinPremium] = useState(0);
  const [rows, setRows] = useState<ScreenerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/screener?sort=${sort}&min_premium=${minPremium}`, { cache: "no-store" });
      const body = (await res.json()) as { rows?: ScreenerRow[]; error?: string };
      if (!res.ok || body.error) throw new Error(body.error ?? `HTTP ${res.status}`);
      setRows(body.rows ?? []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load screener");
    } finally {
      setLoading(false);
    }
  }, [sort, minPremium]);

  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 60_000);
    return () => clearInterval(t);
  }, [load]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-bold tracking-tight">Unusual Activity Screener</h1>
          <p className="mt-1 text-xs text-muted">Today (ET) · aggregated from per-event flow · refreshes every 60s</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <span className="eyebrow mr-1">Sort</span>
            {SORTS.map((s) => (
              <button
                key={s.key}
                onClick={() => setSort(s.key)}
                className={`rounded px-2.5 py-1 font-display text-[11px] font-semibold ${
                  sort === s.key ? "bg-amber-dim text-amber" : "text-muted hover:text-bright"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            <span className="eyebrow mr-1">Min Prem</span>
            {PREMIUM_STEPS.map((p) => (
              <button
                key={p}
                onClick={() => setMinPremium(p)}
                className={`rounded px-2 py-1 text-[11px] ${
                  minPremium === p ? "bg-ink-700 text-bright" : "text-muted hover:text-bright"
                }`}
              >
                {p === 0 ? "All" : fmtPremium(p)}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="panel overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-line text-[10px] uppercase tracking-wider text-muted">
              <th className="px-3 py-2">#</th>
              <th className="px-3 py-2">Symbol</th>
              <th className="px-3 py-2 text-right">Total Premium</th>
              <th className="px-3 py-2 text-right">Unusual</th>
              <th className="px-3 py-2 text-right">Net Flow</th>
              <th className="px-3 py-2 text-right">Events</th>
              <th className="px-3 py-2">Session Flow</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {loading && rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-muted">
                  Loading…
                </td>
              </tr>
            )}
            {error && (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-bear">
                  {error}
                </td>
              </tr>
            )}
            {!loading && !error && rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-10 text-center text-muted">
                  No flow recorded today. The screener fills as the ingest service writes events.
                </td>
              </tr>
            )}
            {rows.map((r, i) => (
              <tr key={r.underlying} className="border-b border-line/60 hover:bg-ink-850">
                <td className="px-3 py-2 text-muted">{i + 1}</td>
                <td className="px-3 py-2 font-display font-bold">{r.underlying}</td>
                <td className="px-3 py-2 text-right">{fmtPremium(r.total_premium)}</td>
                <td className="px-3 py-2 text-right">
                  {r.unusual_count > 0 ? <span className="text-amber">{r.unusual_count}</span> : <span className="text-muted">0</span>}
                </td>
                <td className={`px-3 py-2 text-right ${r.net_flow > 0 ? "text-bull" : r.net_flow < 0 ? "text-bear" : "text-muted"}`}>
                  {r.net_flow >= 0 ? "+" : "−"}
                  {fmtPremium(Math.abs(r.net_flow))}
                </td>
                <td className="px-3 py-2 text-right text-muted">{fmtNum(r.event_count)}</td>
                <td className="px-3 py-2">
                  <Sparkline data={r.spark} />
                </td>
                <td className="px-3 py-2 text-right">
                  <Link href={`/levels/${r.underlying}`} className="text-[11px] text-muted underline-offset-2 hover:text-amber hover:underline">
                    Levels →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-3 text-[11px] text-muted">
        Net flow = bullish premium − bearish premium (size-weighted aggressor side vs. bid/ask). Sector and market-cap
        filters are not included: that requires a reference-data source the free stack doesn&apos;t provide. Symbol
        coverage is limited to the ingest WATCHLIST.
      </p>
    </main>
  );
}
