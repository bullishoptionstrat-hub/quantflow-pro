"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useSession, signIn } from "next-auth/react";
import type { DataFreshness, OptimizerCandidate, SavedStrategy, StrategyLeg } from "@quantflow/shared";
import { FreshnessBadge } from "@/components/FreshnessBadge";
import { fmtNum } from "@/lib/format";
import {
  expirationProfile,
  popAndExpectedValue,
  strategyEntryCost,
  strategyGreeks,
  strategyPnL,
  type LegInput,
} from "@/lib/blackScholes";
import type { ChainContract } from "@/lib/tradier-server";

const RISK_FREE = 0.05;
const YEAR_MS = 365.25 * 86_400_000;
const QUICK = ["SPY", "QQQ", "TSLA", "NVDA", "AAPL", "AMD"];

interface ChainState {
  symbol: string;
  spot: number | null;
  expiration: string;
  expirations: string[];
  freshness: DataFreshness;
  contracts: ChainContract[];
}

function yearsTo(expIso: string, fromMs = Date.now()): number {
  return Math.max(0, (new Date(expIso + "T16:00:00-05:00").getTime() - fromMs) / YEAR_MS);
}

function toLegInputs(legs: StrategyLeg[], atMs: number): LegInput[] {
  return legs.map((l) => ({
    option_type: l.option_type,
    side: l.side,
    strike: l.strike,
    quantity: l.quantity,
    entry_price: l.entry_price,
    iv: l.iv,
    T: yearsTo(l.expiration, atMs),
  }));
}

function fmtUsd(v: number): string {
  const sign = v < 0 ? "−" : "";
  const a = Math.abs(v);
  return `${sign}$${a >= 1000 ? fmtNum(Math.round(a)) : a.toFixed(2)}`;
}

// ----------------------------------------------------------------
// P/L chart — pure SVG, expiration curve + valuation-date curve
// ----------------------------------------------------------------
function PnLChart({ legs, spot }: { legs: StrategyLeg[]; spot: number }) {
  const W = 720;
  const H = 300;
  const PAD = { l: 56, r: 12, t: 12, b: 26 };

  const data = useMemo(() => {
    if (legs.length === 0) return null;
    const nowMs = Date.now();
    const lo = spot * 0.75;
    const hi = spot * 1.25;
    const N = 160;
    const xs: number[] = [];
    const atExp: number[] = [];
    const atNow: number[] = [];
    const expLegsNow = toLegInputs(legs, nowMs);
    // expiration curve: all T forced to 0
    const expLegsExp = expLegsNow.map((l) => ({ ...l, T: 0 }));
    const entry = strategyEntryCost(expLegsNow);
    for (let i = 0; i <= N; i++) {
      const S = lo + ((hi - lo) * i) / N;
      xs.push(S);
      atExp.push(
        expLegsExp.reduce((s, l) => {
          const intrinsic =
            l.option_type === "call" ? Math.max(0, S - l.strike) : Math.max(0, l.strike - S);
          return s + (l.side === "long" ? 1 : -1) * intrinsic * l.quantity * 100;
        }, 0) - entry
      );
      atNow.push(strategyPnL(expLegsNow, S, RISK_FREE));
    }
    const all = [...atExp, ...atNow];
    const yMin = Math.min(...all, 0);
    const yMax = Math.max(...all, 0);
    const span = Math.max(yMax - yMin, 1);
    return { xs, atExp, atNow, lo, hi, yMin: yMin - span * 0.05, yMax: yMax + span * 0.05 };
  }, [legs, spot]);

  if (!data) {
    return (
      <div className="flex h-[300px] items-center justify-center text-xs text-muted">
        Add a leg to see the P/L profile.
      </div>
    );
  }

  const sx = (S: number) => PAD.l + ((S - data.lo) / (data.hi - data.lo)) * (W - PAD.l - PAD.r);
  const sy = (v: number) => PAD.t + (1 - (v - data.yMin) / (data.yMax - data.yMin)) * (H - PAD.t - PAD.b);
  const path = (ys: number[]) => ys.map((v, i) => `${i === 0 ? "M" : "L"}${sx(data.xs[i]).toFixed(1)},${sy(v).toFixed(1)}`).join(" ");

  const zeroY = sy(0);
  const gridPrices = [0.8, 0.9, 1, 1.1, 1.2].map((m) => spot * m);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Strategy P/L profile">
      {gridPrices.map((p) => (
        <g key={p}>
          <line x1={sx(p)} y1={PAD.t} x2={sx(p)} y2={H - PAD.b} stroke="#161A23" />
          <text x={sx(p)} y={H - 8} textAnchor="middle" fontSize={10} fill="#6B7489" fontFamily="'IBM Plex Mono',monospace">
            {p.toFixed(0)}
          </text>
        </g>
      ))}
      {[data.yMin * 0.7, 0, data.yMax * 0.7].map((v, i) => (
        <text key={i} x={PAD.l - 6} y={sy(v) + 3} textAnchor="end" fontSize={10} fill="#6B7489" fontFamily="'IBM Plex Mono',monospace">
          {fmtUsd(v)}
        </text>
      ))}
      {/* zero line */}
      <line x1={PAD.l} y1={zeroY} x2={W - PAD.r} y2={zeroY} stroke="#2E3650" strokeDasharray="3 3" />
      {/* spot marker */}
      <line x1={sx(spot)} y1={PAD.t} x2={sx(spot)} y2={H - PAD.b} stroke="#F5B73D" strokeDasharray="4 3" strokeOpacity={0.6} />
      <text x={sx(spot) + 4} y={PAD.t + 10} fontSize={10} fill="#F5B73D" fontFamily="'IBM Plex Mono',monospace">
        spot {spot.toFixed(2)}
      </text>
      {/* today curve */}
      <path d={path(data.atNow)} fill="none" stroke="#6B7489" strokeWidth={1.5} strokeDasharray="5 3" />
      {/* expiration curve, profit/loss split via gradient is overkill — single teal/red by sign segments */}
      <path d={path(data.atExp)} fill="none" stroke="#2DD4A7" strokeWidth={2} />
    </svg>
  );
}

// ----------------------------------------------------------------
// Page
// ----------------------------------------------------------------
export default function CalculatorPage() {
  const { data: session } = useSession();
  const [symbolInput, setSymbolInput] = useState("SPY");
  const [chain, setChain] = useState<ChainState | null>(null);
  const [chainError, setChainError] = useState<string | null>(null);
  const [loadingChain, setLoadingChain] = useState(false);
  const [legs, setLegs] = useState<StrategyLeg[]>([]);
  const [saved, setSaved] = useState<SavedStrategy[]>([]);
  const [saveName, setSaveName] = useState("");
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  // Optimizer state
  const [targetPrice, setTargetPrice] = useState<string>("");
  const [targetDate, setTargetDate] = useState<string>("");
  const [maxCost, setMaxCost] = useState<string>("5000");
  const [optResults, setOptResults] = useState<OptimizerCandidate[] | null>(null);
  const [optMeta, setOptMeta] = useState<{
    evaluated: number;
    caveat: string;
    model: string;
    scans: { expiration: string; expected_move: number | null; density_model: string }[];
  } | null>(null);
  const [optError, setOptError] = useState<string | null>(null);
  const [optimizing, setOptimizing] = useState(false);
  const [optSort, setOptSort] = useState<"ev" | "roi">("ev");
  const [scanMulti, setScanMulti] = useState(true);

  const loadChain = useCallback(async (symbol: string, expiration?: string) => {
    setLoadingChain(true);
    setChainError(null);
    try {
      const url = expiration
        ? `/api/chain/${symbol}?expiration=${expiration}`
        : `/api/chain/${symbol}`;
      const res = await fetch(url, { cache: "no-store" });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
      setChain(body as ChainState);
    } catch (e) {
      setChainError(e instanceof Error ? e.message : "chain load failed");
      setChain(null);
    } finally {
      setLoadingChain(false);
    }
  }, []);

  useEffect(() => {
    void loadChain("SPY");
  }, [loadChain]);

  useEffect(() => {
    if (!session?.user?.email) return;
    fetch("/api/strategies", { cache: "no-store" })
      .then((r) => r.json())
      .then((b) => setSaved(b.strategies ?? []))
      .catch(() => undefined);
  }, [session]);

  const spot = chain?.spot ?? null;
  const nowMs = Date.now();

  const analytics = useMemo(() => {
    if (legs.length === 0 || !spot) return null;
    const li = toLegInputs(legs, nowMs);
    const entry = strategyEntryCost(li);
    const profile = expirationProfile(li, spot, RISK_FREE);
    const greeks = strategyGreeks(li, spot, RISK_FREE);
    // POP vol: size-weighted leg IV; horizon: nearest leg expiration
    const wIv = li.reduce((s, l) => s + l.iv * l.quantity, 0) / li.reduce((s, l) => s + l.quantity, 0);
    const minT = Math.min(...li.map((l) => l.T));
    const pe = popAndExpectedValue(li, spot, RISK_FREE, wIv, Math.max(minT, 1 / 365));
    return { entry, profile, greeks, pop: pe?.pop ?? null, ev: pe?.ev ?? null };
  }, [legs, spot, nowMs]);

  function addLeg(c: ChainContract, side: "long" | "short") {
    if (!chain) return;
    if (legs.length >= 6) return;
    if (c.iv === null) return;
    const iv = c.iv;
    setLegs((cur) => [
      ...cur,
      {
        option_type: c.option_type,
        side,
        strike: c.strike,
        expiration: chain.expiration,
        quantity: 1,
        entry_price: side === "long" ? (c.ask > 0 ? c.ask : c.mid) : (c.bid > 0 ? c.bid : c.mid),
        iv,
      },
    ]);
  }

  function updateLeg(i: number, patch: Partial<StrategyLeg>) {
    setLegs((cur) => cur.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  }

  async function saveStrategy() {
    if (!chain || legs.length === 0) return;
    setSaveMsg(null);
    const res = await fetch("/api/strategies", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        underlying: chain.symbol,
        strategy_name: saveName.trim() || `${chain.symbol} ${legs.length}-leg`,
        legs,
        entry_cost: analytics?.entry ?? 0,
        notes: null,
      }),
    });
    const body = await res.json();
    if (!res.ok) {
      setSaveMsg(typeof body.error === "string" ? body.error : "save failed");
      return;
    }
    setSaved((cur) => [body.strategy, ...cur]);
    setSaveName("");
    setSaveMsg("Saved.");
  }

  async function runOptimizer() {
    if (!chain) return;
    setOptimizing(true);
    setOptError(null);
    setOptResults(null);
    try {
      const res = await fetch("/api/optimizer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: chain.symbol,
          expiration: chain.expiration,
          target_price: Number(targetPrice),
          target_date: targetDate,
          max_cost: Number(maxCost) || 5000,
          sort: optSort,
          scan_expirations: scanMulti ? (chain?.expirations ?? []).slice(0, 3) : [],
        }),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(
          typeof body.error === "string" ? body.error : "Optimizer failed — check target inputs."
        );
      }
      setOptResults(body.candidates as OptimizerCandidate[]);
      setOptMeta({
        evaluated: body.evaluated,
        caveat: body.assumptions.caveat,
        model: body.assumptions.pop_ev_model,
        scans: body.expirations_scanned ?? [],
      });
    } catch (e) {
      setOptError(e instanceof Error ? e.message : "optimizer failed");
    } finally {
      setOptimizing(false);
    }
  }

  // Chain table rows near the money
  const nearMoney = useMemo(() => {
    if (!chain || !spot) return [];
    const strikes = [...new Set(chain.contracts.map((c) => c.strike))].sort((a, b) => a - b);
    const near = strikes
      .map((k) => ({ k, d: Math.abs(k - spot) }))
      .sort((a, b) => a.d - b.d)
      .slice(0, 16)
      .map((x) => x.k)
      .sort((a, b) => a - b);
    return near.map((k) => ({
      strike: k,
      call: chain.contracts.find((c) => c.strike === k && c.option_type === "call") ?? null,
      put: chain.contracts.find((c) => c.strike === k && c.option_type === "put") ?? null,
    }));
  }, [chain, spot]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-lg font-bold tracking-tight">Options Calculator</h1>
          <p className="mt-1 text-xs text-muted">
            Black-Scholes P/L modeling, position greeks, probability of profit, and a defined-risk optimizer.
            Model outputs, not predictions.
          </p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const s = symbolInput.toUpperCase().trim();
            if (s) {
              setLegs([]);
              void loadChain(s);
            }
          }}
          className="flex items-center gap-2"
        >
          {QUICK.map((s) => (
            <button
              type="button"
              key={s}
              onClick={() => {
                setSymbolInput(s);
                setLegs([]);
                void loadChain(s);
              }}
              className={`rounded px-2 py-1 font-display text-[11px] font-semibold ${
                chain?.symbol === s ? "bg-amber-dim text-amber" : "text-muted hover:text-bright"
              }`}
            >
              {s}
            </button>
          ))}
          <input
            value={symbolInput}
            onChange={(e) => setSymbolInput(e.target.value.toUpperCase())}
            className="w-24 rounded border border-line bg-ink-900 px-2 py-1 text-xs outline-none focus:border-amber"
            maxLength={6}
            aria-label="Symbol"
          />
          <button type="submit" className="rounded bg-ink-800 px-3 py-1 font-display text-xs font-semibold hover:bg-ink-700">
            Load
          </button>
        </form>
      </div>

      {chainError && (
        <div className="panel mb-4 px-4 py-3 text-xs text-bear">
          {chainError}
          {chainError.includes("TRADIER") && (
            <span className="text-muted"> — set TRADIER_API_KEY in the web app environment.</span>
          )}
        </div>
      )}

      {chain && (
        <div className="mb-3 flex flex-wrap items-center gap-3 text-xs">
          <span className="font-display text-base font-bold">{chain.symbol}</span>
          {spot && <span>spot <span className="font-bold text-amber">{spot.toFixed(2)}</span></span>}
          <FreshnessBadge freshness={chain.freshness} />
          <span className="eyebrow ml-2">Expiration</span>
          <select
            value={chain.expiration}
            onChange={(e) => {
              setLegs([]);
              void loadChain(chain.symbol, e.target.value);
            }}
            className="rounded border border-line bg-ink-900 px-2 py-1 text-xs outline-none focus:border-amber"
          >
            {chain.expirations.map((x) => (
              <option key={x} value={x}>
                {x}
              </option>
            ))}
          </select>
          {loadingChain && <span className="text-muted">loading…</span>}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        {/* Chain + leg builder */}
        <section className="panel overflow-hidden xl:col-span-5">
          <div className="border-b border-line px-3 py-2">
            <span className="eyebrow">Chain · near the money · click bid to sell, ask to buy</span>
          </div>
          <table className="w-full text-right text-[11px]">
            <thead>
              <tr className="border-b border-line text-[9px] uppercase tracking-wider text-muted">
                <th className="px-2 py-1.5">C IV</th>
                <th className="px-2 py-1.5">C Bid</th>
                <th className="px-2 py-1.5">C Ask</th>
                <th className="px-2 py-1.5 text-center">Strike</th>
                <th className="px-2 py-1.5">P Bid</th>
                <th className="px-2 py-1.5">P Ask</th>
                <th className="px-2 py-1.5">P IV</th>
              </tr>
            </thead>
            <tbody>
              {nearMoney.map((r) => {
                const atm = spot && Math.abs(r.strike - spot) === Math.min(...nearMoney.map((x) => Math.abs(x.strike - (spot ?? 0))));
                return (
                  <tr key={r.strike} className={`border-b border-line/50 ${atm ? "bg-ink-850" : ""}`}>
                    <td className="px-2 py-1 text-muted">{r.call?.iv ? `${(r.call.iv * 100).toFixed(0)}%` : "—"}</td>
                    <td className="px-2 py-1">
                      {r.call && r.call.bid > 0 ? (
                        <button onClick={() => addLeg(r.call!, "short")} className="text-bear hover:underline" title="Sell call (short)">
                          {r.call.bid.toFixed(2)}
                        </button>
                      ) : "—"}
                    </td>
                    <td className="px-2 py-1">
                      {r.call && r.call.ask > 0 ? (
                        <button onClick={() => addLeg(r.call!, "long")} className="text-bull hover:underline" title="Buy call (long)">
                          {r.call.ask.toFixed(2)}
                        </button>
                      ) : "—"}
                    </td>
                    <td className="px-2 py-1 text-center font-display font-bold">{r.strike}</td>
                    <td className="px-2 py-1">
                      {r.put && r.put.bid > 0 ? (
                        <button onClick={() => addLeg(r.put!, "short")} className="text-bear hover:underline" title="Sell put (short)">
                          {r.put.bid.toFixed(2)}
                        </button>
                      ) : "—"}
                    </td>
                    <td className="px-2 py-1">
                      {r.put && r.put.ask > 0 ? (
                        <button onClick={() => addLeg(r.put!, "long")} className="text-bull hover:underline" title="Buy put (long)">
                          {r.put.ask.toFixed(2)}
                        </button>
                      ) : "—"}
                    </td>
                    <td className="px-2 py-1 text-muted">{r.put?.iv ? `${(r.put.iv * 100).toFixed(0)}%` : "—"}</td>
                  </tr>
                );
              })}
              {nearMoney.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-muted">
                    {loadingChain ? "Loading chain…" : "No tradeable contracts."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* Legs */}
          <div className="border-t border-line px-3 py-2">
            <span className="eyebrow">Position legs ({legs.length}/6)</span>
          </div>
          {legs.length === 0 && <div className="px-3 py-4 text-center text-xs text-muted">No legs yet.</div>}
          <ul>
            {legs.map((l, i) => (
              <li key={i} className="flex items-center gap-2 border-b border-line/50 px-3 py-2 text-[11px]">
                <span className={`w-12 font-display font-bold ${l.side === "long" ? "text-bull" : "text-bear"}`}>
                  {l.side === "long" ? "LONG" : "SHORT"}
                </span>
                <span className="w-20">{l.strike}{l.option_type === "call" ? "C" : "P"}</span>
                <span className="w-20 text-muted">{l.expiration.slice(5)}</span>
                <label className="flex items-center gap-1">
                  <span className="text-muted">qty</span>
                  <input
                    type="number"
                    min={1}
                    max={1000}
                    value={l.quantity}
                    onChange={(e) => updateLeg(i, { quantity: Math.max(1, Number(e.target.value)) })}
                    className="w-14 rounded border border-line bg-ink-950 px-1 py-0.5 text-right outline-none focus:border-amber"
                  />
                </label>
                <label className="flex items-center gap-1">
                  <span className="text-muted">px</span>
                  <input
                    type="number"
                    step={0.01}
                    min={0}
                    value={l.entry_price}
                    onChange={(e) => updateLeg(i, { entry_price: Math.max(0, Number(e.target.value)) })}
                    className="w-16 rounded border border-line bg-ink-950 px-1 py-0.5 text-right outline-none focus:border-amber"
                  />
                </label>
                <span className="text-muted">IV {(l.iv * 100).toFixed(0)}%</span>
                <button onClick={() => setLegs((cur) => cur.filter((_, idx) => idx !== i))} className="ml-auto text-muted hover:text-bear">
                  ✕
                </button>
              </li>
            ))}
          </ul>
        </section>

        {/* P/L + stats */}
        <section className="space-y-4 xl:col-span-7">
          <div className="panel p-4">
            <div className="mb-2 flex items-center justify-between">
              <span className="eyebrow">P/L profile</span>
              <span className="flex gap-3 text-[10px] text-muted">
                <span className="flex items-center gap-1"><span className="inline-block h-0.5 w-4 bg-bull" />at expiration</span>
                <span className="flex items-center gap-1"><span className="inline-block h-0.5 w-4 border-b border-dashed border-muted" />today (model)</span>
              </span>
            </div>
            {spot ? <PnLChart legs={legs} spot={spot} /> : <div className="py-10 text-center text-xs text-muted">No spot price.</div>}
          </div>

          {analytics && (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <div className="panel p-3">
                <div className="eyebrow">Net {analytics.entry >= 0 ? "debit" : "credit"}</div>
                <div className="mt-1 font-display text-base font-bold">{fmtUsd(Math.abs(analytics.entry))}</div>
              </div>
              <div className="panel p-3">
                <div className="eyebrow">Max profit / loss</div>
                <div className="mt-1 text-xs">
                  <span className="text-bull">{analytics.profile.maxProfit === null ? "Unbounded" : fmtUsd(analytics.profile.maxProfit)}</span>
                  {" / "}
                  <span className="text-bear">{analytics.profile.maxLoss === null ? "Unbounded" : fmtUsd(analytics.profile.maxLoss)}</span>
                </div>
                <div className="mt-0.5 text-[10px] text-muted">
                  BE: {analytics.profile.breakevens.length > 0 ? analytics.profile.breakevens.join(" · ") : "—"}
                </div>
              </div>
              <div className="panel p-3">
                <div className="eyebrow">POP / expected value*</div>
                <div className="mt-1 font-display text-base font-bold">
                  {analytics.pop !== null ? `${(analytics.pop * 100).toFixed(1)}%` : "—"}
                  <span className={`ml-2 text-xs ${analytics.ev !== null && analytics.ev >= 0 ? "text-bull" : "text-bear"}`}>
                    {analytics.ev !== null ? `EV ${analytics.ev >= 0 ? "+" : "−"}$${Math.abs(analytics.ev).toFixed(0)}` : ""}
                  </span>
                </div>
                <div className="mt-0.5 text-[10px] text-muted">*lognormal at expiration, no skew</div>
              </div>
              <div className="panel p-3">
                <div className="eyebrow">Position greeks</div>
                <div className="mt-1 grid grid-cols-2 gap-x-2 text-[10px]">
                  <span>Δ {analytics.greeks.delta.toFixed(1)}</span>
                  <span>Γ {analytics.greeks.gamma.toFixed(2)}</span>
                  <span>Θ {fmtUsd(analytics.greeks.theta)}/d</span>
                  <span>V {fmtUsd(analytics.greeks.vega)}</span>
                </div>
              </div>
            </div>
          )}

          {/* Save */}
          {legs.length > 0 && (
            <div className="panel flex items-center gap-2 p-3">
              {session ? (
                <>
                  <input
                    value={saveName}
                    onChange={(e) => setSaveName(e.target.value)}
                    placeholder="Strategy name"
                    className="flex-1 rounded border border-line bg-ink-950 px-2 py-1.5 text-xs outline-none focus:border-amber"
                    maxLength={80}
                  />
                  <button onClick={() => void saveStrategy()} className="rounded bg-amber px-4 py-1.5 font-display text-xs font-bold text-ink-950 hover:bg-amber/90">
                    Save strategy
                  </button>
                  {saveMsg && <span className="text-[11px] text-muted">{saveMsg}</span>}
                </>
              ) : (
                <button onClick={() => signIn()} className="text-xs text-muted underline underline-offset-2 hover:text-bright">
                  Sign in to save strategies
                </button>
              )}
            </div>
          )}

          {/* Optimizer */}
          <div className="panel p-4">
            <div className="eyebrow mb-2">Optimizer · defined-risk only</div>
            <div className="flex flex-wrap items-end gap-3 text-xs">
              <label>
                <span className="mb-1 block text-muted">Target price</span>
                <input type="number" step={0.01} value={targetPrice} onChange={(e) => setTargetPrice(e.target.value)} placeholder={spot ? (spot * 1.03).toFixed(2) : ""} className="w-24 rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber" />
              </label>
              <label>
                <span className="mb-1 block text-muted">By date</span>
                <input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} max={chain?.expiration} className="rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber" />
              </label>
              <label>
                <span className="mb-1 block text-muted">Max risk ($)</span>
                <input type="number" min={100} step={100} value={maxCost} onChange={(e) => setMaxCost(e.target.value)} className="w-24 rounded border border-line bg-ink-950 px-2 py-1.5 outline-none focus:border-amber" />
              </label>
              <div>
                <span className="mb-1 block text-muted">Rank by</span>
                <div className="flex gap-1">
                  {(["ev", "roi"] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => setOptSort(m)}
                      className={`rounded px-2.5 py-1.5 font-display text-[11px] font-semibold ${
                        optSort === m ? "bg-amber-dim text-amber" : "text-muted hover:text-bright"
                      }`}
                      title={m === "ev" ? "Probability-weighted P/L — prices in the ways the target can miss" : "Return if target hits exactly — assumes the thesis is right"}
                    >
                      {m === "ev" ? "Expected value" : "ROI @ target"}
                    </button>
                  ))}
                </div>
              </div>
              <label className="flex items-center gap-1.5 pb-1.5">
                <input type="checkbox" checked={scanMulti} onChange={() => setScanMulti((v) => !v)} className="accent-amber" />
                <span className="text-muted">Scan 3 expirations</span>
              </label>
              <button
                onClick={() => void runOptimizer()}
                disabled={optimizing || !targetPrice || !targetDate}
                className="rounded bg-ink-800 px-4 py-1.5 font-display text-xs font-semibold hover:bg-ink-700 disabled:opacity-40"
              >
                {optimizing ? "Scanning…" : "Find strategies"}
              </button>
            </div>
            {optError && <p className="mt-2 text-xs text-bear">{optError}</p>}
            {optResults && (
              <>
                <table className="mt-3 w-full text-left text-[11px]">
                  <thead>
                    <tr className="border-b border-line text-[9px] uppercase tracking-wider text-muted">
                      <th className="py-1.5 pr-2">Strategy</th>
                      <th className="py-1.5 pr-2 text-right">Cost</th>
                      <th className="py-1.5 pr-2 text-right">@ Target</th>
                      <th className="py-1.5 pr-2 text-right">ROI</th>
                      <th className="py-1.5 pr-2 text-right">POP</th>
                      <th className="py-1.5 pr-2 text-right">EV</th>
                      <th className="py-1.5 pr-2 text-right">Max loss</th>
                      <th className="py-1.5" />
                    </tr>
                  </thead>
                  <tbody>
                    {optResults.map((c, i) => (
                      <tr key={i} className="border-b border-line/50 hover:bg-ink-850">
                        <td className="py-1.5 pr-2">{c.label}</td>
                        <td className="py-1.5 pr-2 text-right">{fmtUsd(c.net_cost)}</td>
                        <td className="py-1.5 pr-2 text-right text-bull">+{fmtUsd(c.profit_at_target)}</td>
                        <td className="py-1.5 pr-2 text-right font-bold">{(c.roi_at_target * 100).toFixed(0)}%</td>
                        <td className="py-1.5 pr-2 text-right text-muted">{c.pop !== null ? `${(c.pop * 100).toFixed(0)}%` : "—"}</td>
                        <td className={`py-1.5 pr-2 text-right ${c.expected_value !== null && c.expected_value >= 0 ? "text-bull" : "text-bear"}`}>
                          {c.expected_value !== null ? fmtUsd(c.expected_value) : "—"}
                        </td>
                        <td className="py-1.5 pr-2 text-right text-bear">{c.max_loss === null ? "∞" : fmtUsd(c.max_loss)}</td>
                        <td className="py-1.5 text-right">
                          <button onClick={() => setLegs(c.legs)} className="text-[10px] text-amber underline-offset-2 hover:underline">
                            Load →
                          </button>
                        </td>
                      </tr>
                    ))}
                    {optResults.length === 0 && (
                      <tr><td colSpan={8} className="py-6 text-center text-muted">Nothing profitable at that target within max risk. That is an answer, not an error.</td></tr>
                    )}
                  </tbody>
                </table>
                {optMeta && (
                  <div className="mt-2 space-y-1">
                    {optMeta.scans.length > 0 && (
                      <div className="flex flex-wrap gap-2 text-[10px]">
                        {optMeta.scans.map((sc) => (
                          <span key={sc.expiration} className="rounded bg-ink-900 px-2 py-1 text-muted">
                            {sc.expiration}
                            {sc.expected_move !== null && (
                              <span className="ml-1.5 text-amber">±{sc.expected_move.toFixed(2)} EM</span>
                            )}
                            <span className={`ml-1.5 ${sc.density_model === "market_implied" ? "text-bull" : "text-bear"}`}>
                              {sc.density_model === "market_implied" ? "implied density" : "lognormal fallback"}
                            </span>
                          </span>
                        ))}
                      </div>
                    )}
                    <p className="text-[10px] leading-relaxed text-muted">
                      {optMeta.evaluated} candidates · entries at ask/bid (spread paid) · {optMeta.model} · high ROI + low POP + negative EV = lottery ticket · {optMeta.caveat}
                    </p>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Saved strategies */}
          {session && saved.length > 0 && (
            <div className="panel overflow-hidden">
              <div className="border-b border-line px-3 py-2"><span className="eyebrow">Saved strategies</span></div>
              <ul>
                {saved.map((s) => (
                  <li key={s.id} className="flex items-center justify-between border-b border-line/50 px-3 py-2 text-xs">
                    <div>
                      <span className="font-display font-bold">{s.underlying}</span>
                      <span className="ml-2">{s.strategy_name}</span>
                      <span className="ml-2 text-muted">{s.legs.length} leg{s.legs.length > 1 ? "s" : ""} · {fmtUsd(Math.abs(s.entry_cost))} {s.entry_cost >= 0 ? "debit" : "credit"}</span>
                      {s.status === "closed" && <span className="ml-2 rounded bg-ink-800 px-1.5 py-0.5 text-[9px] uppercase text-muted">closed</span>}
                    </div>
                    <div className="flex gap-3">
                      <button
                        onClick={() => {
                          setLegs(s.legs);
                          if (s.underlying !== chain?.symbol) {
                            setSymbolInput(s.underlying);
                            void loadChain(s.underlying, s.legs[0]?.expiration);
                          }
                        }}
                        className="text-[11px] text-amber underline-offset-2 hover:underline"
                      >
                        Load
                      </button>
                      <button
                        onClick={async () => {
                          await fetch(`/api/strategies?id=${s.id}`, { method: "DELETE" });
                          setSaved((cur) => cur.filter((x) => x.id !== s.id));
                        }}
                        className="text-[11px] text-muted hover:text-bear"
                      >
                        Delete
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      </div>

      <p className="mt-4 text-[11px] leading-relaxed text-muted">
        All values are Black-Scholes model outputs under constant volatility and lognormal assumptions. The
        &ldquo;today&rdquo; curve holds each leg&rsquo;s chain IV fixed; real vols move with price and time. Probability
        of profit inherits every model assumption and ignores skew. None of this is a prediction or advice — it is
        arithmetic on stated assumptions.
      </p>
    </main>
  );
}
