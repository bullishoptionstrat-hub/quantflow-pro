import { NextRequest, NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

/**
 * FINRA ATS weekly aggregates. Response includes an explicit provenance
 * block so no consumer can mistake this for real-time prints.
 */
export async function GET(req: NextRequest) {
  const symbol = req.nextUrl.searchParams.get("symbol")?.toUpperCase();
  const db = supabaseAnon();

  let q = db.from("dark_pool_weekly").select("*").order("week_start", { ascending: false }).limit(300);
  if (symbol) q = q.eq("symbol", symbol);

  const { data, error } = await q;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({
    provenance: {
      source: "FINRA ATS Transparency Data",
      granularity: "weekly per-symbol aggregate",
      delay: "2–4 weeks (FINRA publication schedule)",
      note: "Real-time dark pool prints are not available from any free source.",
    },
    rows: data,
  });
}
