import { NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

export async function GET() {
  const db = supabaseAnon();
  const startOfDayET = new Date();
  // midnight ET expressed in UTC
  const et = new Date(startOfDayET.toLocaleString("en-US", { timeZone: "America/New_York" }));
  const offsetMs = startOfDayET.getTime() - et.getTime();
  const midnightET = new Date(et.getFullYear(), et.getMonth(), et.getDate()).getTime() + offsetMs;

  const { data, error } = await db
    .from("options_flow")
    .select("*")
    .eq("is_unusual", true)
    .gte("created_at", new Date(midnightET).toISOString())
    .order("created_at", { ascending: false })
    .limit(200);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ events: data });
}
