import { NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

/**
 * SSE stream of new flow events via Supabase Realtime.
 * Note: the primary realtime path is the Socket.IO relay (lower latency,
 * single Tradier session). This SSE route exists per spec for clients that
 * can't hold a Socket.IO connection. Vercel serverless caps function
 * duration; on Hobby this stream ends after the platform limit and the
 * client should auto-reconnect (EventSource does this natively).
 */
export async function GET() {
  const db = supabaseAnon();
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      // initial snapshot: last 100
      const { data } = await db
        .from("options_flow")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);
      controller.enqueue(encoder.encode(`event: snapshot\ndata: ${JSON.stringify(data ?? [])}\n\n`));

      const channel = db
        .channel("flow-sse")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "options_flow" }, (payload) => {
          controller.enqueue(encoder.encode(`event: flow\ndata: ${JSON.stringify(payload.new)}\n\n`));
        })
        .subscribe();

      const keepalive = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: keepalive\n\n`));
        } catch {
          clearInterval(keepalive);
        }
      }, 15_000);

      // Vercel will terminate the function; clean up on cancel
      const cleanup = () => {
        clearInterval(keepalive);
        void db.removeChannel(channel);
      };
      // @ts-expect-error attach for cancel()
      controller._cleanup = cleanup;
    },
    cancel() {
      // @ts-expect-error see start()
      this._cleanup?.();
    },
  });

  return new NextResponse(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
