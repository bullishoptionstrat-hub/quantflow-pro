import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

const Query = z.object({
  limit: z.coerce.number().min(1).max(500).default(100),
  offset: z.coerce.number().min(0).default(0),
  underlying: z.string().toUpperCase().optional(),
  order_type: z.enum(["SWEEP", "BLOCK", "SPLIT"]).optional(),
  sentiment: z.enum(["BULLISH", "BEARISH", "NEUTRAL"]).optional(),
  min_premium: z.coerce.number().min(0).optional(),
  unusual: z.coerce.boolean().optional(),
});

export async function GET(req: NextRequest) {
  const parsed = Query.safeParse(Object.fromEntries(req.nextUrl.searchParams));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const q = parsed.data;
  const db = supabaseAnon();

  let query = db
    .from("options_flow")
    .select("*")
    .order("created_at", { ascending: false })
    .range(q.offset, q.offset + q.limit - 1);

  if (q.underlying) query = query.eq("underlying", q.underlying);
  if (q.order_type) query = query.eq("order_type", q.order_type);
  if (q.sentiment) query = query.eq("sentiment", q.sentiment);
  if (q.min_premium) query = query.gte("total_premium", q.min_premium);
  if (q.unusual) query = query.eq("is_unusual", true);

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ events: data, limit: q.limit, offset: q.offset });
}
