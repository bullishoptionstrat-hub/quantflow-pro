import { NextRequest, NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

interface ScreenerRow {
  underlying: string;
  total_premium: number;
  unusual_count: number;
  net_flow: number;
  event_count: number;
  spark: number[]; // hourly net flow buckets for sparkline
}

export async function GET(req: NextRequest) {
  const sort = req.nextUrl.searchParams.get("sort") ?? "total_premium";
  const minPremium = Number(req.nextUrl.searchParams.get("min_premium") ?? 0);
  const db = supabaseAnon();

  const since = new Date();
  since.setUTCHours(0, 0, 0, 0);

  const { data, error } = await db
    .from("options_flow")
    .select("underlying,sentiment,total_premium,is_unusual,created_at")
    .gte("created_at", since.toISOString())
    .gte("total_premium", minPremium)
    .limit(20000);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const map = new Map<string, ScreenerRow>();
  for (const row of data ?? []) {
    const cur =
      map.get(row.underlying) ??
      { underlying: row.underlying, total_premium: 0, unusual_count: 0, net_flow: 0, event_count: 0, spark: new Array(24).fill(0) };
    const p = Number(row.total_premium);
    cur.total_premium += p;
    cur.event_count++;
    if (row.is_unusual) cur.unusual_count++;
    const signed = row.sentiment === "BULLISH" ? p : row.sentiment === "BEARISH" ? -p : 0;
    cur.net_flow += signed;
    const hour = new Date(row.created_at).getUTCHours();
    cur.spark[hour] += signed;
    map.set(row.underlying, cur);
  }

  const rows = [...map.values()];
  const key = (sort === "unusual_count" || sort === "net_flow" ? sort : "total_premium") as keyof Pick<
    ScreenerRow,
    "total_premium" | "unusual_count" | "net_flow"
  >;
  rows.sort((a, b) => Math.abs(b[key]) - Math.abs(a[key]));

  return NextResponse.json({ rows: rows.slice(0, 50), sort: key });
}
