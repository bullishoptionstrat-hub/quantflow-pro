import { NextRequest, NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

/**
 * Returns flow-derived price levels plus daily candles for the chart.
 * Candles come from Tradier /markets/history (server-side; key never reaches
 * the browser). If TRADIER_API_KEY isn't set in the web env, levels still
 * return and candles come back empty — the UI states this plainly.
 */
export async function GET(_req: NextRequest, { params }: { params: { symbol: string } }) {
  const symbol = params.symbol.toUpperCase();
  const db = supabaseAnon();

  const { data: levels, error } = await db
    .from("flow_levels")
    .select("*")
    .eq("symbol", symbol)
    .order("total_volume", { ascending: false })
    .limit(15);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  let candles: { time: string; open: number; high: number; low: number; close: number }[] = [];
  const key = process.env.TRADIER_API_KEY;
  if (key) {
    try {
      const base =
        process.env.TRADIER_ENV === "production"
          ? "https://api.tradier.com/v1"
          : "https://sandbox.tradier.com/v1";
      const start = new Date(Date.now() - 90 * 86_400_000).toISOString().slice(0, 10);
      const end = new Date().toISOString().slice(0, 10);
      const res = await fetch(
        `${base}/markets/history?symbol=${symbol}&interval=daily&start=${start}&end=${end}`,
        { headers: { Authorization: `Bearer ${key}`, Accept: "application/json" }, next: { revalidate: 300 } }
      );
      if (res.ok) {
        const body = (await res.json()) as {
          history?: { day?: { date: string; open: number; high: number; low: number; close: number }[] | { date: string; open: number; high: number; low: number; close: number } };
        };
        const days = body.history?.day;
        const arr = Array.isArray(days) ? days : days ? [days] : [];
        candles = arr.map((d) => ({ time: d.date, open: d.open, high: d.high, low: d.low, close: d.close }));
      }
    } catch {
      // candles stay empty; UI handles it
    }
  }

  return NextResponse.json({ symbol, levels: levels ?? [], candles });
}
