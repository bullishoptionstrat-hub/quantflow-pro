import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { supabaseService } from "@/lib/supabase";

export const dynamic = "force-dynamic";

const RuleSchema = z.object({
  underlying: z.string().toUpperCase().min(1).max(6).nullable(),
  min_premium: z.number().min(0),
  order_types: z.array(z.enum(["SWEEP", "BLOCK", "SPLIT"])).default([]),
  sentiments: z.array(z.enum(["BULLISH", "BEARISH", "NEUTRAL"])).default([]),
  unusual_only: z.boolean().default(false),
  webhook_url: z
    .string()
    .url()
    .refine(
      (u) => u.startsWith("https://discord.com/api/webhooks/") || u.startsWith("https://api.telegram.org/"),
      "Only Discord or Telegram webhook URLs are accepted"
    )
    .nullable(),
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Sign in to create alert rules." }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = RuleSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const db = supabaseService();
  const { data, error } = await db
    .from("alert_rules")
    .insert({ ...parsed.data, user_email: session.user.email })
    .select()
    .single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ rule: data }, { status: 201 });
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ rules: [], log: [] });

  const db = supabaseService();
  const [{ data: rules }, { data: log }] = await Promise.all([
    db.from("alert_rules").select("*").eq("user_email", session.user.email).order("created_at", { ascending: false }),
    db
      .from("alert_log")
      .select("*, alert_rules!inner(user_email)")
      .eq("alert_rules.user_email", session.user.email)
      .order("created_at", { ascending: false })
      .limit(100),
  ]);
  return NextResponse.json({ rules: rules ?? [], log: log ?? [] });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const db = supabaseService();
  const { error } = await db.from("alert_rules").delete().eq("id", id).eq("user_email", session.user.email);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
