import { NextRequest, NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";

export const dynamic = "force-dynamic";

/**
 * Net dealer gamma exposure per strike, computed hourly by the ingest service
 * from Tradier chains (greeks=true → ORATS, ~hourly refresh).
 * Provenance block included so nobody mistakes this for tick-level data, and
 * because the dealer-positioning convention (short calls / long puts) is a
 * heuristic — true dealer books are unobservable.
 */
export async function GET(_req: NextRequest, { params }: { params: { symbol: string } }) {
  const underlying = params.symbol.toUpperCase();
  const db = supabaseAnon();

  const { data, error } = await db
    .from("gex_levels")
    .select("*")
    .eq("underlying", underlying)
    .order("strike", { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  return NextResponse.json({
    underlying,
    provenance: {
      source: "Tradier option chains, greeks=true (ORATS-computed)",
      refresh: "~hourly (ORATS schedule); recomputed hourly by ingest",
      convention:
        "GEX = gamma × OI × 100 × spot² × 1%, calls positive / puts negative (dealer short-call long-put heuristic — actual dealer positioning is unobservable)",
      note: "Positioning context, not a real-time signal.",
    },
    levels: data ?? [],
    computed_at: data?.[0]?.computed_at ?? null,
  });
}
