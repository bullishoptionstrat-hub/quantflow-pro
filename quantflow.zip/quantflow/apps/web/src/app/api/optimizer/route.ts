import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import type { OptimizerCandidate, StrategyLeg } from "@quantflow/shared";
import { fetchChain, TradierError, type ChainContract, type ChainResult } from "@/lib/tradier-server";
import {
  blackScholes,
  buildSmile,
  impliedVolatility,
  marketImpliedPopEv,
  popAndExpectedValue,
  type LegInput,
} from "@/lib/blackScholes";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

/**
 * Strategy optimizer v3.
 *
 * Given a target price + date, enumerates defined-risk structures (single-leg
 * longs, debit verticals, credit verticals, long butterflies) across one or
 * more expirations, values each at target, and ranks by expected value or ROI.
 *
 * POP/EV model, in order of preference:
 * 1. MARKET-IMPLIED DENSITY (Breeden–Litzenberger): the risk-neutral
 *    distribution recovered from the chain's own smile — skew priced in.
 *    EV under this density measures edge vs. the market's consensus, so a
 *    fairly-priced structure shows EV ≈ −spread, not fake "cheapness".
 * 2. Lognormal at ATM IV — fallback only when the smile is too sparse or the
 *    recovered density loses mass. The response says which model ran.
 *
 * Honesty constraints, in order of importance:
 * 1. Entry at the ASK for buys, BID for sells — the spread is paid up front.
 * 2. IV held constant to target date for value-at-target; results are a model
 *    ranking under stated assumptions, not predictions.
 * 3. No quote, no OI, no trade: dead contracts are excluded.
 * 4. Defined risk only. Naked shorts are not enumerated.
 */

const ReqSchema = z.object({
  symbol: z.string().toUpperCase().min(1).max(6),
  expiration: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  target_price: z.number().positive(),
  target_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  max_cost: z.number().positive().max(1_000_000).default(10_000),
  sort: z.enum(["ev", "roi"]).default("ev"),
  /** Additional expirations to scan (the primary is always included). Max 3 total. */
  scan_expirations: z.array(z.string().regex(/^\d{4}-\d{2}-\d{2}$/)).max(3).default([]),
});

const RISK_FREE = Number(process.env.RISK_FREE_RATE ?? 0.05);
const YEAR_MS = 365.25 * 86_400_000;

function yearsBetween(fromMs: number, toIso: string): number {
  return Math.max(0, (new Date(toIso + "T16:00:00-05:00").getTime() - fromMs) / YEAR_MS);
}

function legToInput(leg: StrategyLeg, atMs: number): LegInput {
  return {
    option_type: leg.option_type,
    side: leg.side,
    strike: leg.strike,
    quantity: leg.quantity,
    entry_price: leg.entry_price,
    iv: leg.iv,
    T: yearsBetween(atMs, leg.expiration),
  };
}

function valueAt(legs: StrategyLeg[], S: number, atMs: number): number {
  let v = 0;
  for (const leg of legs) {
    const li = legToInput(leg, atMs);
    const { price } = blackScholes(li.option_type, {
      S,
      K: li.strike,
      T: li.T,
      r: RISK_FREE,
      sigma: li.iv,
    });
    v += (li.side === "long" ? 1 : -1) * price * li.quantity * 100;
  }
  return v;
}

interface ExpirationScan {
  expiration: string;
  contracts_tradeable: number;
  iv_backfilled: number;
  expected_move: number | null; // ATM straddle mid, dollars of underlying
  density_model: "market_implied" | "lognormal_fallback";
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = ReqSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { symbol, expiration, target_price, target_date, max_cost, sort, scan_expirations } =
    parsed.data;

  if (target_date > expiration && scan_expirations.length === 0) {
    return NextResponse.json({ error: "target_date must be on or before expiration" }, { status: 400 });
  }

  const nowMs = Date.now();
  const targetMs = new Date(target_date + "T16:00:00-05:00").getTime();
  if (targetMs <= nowMs) {
    return NextResponse.json({ error: "target_date must be in the future" }, { status: 400 });
  }

  const expirations = [...new Set([expiration, ...scan_expirations])].slice(0, 3);

  const candidates: OptimizerCandidate[] = [];
  const scans: ExpirationScan[] = [];
  let spotOut: number | null = null;
  let freshness: "REALTIME" | "DELAYED" = "DELAYED";

  for (const exp of expirations) {
    if (target_date > exp) continue; // can't target past this expiry

    let chain: ChainResult;
    try {
      chain = await fetchChain(symbol, exp);
    } catch (err) {
      if (err instanceof TradierError && expirations.length === 1) {
        return NextResponse.json({ error: err.message }, { status: err.status });
      }
      continue; // multi-scan: skip a failing expiration, report what worked
    }
    if (chain.expiration !== exp) continue; // fetchChain fell back to a different expiry
    const spot = chain.spot;
    if (!spot || spot <= 0) continue;
    spotOut = spot;
    freshness = chain.freshness;

    const expT = yearsBetween(nowMs, exp);

    // IV backfill: a two-sided quote IS an implied vol — solve from the mid
    // instead of discarding the contract when ORATS greeks are missing.
    let ivBackfilled = 0;
    for (const c of chain.contracts) {
      if (c.iv === null && c.bid > 0 && c.ask > 0 && c.ask >= c.bid && expT > 0) {
        const solved = impliedVolatility(c.option_type, (c.bid + c.ask) / 2, {
          S: spot,
          K: c.strike,
          T: expT,
          r: RISK_FREE,
        });
        if (solved !== null && solved > 0.01 && solved < 5) {
          c.iv = Number(solved.toFixed(4));
          ivBackfilled++;
        }
      }
    }

    const tradeable = chain.contracts.filter(
      (c) =>
        c.bid > 0 &&
        c.ask > 0 &&
        c.ask >= c.bid &&
        c.open_interest > 0 &&
        c.iv !== null &&
        Math.abs(c.strike - spot) / spot <= 0.3
    );
    if (tradeable.length === 0) continue;

    // ---- Smile from OTM quotes (puts below spot, calls above — standard) ----
    const smilePoints = tradeable
      .filter((c) => (c.option_type === "put" ? c.strike <= spot : c.strike >= spot))
      .map((c) => ({ strike: c.strike, iv: c.iv as number }));
    const fwd = spot * Math.exp(RISK_FREE * expT);
    const smile = buildSmile(smilePoints, fwd);

    // ---- ATM sigma (lognormal fallback) + expected move (ATM straddle mid) ----
    const byDist = [...tradeable].sort((a, b) => Math.abs(a.strike - spot) - Math.abs(b.strike - spot));
    const atmIvs = byDist.slice(0, 4).map((c) => c.iv as number);
    const atmSigma = atmIvs.length ? atmIvs.reduce((a, b) => a + b, 0) / atmIvs.length : null;

    const atmStrike = byDist[0]?.strike ?? null;
    const atmCall = tradeable.find((c) => c.strike === atmStrike && c.option_type === "call");
    const atmPut = tradeable.find((c) => c.strike === atmStrike && c.option_type === "put");
    const expectedMove =
      atmCall && atmPut ? Number((atmCall.mid + atmPut.mid).toFixed(2)) : null;

    // Probe the density once; if it fails, the whole expiration falls back.
    const probe =
      smile &&
      marketImpliedPopEv(
        [{ option_type: "call", side: "long", strike: spot, quantity: 1, entry_price: 1, iv: atmSigma ?? 0.2, T: expT }],
        spot,
        RISK_FREE,
        Math.max(expT, 1 / 365),
        smile
      );
    const useDensity = Boolean(smile && probe);

    scans.push({
      expiration: exp,
      contracts_tradeable: tradeable.length,
      iv_backfilled: ivBackfilled,
      expected_move: expectedMove,
      density_model: useDensity ? "market_implied" : "lognormal_fallback",
    });

    const calls = tradeable.filter((c) => c.option_type === "call").sort((a, b) => a.strike - b.strike);
    const puts = tradeable.filter((c) => c.option_type === "put").sort((a, b) => a.strike - b.strike);

    const mkLeg = (c: ChainContract, side: "long" | "short"): StrategyLeg => ({
      option_type: c.option_type,
      side,
      strike: c.strike,
      expiration: exp,
      quantity: 1,
      entry_price: side === "long" ? c.ask : c.bid, // spread paid up front
      iv: c.iv as number,
    });

    const evaluate = (
      label: string,
      legs: StrategyLeg[],
      maxLoss: number | null,
      breakeven: number | null
    ) => {
      const netCost = legs.reduce(
        (s, l) => s + (l.side === "long" ? 1 : -1) * l.entry_price * l.quantity * 100,
        0
      );
      const risk = maxLoss === null ? Math.abs(netCost) : Math.abs(maxLoss);
      if (risk <= 0 || risk > max_cost) return;
      const valueAtTarget = valueAt(legs, target_price, targetMs);
      const profit = valueAtTarget - netCost;
      if (profit <= 0) return; // losers at their own target are noise

      // Quote-anomaly flag: when the executable debit is a small fraction of
      // the structure's model value RIGHT NOW, the quotes are stale or crossed
      // across strikes (common on DELAYED feeds with per-contract timestamps).
      // Real markets do not sell $3.50 of spread for $0.14 — flag, don't hide.
      const modelNow = valueAt(legs, spot, nowMs);
      const anomaly = netCost > 0 && modelNow > 0 && netCost < 0.4 * modelNow;

      const li = legs.map((l) => legToInput(l, nowMs));
      const horizon = Math.max(expT, 1 / 365);
      const pe = useDensity
        ? marketImpliedPopEv(li, spot, RISK_FREE, horizon, smile as (K: number) => number)
        : atmSigma
          ? popAndExpectedValue(li, spot, RISK_FREE, atmSigma, horizon)
          : null;

      candidates.push({
        label: anomaly ? `⚠ ${label}` : label,
        legs,
        net_cost: Number(netCost.toFixed(2)),
        value_at_target: Number(valueAtTarget.toFixed(2)),
        profit_at_target: Number(profit.toFixed(2)),
        roi_at_target: Number((profit / risk).toFixed(4)),
        pop: pe ? Number(pe.pop.toFixed(4)) : null,
        expected_value: pe ? Number(pe.ev.toFixed(2)) : null,
        max_loss: maxLoss === null ? -Math.abs(netCost) : maxLoss,
        breakeven,
      });
    };

    const bullish = target_price >= spot;

    // ---- Single-leg longs ----
    for (const c of bullish ? calls : puts) {
      const leg = mkLeg(c, "long");
      const be = c.option_type === "call" ? c.strike + c.ask : c.strike - c.ask;
      evaluate(
        `Long ${c.strike}${c.option_type === "call" ? "C" : "P"} ${exp}`,
        [leg],
        -c.ask * 100,
        Number(be.toFixed(2))
      );
    }

    // ---- Debit verticals ----
    const sideList = bullish ? calls : puts;
    for (let i = 0; i < sideList.length; i++) {
      for (let j = i + 1; j < sideList.length && j <= i + 12; j++) {
        const low = sideList[i];
        const high = sideList[j];
        const width = (high.strike - low.strike) * 100;
        if (bullish) {
          const legs = [mkLeg(low, "long"), mkLeg(high, "short")];
          const debit = (low.ask - high.bid) * 100;
          if (debit > 0 && debit < width) {
            evaluate(
              `Bull Call ${low.strike}/${high.strike} ${exp}`,
              legs,
              -debit,
              Number((low.strike + debit / 100).toFixed(2))
            );
          }
        } else {
          const legs = [mkLeg(high, "long"), mkLeg(low, "short")];
          const debit = (high.ask - low.bid) * 100;
          if (debit > 0 && debit < width) {
            evaluate(
              `Bear Put ${high.strike}/${low.strike} ${exp}`,
              legs,
              -debit,
              Number((high.strike - debit / 100).toFixed(2))
            );
          }
        }
      }
    }

    // ---- Long butterflies (body within 2% of target) ----
    {
      const list = bullish ? calls : puts;
      for (let i = 0; i < list.length; i++) {
        for (let step = 1; step <= 8; step++) {
          const j = i + step;
          const k = i + 2 * step;
          if (k >= list.length) break;
          const w1 = list[i];
          const bodyC = list[j];
          const w2 = list[k];
          if (Math.abs(bodyC.strike - w1.strike - (w2.strike - bodyC.strike)) > 1e-6) continue;
          if (Math.abs(bodyC.strike - target_price) / spot > 0.02) continue;
          const debit = (w1.ask - 2 * bodyC.bid + w2.ask) * 100;
          const width = (bodyC.strike - w1.strike) * 100;
          if (debit <= 0 || debit >= width) continue;
          const legs: StrategyLeg[] = [
            mkLeg(w1, "long"),
            { ...mkLeg(bodyC, "short"), quantity: 2 },
            mkLeg(w2, "long"),
          ];
          const cp = w1.option_type === "call" ? "Call" : "Put";
          evaluate(
            `${cp} Fly ${w1.strike}/${bodyC.strike}/${w2.strike} ${exp}`,
            legs,
            -debit,
            Number((w1.strike + debit / 100).toFixed(2))
          );
        }
      }
    }

    // ---- Credit verticals on the opposite side ----
    const oppList = bullish ? puts : calls;
    for (let i = 0; i < oppList.length; i++) {
      for (let j = i + 1; j < oppList.length && j <= i + 12; j++) {
        const low = oppList[i];
        const high = oppList[j];
        const width = (high.strike - low.strike) * 100;
        if (bullish) {
          const legs = [mkLeg(high, "short"), mkLeg(low, "long")];
          const credit = (high.bid - low.ask) * 100;
          if (credit > 0 && credit < width) {
            evaluate(
              `Bull Put Credit ${high.strike}/${low.strike} ${exp}`,
              legs,
              -(width - credit),
              Number((high.strike - credit / 100).toFixed(2))
            );
          }
        } else {
          const legs = [mkLeg(low, "short"), mkLeg(high, "long")];
          const credit = (low.bid - high.ask) * 100;
          if (credit > 0 && credit < width) {
            evaluate(
              `Bear Call Credit ${low.strike}/${high.strike} ${exp}`,
              legs,
              -(width - credit),
              Number((low.strike + credit / 100).toFixed(2))
            );
          }
        }
      }
    }
  }

  if (scans.length === 0) {
    return NextResponse.json(
      { error: "No usable expirations — check that target_date precedes the expirations scanned." },
      { status: 422 }
    );
  }

  candidates.sort((a, b) =>
    sort === "roi"
      ? b.roi_at_target - a.roi_at_target
      : (b.expected_value ?? -Infinity) - (a.expected_value ?? -Infinity)
  );

  const allDensity = scans.every((s) => s.density_model === "market_implied");

  return NextResponse.json({
    symbol,
    spot: spotOut,
    target_price,
    target_date,
    freshness,
    expirations_scanned: scans,
    assumptions: {
      pricing: "entry at ask (buys) / bid (sells) — spread paid up front",
      model: "Black-Scholes with per-leg chain IV held constant to target date (value-at-target)",
      universe:
        "defined-risk only: single-leg longs, debit verticals, credit verticals, long butterflies; ±30% strikes, OI > 0",
      pop_ev_model: allDensity
        ? "market-implied risk-neutral density (Breeden–Litzenberger from the chain's own smile) — skew priced in; EV measures edge vs. market consensus, so fairly-priced structures show EV ≈ −spread"
        : "MIXED/FALLBACK: lognormal at ATM IV on at least one expiration (smile too sparse). Flat-vol EV makes below-ATM-IV wings look cheap — uniformly positive EV there is skew vs. the model, not edge. See expirations_scanned[].density_model.",
      rate: RISK_FREE,
      caveat:
        "EV/POP are at-expiration model outputs, not predictions. ROI assumes the target hits exactly; EV prices in the ways it can miss. ⚠-flagged candidates price far below model value — stale/crossed quotes (expect these on DELAYED data), verify the fill is real before believing the numbers.",
      sorted_by: sort,
    },
    candidates: candidates.slice(0, 20),
    evaluated: candidates.length,
  });
}
