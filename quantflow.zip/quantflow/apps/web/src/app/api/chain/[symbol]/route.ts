import { NextRequest, NextResponse } from "next/server";
import { fetchChain, TradierError } from "@/lib/tradier-server";

export const dynamic = "force-dynamic";

/**
 * Options chain for the calculator/optimizer. Tradier server-side — the key
 * never reaches the browser. Returns expirations, spot, and per-contract
 * bid/ask/mid/IV for the requested expiration (defaults to nearest).
 * Sandbox tokens = DELAYED (~15 min), production = REALTIME; response says which.
 */
export async function GET(req: NextRequest, { params }: { params: { symbol: string } }) {
  try {
    const result = await fetchChain(params.symbol.toUpperCase(), req.nextUrl.searchParams.get("expiration"));
    return NextResponse.json(result);
  } catch (err) {
    if (err instanceof TradierError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    return NextResponse.json({ error: err instanceof Error ? err.message : "chain fetch failed" }, { status: 500 });
  }
}
