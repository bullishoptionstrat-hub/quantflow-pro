import { NextRequest, NextResponse } from "next/server";
import { supabaseAnon } from "@/lib/supabase";
import type { SymbolAnalytics, OptionType } from "@quantflow/shared";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, { params }: { params: { symbol: string } }) {
  const underlying = params.symbol.toUpperCase();
  const db = supabaseAnon();

  const since = new Date();
  since.setUTCHours(0, 0, 0, 0);

  const { data, error } = await db
    .from("options_flow")
    .select("sentiment,total_premium,strike,option_type,is_unusual")
    .eq("underlying", underlying)
    .gte("created_at", since.toISOString())
    .limit(5000);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  let bull = 0, bear = 0, total = 0, unusual = 0;
  const strikes = new Map<string, { strike: number; option_type: OptionType; premium: number }>();

  for (const row of data ?? []) {
    const p = Number(row.total_premium);
    total += p;
    if (row.sentiment === "BULLISH") bull += p;
    if (row.sentiment === "BEARISH") bear += p;
    if (row.is_unusual) unusual++;
    const key = `${row.strike}-${row.option_type}`;
    const cur = strikes.get(key) ?? { strike: Number(row.strike), option_type: row.option_type as OptionType, premium: 0 };
    cur.premium += p;
    strikes.set(key, cur);
  }

  const out: SymbolAnalytics = {
    underlying,
    bull_premium: bull,
    bear_premium: bear,
    net_flow: bull - bear,
    bull_bear_ratio: bear > 0 ? bull / bear : bull > 0 ? 99 : 1,
    total_premium: total,
    event_count: data?.length ?? 0,
    unusual_count: unusual,
    top_strikes: [...strikes.values()].sort((a, b) => b.premium - a.premium).slice(0, 8),
  };
  return NextResponse.json(out);
}
