import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { supabaseService } from "@/lib/supabase";

export const dynamic = "force-dynamic";

const LegSchema = z.object({
  option_type: z.enum(["call", "put"]),
  side: z.enum(["long", "short"]),
  strike: z.number().positive(),
  expiration: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  quantity: z.number().int().min(1).max(1000),
  entry_price: z.number().min(0),
  iv: z.number().min(0).max(10),
});

const StrategySchema = z.object({
  underlying: z.string().toUpperCase().min(1).max(6),
  strategy_name: z.string().min(1).max(80),
  legs: z.array(LegSchema).min(1).max(6),
  entry_cost: z.number(),
  notes: z.string().max(2000).nullable().default(null),
});

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Sign in to save strategies." }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const parsed = StrategySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const db = supabaseService();
  const { data, error } = await db
    .from("saved_strategies")
    .insert({ ...parsed.data, user_email: session.user.email })
    .select()
    .single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ strategy: data }, { status: 201 });
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ strategies: [] });

  const db = supabaseService();
  const { data, error } = await db
    .from("saved_strategies")
    .select("*")
    .eq("user_email", session.user.email)
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ strategies: data ?? [] });
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const body = await req.json().catch(() => null);
  const parsed = z.object({ status: z.enum(["open", "closed"]) }).safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const db = supabaseService();
  const { error } = await db
    .from("saved_strategies")
    .update({ status: parsed.data.status })
    .eq("id", id)
    .eq("user_email", session.user.email);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const db = supabaseService();
  const { error } = await db
    .from("saved_strategies")
    .delete()
    .eq("id", id)
    .eq("user_email", session.user.email);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}
