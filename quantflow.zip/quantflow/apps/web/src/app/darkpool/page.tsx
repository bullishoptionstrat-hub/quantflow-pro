"use client";

import { useEffect, useMemo, useState } from "react";
import type { DarkPoolWeeklyRow } from "@quantflow/shared";
import { fmtNum } from "@/lib/format";

interface Provenance {
  source: string;
  granularity: string;
  delay: string;
  note: string;
}

function fmtShares(v: number): string {
  if (v >= 1_000_000_000) return `${(v / 1_000_000_000).toFixed(2)}B`;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(0)}K`;
  return String(v);
}

export default function DarkPoolPage() {
  const [rows, setRows] = useState<DarkPoolWeeklyRow[]>([]);
  const [provenance, setProvenance] = useState<Provenance | null>(null);
  const [symbol, setSymbol] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    const url = symbol ? `/api/flow/darkpool?symbol=${encodeURIComponent(symbol)}` : "/api/flow/darkpool";
    fetch(url, { cache: "no-store" })
      .then(async (res) => {
        const body = (await res.json()) as { rows?: DarkPoolWeeklyRow[]; provenance?: Provenance; error?: string };
        if (!res.ok || body.error) throw new Error(body.error ?? `HTTP ${res.status}`);
        if (cancelled) return;
        setRows(body.rows ?? []);
        setProvenance(body.provenance ?? null);
      })
      .catch((e) => !cancelled && setError(e instanceof Error ? e.message : "Failed to load"))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [symbol]);

  // Aggregate latest week per symbol for the "share of ATS volume" bars.
  const latestWeek = useMemo(() => {
    if (rows.length === 0) return { week: null as string | null, perSymbol: [] as DarkPoolWeeklyRow[] };
    const week = rows.reduce((max, r) => (r.week_start > max ? r.week_start : max), rows[0].week_start);
    const perSymbol = rows.filter((r) => r.week_start === week).sort((a, b) => b.total_shares - a.total_shares);
    return { week, perSymbol };
  }, [rows]);

  const maxShares = Math.max(...latestWeek.perSymbol.map((r) => r.total_shares), 1);

  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-4">
        <h1 className="font-display text-lg font-bold tracking-tight">ATS (Dark Pool) Volume</h1>
        <p className="mt-1 text-xs text-muted">FINRA ATS Transparency Data · weekly per-symbol aggregates</p>
      </div>

      {/* Provenance banner — this is the page's first element on purpose. */}
      <div className="panel mb-4 border-amber/40 bg-amber-dim/40 px-4 py-3">
        <div className="eyebrow text-amber">Delayed — weekly aggregate</div>
        <p className="mt-1 text-xs leading-relaxed text-bright/90">
          {provenance?.note ??
            "Real-time dark pool prints are not available from any free source."}{" "}
          What you see here is {provenance?.granularity ?? "weekly per-symbol aggregate"} data published by FINRA with a{" "}
          {provenance?.delay ?? "2–4 week"} delay. There is no trade-by-trade print feed on this page, and any product
          claiming free real-time dark pool prints is mislabeling this same dataset.
        </p>
      </div>

      <div className="mb-4 flex items-center gap-2">
        <span className="eyebrow">Filter symbol</span>
        <input
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase().trim())}
          placeholder="e.g. SPY"
          className="w-28 rounded border border-line bg-ink-900 px-2 py-1 text-xs outline-none focus:border-amber"
          maxLength={6}
        />
        {symbol && (
          <button onClick={() => setSymbol("")} className="text-[11px] text-muted hover:text-bright">
            clear
          </button>
        )}
      </div>

      {error && <div className="panel mb-4 px-4 py-3 text-xs text-bear">{error}</div>}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Latest week share bars */}
        <section className="panel p-4 lg:col-span-5">
          <div className="eyebrow mb-3">
            Latest reported week {latestWeek.week ? `· ${latestWeek.week}` : ""}
          </div>
          {loading && <div className="py-8 text-center text-xs text-muted">Loading…</div>}
          {!loading && latestWeek.perSymbol.length === 0 && (
            <div className="py-8 text-center text-xs text-muted">
              No ATS rows synced yet. The ingest service syncs FINRA data every 6 hours — check the ingest logs if this
              stays empty.
            </div>
          )}
          <div className="space-y-2">
            {latestWeek.perSymbol.map((r) => (
              <div key={r.symbol}>
                <div className="mb-0.5 flex justify-between text-[11px]">
                  <span className="font-display font-bold">{r.symbol}</span>
                  <span className="text-muted">
                    {fmtShares(r.total_shares)} sh · {fmtNum(r.total_trades)} trades · {r.ats_count} ATSs
                  </span>
                </div>
                <div className="h-2 rounded bg-ink-800">
                  <div
                    className="h-2 rounded bg-amber/70"
                    style={{ width: `${Math.max((r.total_shares / maxShares) * 100, 2)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Weekly history table */}
        <section className="panel overflow-hidden lg:col-span-7">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-line text-[10px] uppercase tracking-wider text-muted">
                <th className="px-3 py-2">Week</th>
                <th className="px-3 py-2">Symbol</th>
                <th className="px-3 py-2 text-right">Total Shares</th>
                <th className="px-3 py-2 text-right">Trades</th>
                <th className="px-3 py-2 text-right">Avg Size</th>
                <th className="px-3 py-2 text-right">ATSs</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-line/60 hover:bg-ink-850">
                  <td className="px-3 py-2 text-muted">{r.week_start}</td>
                  <td className="px-3 py-2 font-display font-bold">{r.symbol}</td>
                  <td className="px-3 py-2 text-right">{fmtShares(r.total_shares)}</td>
                  <td className="px-3 py-2 text-right text-muted">{fmtNum(r.total_trades)}</td>
                  <td className="px-3 py-2 text-right text-muted">{fmtNum(Math.round(r.avg_trade_size))}</td>
                  <td className="px-3 py-2 text-right text-muted">{r.ats_count}</td>
                </tr>
              ))}
              {!loading && rows.length === 0 && !error && (
                <tr>
                  <td colSpan={6} className="px-3 py-10 text-center text-xs text-muted">
                    No data for this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>
      </div>

      <p className="mt-3 text-[11px] text-muted">
        Rising week-over-week ATS share with flat price is the classic off-exchange accumulation read — but at weekly
        granularity it&apos;s a positioning context tool, not an intraday signal. Don&apos;t treat it as one.
      </p>
    </main>
  );
}
