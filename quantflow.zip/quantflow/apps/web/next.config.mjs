/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ["@quantflow/shared"],
  reactStrictMode: true,
};
export default nextConfig;
