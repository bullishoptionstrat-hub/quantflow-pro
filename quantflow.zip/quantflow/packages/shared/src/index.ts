/**
 * @quantflow/shared — canonical type contracts.
 * Every service (web, ingest, ml) imports from here. Do not duplicate these shapes.
 */

export type OptionType = "call" | "put";
export type OrderType = "SWEEP" | "BLOCK" | "SPLIT";
export type Sentiment = "BULLISH" | "BEARISH" | "NEUTRAL";

/**
 * Data freshness is a first-class field. Nothing delayed is ever presented as live.
 * REALTIME  — Tradier production token, streaming session
 * DELAYED   — Tradier sandbox token or REST poll fallback (~15 min)
 * DEMO      — synthetic generator, development only, hard-disabled in production
 */
export type DataFreshness = "REALTIME" | "DELAYED" | "DEMO";

export interface RawTradeTick {
  symbol: string; // OCC option symbol e.g. TSLA260116C00300000
  underlying: string;
  strike: number;
  expiration: string; // ISO date
  optionType: OptionType;
  price: number;
  size: number;
  exchange: string;
  bid: number;
  ask: number;
  timestampMs: number;
}

export interface FlowEvent {
  id: string;
  created_at: string;
  symbol: string;
  underlying: string;
  strike: number;
  expiration: string;
  option_type: OptionType;
  order_type: OrderType;
  total_size: number;
  total_premium: number;
  avg_price: number;
  exchange_count: number;
  sentiment: Sentiment;
  is_unusual: boolean;
  /**
   * 0–100 fill-aggression score (InsiderFinance "Heat Score" analog).
   * Components: ask-side fill, multi-exchange sweep, premium magnitude,
   * spread displacement. In DELAYED (sandbox REST-poll) mode exchange
   * attribution is synthetic, so the multi-exchange component is muted —
   * treat DELAYED heat scores as directionally weaker.
   */
  heat_score: number;
  days_to_expiry: number;
  iv: number | null;
  underlying_price: number | null;
  otm_percentage: number | null;
  freshness: DataFreshness;
}

export interface DarkPoolWeeklyRow {
  id: string;
  created_at: string;
  symbol: string;
  week_start: string; // FINRA reporting week
  total_shares: number;
  total_trades: number;
  ats_count: number;
  avg_trade_size: number;
  source: "FINRA_ATS_WEEKLY"; // honest provenance — this is weekly aggregate, not prints
}

export interface FlowLevel {
  id: string;
  symbol: string;
  price_level: number;
  total_volume: number;
  level_type: "support" | "resistance" | "accumulation";
  last_updated: string;
}

/**
 * Net dealer gamma exposure at a strike.
 * GEX = gamma × OI × spot × 100 per contract leg; call side positive,
 * put side negative (dealer short calls / long puts convention).
 * Derived from Tradier option chains with greeks=true (ORATS-computed).
 * Greeks update on ORATS' schedule (~hourly), not tick-by-tick — GEX is a
 * positioning map, not a real-time signal.
 */
export interface GexLevel {
  id: string;
  computed_at: string;
  underlying: string;
  strike: number;
  net_gex: number;
  call_gex: number;
  put_gex: number;
  level_type: "wall" | "flip" | "support" | "resistance";
  spot_price: number;
  expirations_included: number;
  freshness: DataFreshness;
}

export interface StrategyLeg {
  option_type: OptionType;
  side: "long" | "short";
  strike: number;
  expiration: string; // ISO date
  quantity: number;
  /** premium per contract at entry (per share, e.g. 2.45) */
  entry_price: number;
  /** implied vol used for modeling, decimal (0.30 = 30%) */
  iv: number;
}

export interface SavedStrategy {
  id: string;
  user_email: string;
  created_at: string;
  underlying: string;
  strategy_name: string;
  legs: StrategyLeg[];
  entry_cost: number; // net debit (+) or credit (−), total dollars
  notes: string | null;
  status: "open" | "closed";
}

export interface OptimizerCandidate {
  label: string; // e.g. "Long 450C 2026-07-17", "Bull Call 450/460", "Call Fly 445/450/455"
  legs: StrategyLeg[];
  net_cost: number; // total dollars, debit positive
  value_at_target: number; // modeled value at target price/date
  profit_at_target: number;
  roi_at_target: number; // profit / |cost|
  /** Probability of profit at expiration — lognormal model, ATM IV, no skew. */
  pop: number | null;
  /**
   * Probability-weighted P/L at expiration (lognormal, risk-neutral drift).
   * The honesty stat: ROI-at-target assumes the thesis is right; EV prices in
   * all the ways it can be wrong. High-ROI/negative-EV = lottery ticket.
   */
  expected_value: number | null;
  max_loss: number | null; // null = undefined risk
  breakeven: number | null;
}

export interface PowerAlert {
  flow_event_id: string;
  underlying: string;
  score: number; // 0..1
  scoring_mode: "MODEL" | "HEURISTIC"; // HEURISTIC until model.pkl is trained — labeled, never hidden
  features: Record<string, number | string>;
  emitted_at: string;
}

export interface AlertRule {
  id: string;
  user_email: string;
  underlying: string | null; // null = all symbols
  min_premium: number;
  order_types: OrderType[];
  sentiments: Sentiment[];
  unusual_only: boolean;
  webhook_url: string | null; // Telegram/Discord
  created_at: string;
}

export interface FlowFilters {
  minPremium: number;
  orderTypes: OrderType[];
  sentiments: Sentiment[];
  unusualOnly: boolean;
  underlyings: string[]; // empty = all
}

export interface SymbolAnalytics {
  underlying: string;
  bull_premium: number;
  bear_premium: number;
  net_flow: number;
  bull_bear_ratio: number;
  total_premium: number;
  event_count: number;
  unusual_count: number;
  top_strikes: { strike: number; option_type: OptionType; premium: number }[];
}

/** Socket.IO event names — shared so client/server can't drift. */
export const WS_EVENTS = {
  FLOW_UPDATE: "flow_update",
  POWER_ALERT: "power_alert",
  FEED_STATUS: "feed_status",
} as const;

export interface FeedStatus {
  connected: boolean;
  freshness: DataFreshness;
  provider: "TRADIER_WS" | "TRADIER_REST_POLL" | "DEMO";
  last_event_at: string | null;
  message: string;
}

export function passesFilters(e: FlowEvent, f: FlowFilters): boolean {
  if (e.total_premium < f.minPremium) return false;
  if (f.orderTypes.length > 0 && !f.orderTypes.includes(e.order_type)) return false;
  if (f.sentiments.length > 0 && !f.sentiments.includes(e.sentiment)) return false;
  if (f.unusualOnly && !e.is_unusual) return false;
  if (f.underlyings.length > 0 && !f.underlyings.includes(e.underlying)) return false;
  return true;
}
