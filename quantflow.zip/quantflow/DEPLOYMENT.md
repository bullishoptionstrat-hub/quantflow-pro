# DEPLOYMENT — QuantFlow Terminal (free tier)

Order matters. Do these in sequence; each step's output feeds the next.

---

## 1. Supabase (database + realtime)

1. Create a project at supabase.com (free tier).
2. SQL Editor → run `supabase/migrations/0001_init.sql`, then `supabase/migrations/0002_v1_1.sql` (in that order).
3. Verify: Table Editor shows `options_flow` (with `heat_score`), `contract_volume_baseline`, `dark_pool_weekly`, `flow_levels`, `gex_levels`, `saved_strategies`, `alert_rules`, `alert_log`, `power_alerts`.
4. Collect from Project Settings → API:
   - Project URL → `SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_URL`
   - `anon` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (server-side only)

## 2. Upstash Redis

1. Create a database at upstash.com (free: 10k commands/day).
2. Collect REST URL + token → `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`.

Budget note: each grouped flow window costs a handful of commands. On a busy day a 10-symbol watchlist fits inside 10k/day in DELAYED mode; REALTIME streaming on volatile days can exceed it — if you hit the cap, trim `WATCHLIST` or upgrade.

## 3. Tradier

- **Development:** create a free developer sandbox account → sandbox token → `TRADIER_ENV=sandbox`. Data is delayed; everything gets stamped `DELAYED`. That is correct behavior, not a bug.
- **Real-time:** open and fund a Tradier brokerage account, generate a production token → `TRADIER_ENV=production`. Only then does the WebSocket stream open and events stamp `REALTIME`.
- Tradier allows **one** concurrent streaming session per account. Only the ingest service connects — never the browser, never a second instance. If you redeploy, the old session must die before the new one authenticates (the service handles reconnect/backoff).

## 4. Ingest service → Render

**Fast path:** `render.yaml` is in the repo root — Render → New → **Blueprint** → select the repo. It creates BOTH backend services (ingest + ML) and prompts for the secret env vars. Then skip to the keep-alive step below and §5's webhook setup.

**Manual path:**
1. Push the repo to GitHub.
2. Render → New Web Service → repo root.
   - Build command: `npm install && npm run build -w @quantflow/shared -w @quantflow/ingest`
   - Start command: `npm run start -w @quantflow/ingest`
   - Instance: Free.
3. Environment variables: `TRADIER_API_KEY`, `TRADIER_ENV`, `WATCHLIST`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`, `ML_WEBHOOK_SECRET`, `CORS_ORIGIN` (your Vercel URL, set after step 6), `PORT=4000`. **Do not set `DEMO_MODE`** — the service exits if it's true in production.
4. Verify: `https://YOUR-INGEST.onrender.com/health` returns JSON with provider + freshness.

### Keep-alive (mandatory)

Render free instances sleep after 15 min idle, which kills the Tradier session and the cron jobs. Create a free cron at cron-job.org: GET `https://YOUR-INGEST.onrender.com/health` every 10 minutes, 24/5 minimum (cron jobs for FINRA sync and baseline rolls also run off-hours — 24/7 is safer).

## 5. ML service → Render (second service)

1. Render → New Web Service → same repo.
   - Root directory: `services/ml`
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
2. Environment: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `INGEST_URL` (ingest Render URL), `ML_WEBHOOK_SECRET` (same value as ingest), `SCORE_THRESHOLD=0.72`, `TRADIER_API_KEY` (for train.py labels).
3. Verify: `/health` returns `{"mode": "HEURISTIC"}` until you train and commit/upload `model.pkl`.

### Supabase → ML webhook

Supabase Dashboard → Database → Webhooks → Create:
- Table: `options_flow` · Events: **INSERT**
- URL: `https://YOUR-ML.onrender.com/score`
- HTTP header: `x-webhook-secret: <ML_WEBHOOK_SECRET>`

This is what triggers scoring on every new flow row. Without it, power alerts never fire.

## 6. Web app → Vercel

1. Vercel → New Project → repo.
   - Root directory: `apps/web`
   - Framework preset: Next.js (defaults fine; `transpilePackages` already handles `@quantflow/shared`).
2. Environment variables: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_WS_URL` (ingest Render URL), `NEXTAUTH_SECRET` (`openssl rand -base64 32`), `NEXTAUTH_URL` (your Vercel URL), `TRADIER_API_KEY` + `TRADIER_ENV` (candle charts), optional `GITHUB_ID`/`GITHUB_SECRET`, optional `ADMIN_EMAIL`/`ADMIN_PASSWORD` (single-operator credential login — not for paying users).
3. Deploy, then go back to the ingest service and set `CORS_ORIGIN` to the Vercel URL. Redeploy ingest.

## 7. Smoke test (in order)

1. Ingest `/health` → connected, freshness as expected for your token tier.
2. Dashboard loads → FeedStatusBar shows REALTIME or DELAYED badge (never DEMO in prod).
3. Rows appear in `options_flow` (Supabase Table Editor) during market hours.
4. ML `/health` → HEURISTIC or MODEL; insert test passes through webhook (check ML logs for `/score` hits).
5. `/screener` populates after the first events; `/darkpool` populates after the first 6h FINRA sync; `/levels/SPY` shows candles + levels after the first hourly recompute.
6. Sign in on `/alerts`, create a Discord-webhook rule with a low threshold, confirm delivery + `alert_log` row.
7. `/calculator` loads a SPY chain (requires TRADIER_API_KEY on the web app); `/levels/SPY` shows the GEX panel after the first hourly recompute (~30s after ingest boot for the initial pass).

## Cost ceiling and failure modes

| Component | Free limit | What breaks first |
|---|---|---|
| Supabase | 500MB / 2 realtime concurrency tiers | flow table growth — prune rows older than ~90 days |
| Upstash | 10k commands/day | busy REALTIME days — trim watchlist |
| Render ×2 | 750 instance-hours/mo each | sleep without keep-alive cron |
| Vercel | 100GB bandwidth | fine at this scale |
| Concurrency | — | ~50 simultaneous users |

When you outgrow this: Render Starter ($7/mo) removes sleep; Supabase Pro removes the realtime ceiling. Those are the first two dollars worth spending.
