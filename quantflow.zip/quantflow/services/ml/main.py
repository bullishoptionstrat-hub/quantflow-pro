"""
QuantFlow Power Alerts — ML scoring microservice.

Receives new UNUSUAL flow events via Supabase Database Webhook (POST /score),
computes features, scores with a trained GradientBoostingClassifier if
model.pkl exists, otherwise falls back to a transparent rules heuristic.

Provenance is explicit: every alert carries scoring_mode = MODEL | HEURISTIC.
The heuristic is never presented as a trained model. Run train.py once you
have >= 90 days of flow history to replace it.

Run:  uvicorn main:app --host 0.0.0.0 --port 8000
"""

import os
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import httpx
import joblib
import numpy as np
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from supabase import create_client

from features import build_features, FEATURE_ORDER

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("quantflow-ml")

SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_SERVICE_ROLE_KEY = os.environ["SUPABASE_SERVICE_ROLE_KEY"]
INGEST_URL = os.environ.get("INGEST_URL", "")  # Socket.IO relay's HTTP base, for emit
WEBHOOK_SECRET = os.environ.get("ML_WEBHOOK_SECRET", "")
SCORE_THRESHOLD = float(os.environ.get("SCORE_THRESHOLD", "0.72"))
MODEL_PATH = Path(os.environ.get("MODEL_PATH", "model.pkl"))

db = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
app = FastAPI(title="QuantFlow Power Alerts", version="1.0.0")

_model = None
if MODEL_PATH.exists():
    _model = joblib.load(MODEL_PATH)
    log.info("model.pkl loaded — scoring_mode=MODEL")
else:
    log.warning("model.pkl not found — scoring_mode=HEURISTIC until train.py is run")


class FlowEventPayload(BaseModel):
    id: str
    underlying: str
    strike: float
    expiration: str
    option_type: str
    order_type: str
    total_size: int
    total_premium: float
    sentiment: str
    is_unusual: bool
    days_to_expiry: int
    otm_percentage: Optional[float] = None
    underlying_price: Optional[float] = None
    created_at: str
    freshness: str


def heuristic_score(features: dict[str, float]) -> float:
    """
    Transparent rules score, 0..1. Weights are stated, not learned:
      premium size 35%, sweep urgency 20%, short-dated conviction 15%,
      OTM aggressiveness 15%, sentiment/ratio alignment 15%.
    """
    s = 0.0
    s += 0.35 * min(features["log_premium"] / 7.0, 1.0)          # $10M caps it
    s += 0.20 * features["is_sweep"]
    s += 0.15 * (1.0 if features["days_to_expiry"] <= 7 else 0.5 if features["days_to_expiry"] <= 21 else 0.0)
    otm = features["otm_percentage"]
    s += 0.15 * (1.0 if 1.0 <= otm <= 8.0 else 0.4 if 0.0 <= otm < 1.0 else 0.0)
    s += 0.15 * min(max(features["cp_ratio_5d"] - 1.0, 0.0), 1.0)
    return round(min(s, 1.0), 4)


async def fetch_history(underlying: str) -> list[dict[str, Any]]:
    res = (
        db.table("options_flow")
        .select("option_type,total_premium,created_at")
        .eq("underlying", underlying)
        .gte("created_at", _days_ago_iso(30))
        .limit(5000)
        .execute()
    )
    return res.data or []


def _days_ago_iso(days: int) -> str:
    from datetime import timedelta
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "scoring_mode": "MODEL" if _model is not None else "HEURISTIC",
        "threshold": SCORE_THRESHOLD,
    }


@app.post("/score")
async def score(request: Request) -> dict[str, Any]:
    if WEBHOOK_SECRET and request.headers.get("x-webhook-secret") != WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="bad webhook secret")

    body = await request.json()
    # Supabase Database Webhook wraps the row in {"record": {...}, "type": "INSERT", ...}
    record = body.get("record", body)
    try:
        event = FlowEventPayload(**record)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"bad payload: {exc}")

    if not event.is_unusual:
        return {"scored": False, "reason": "not unusual"}
    if event.freshness == "DEMO":
        return {"scored": False, "reason": "demo data — never scored or alerted"}

    history = await fetch_history(event.underlying)
    features = build_features(event.model_dump(), history)

    if _model is not None:
        x = np.array([[features[k] for k in FEATURE_ORDER]])
        prob = float(_model.predict_proba(x)[0][1])
        mode = "MODEL"
    else:
        prob = heuristic_score(features)
        mode = "HEURISTIC"

    alert_fired = prob > SCORE_THRESHOLD
    if alert_fired:
        row = {
            "flow_event_id": event.id,
            "underlying": event.underlying,
            "score": prob,
            "scoring_mode": mode,
            "features": features,
        }
        db.table("power_alerts").insert(row).execute()

        if INGEST_URL:
            # forward to the Socket.IO relay so clients receive power_alert live
            try:
                async with httpx.AsyncClient(timeout=5) as client:
                    await client.post(f"{INGEST_URL}/internal/power-alert", json={
                        **row,
                        "emitted_at": datetime.now(timezone.utc).isoformat(),
                    }, headers={"x-webhook-secret": WEBHOOK_SECRET})
            except Exception as exc:
                log.warning("relay emit failed: %s", exc)

    return {"scored": True, "score": prob, "mode": mode, "alert": alert_fired}
