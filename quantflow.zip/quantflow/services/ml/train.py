"""
Offline training for the Power Alert classifier.

Label definition: positive if the underlying moved > 3% in EITHER direction
within 5 trading days after the unusual flow event (direction-aware variant
commented below — start symmetric, refine after first validation pass).

Requirements before this produces anything trustworthy:
  - >= 90 days of options_flow history in Supabase
  - daily underlying closes (fetched free from Tradier /markets/history)

Output: model.pkl + metrics.json. Deploy model.pkl next to main.py.

Usage:
  SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... TRADIER_API_KEY=... python train.py
"""

import json
import os
from datetime import datetime, timedelta, timezone

import httpx
import joblib
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import TimeSeriesSplit
from supabase import create_client

from features import build_features, FEATURE_ORDER

SUPABASE_URL = os.environ["SUPABASE_URL"]
SUPABASE_SERVICE_ROLE_KEY = os.environ["SUPABASE_SERVICE_ROLE_KEY"]
TRADIER_API_KEY = os.environ["TRADIER_API_KEY"]
TRADIER_BASE = "https://api.tradier.com/v1"

db = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)


def fetch_daily_closes(symbol: str, start: str, end: str) -> dict[str, float]:
    r = httpx.get(
        f"{TRADIER_BASE}/markets/history",
        params={"symbol": symbol, "interval": "daily", "start": start, "end": end},
        headers={"Authorization": f"Bearer {TRADIER_API_KEY}", "Accept": "application/json"},
        timeout=30,
    )
    r.raise_for_status()
    days = (r.json().get("history") or {}).get("day") or []
    if isinstance(days, dict):
        days = [days]
    return {d["date"]: float(d["close"]) for d in days}


def label_event(event: dict, closes: dict[str, float]) -> int | None:
    """1 if |move| > 3% within 5 trading days after the event, else 0. None if insufficient data."""
    event_date = str(event["created_at"])[:10]
    dates = sorted(d for d in closes if d >= event_date)
    if len(dates) < 6:
        return None
    base = closes[dates[0]]
    for d in dates[1:6]:
        if abs(closes[d] / base - 1.0) > 0.03:
            return 1
    return 0
    # Direction-aware variant (use after symmetric model validates):
    # bullish events labeled on upside-only moves, bearish on downside-only.


def main() -> None:
    one_year_ago = (datetime.now(timezone.utc) - timedelta(days=365)).isoformat()
    rows = (
        db.table("options_flow")
        .select("*")
        .eq("is_unusual", True)
        .neq("freshness", "DEMO")           # never train on synthetic data
        .gte("created_at", one_year_ago)
        .order("created_at")
        .limit(50000)
        .execute()
        .data
        or []
    )
    if len(rows) < 500:
        raise SystemExit(
            f"Only {len(rows)} non-demo unusual events. Need >= 500 (ideally 5000+). "
            "Run the ingest service longer before training — a model fit on this would be noise."
        )

    # price history per underlying, one fetch each
    underlyings = sorted({r["underlying"] for r in rows})
    start = str(rows[0]["created_at"])[:10]
    end = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    closes = {u: fetch_daily_closes(u, start, end) for u in underlyings}

    # group history per underlying once for ratio features
    hist_by_u: dict[str, list[dict]] = {}
    for r in rows:
        hist_by_u.setdefault(r["underlying"], []).append(r)

    X, y = [], []
    for r in rows:
        label = label_event(r, closes.get(r["underlying"], {}))
        if label is None:
            continue
        f = build_features(r, hist_by_u[r["underlying"]])
        X.append([f[k] for k in FEATURE_ORDER])
        y.append(label)

    X, y = np.array(X), np.array(y)
    print(f"dataset: {len(y)} events, positive rate {y.mean():.3f}")

    # time-ordered CV — never random shuffle on market data
    tscv = TimeSeriesSplit(n_splits=5)
    aucs = []
    for train_idx, test_idx in tscv.split(X):
        clf = GradientBoostingClassifier(
            n_estimators=300, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=42
        )
        clf.fit(X[train_idx], y[train_idx])
        aucs.append(roc_auc_score(y[test_idx], clf.predict_proba(X[test_idx])[:, 1]))
    print(f"walk-forward AUC per fold: {[round(a, 3) for a in aucs]}  mean={np.mean(aucs):.3f}")

    if np.mean(aucs) < 0.55:
        raise SystemExit(
            f"Mean walk-forward AUC {np.mean(aucs):.3f} < 0.55 — model has no demonstrated edge. "
            "Refusing to export. The service will keep using the labeled HEURISTIC."
        )

    final = GradientBoostingClassifier(
        n_estimators=300, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=42
    )
    final.fit(X, y)
    joblib.dump(final, "model.pkl")

    holdout = max(1, int(len(y) * 0.2))
    report = classification_report(
        y[-holdout:], final.predict(X[-holdout:]), output_dict=True, zero_division=0
    )
    with open("metrics.json", "w") as fh:
        json.dump({"walk_forward_auc": float(np.mean(aucs)), "holdout_report": report}, fh, indent=2)
    print("saved model.pkl + metrics.json")


if __name__ == "__main__":
    main()
