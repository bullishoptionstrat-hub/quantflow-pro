"""Shared feature engineering — used identically by main.py (serve) and train.py (fit)."""

import math
from datetime import datetime
from typing import Any

FEATURE_ORDER = [
    "log_premium",
    "total_size",
    "days_to_expiry",
    "otm_percentage",
    "is_sweep",
    "is_block",
    "is_call",
    "is_bullish",
    "cp_ratio_5d",
    "cp_ratio_20d",
    "hour_of_day",
    "is_morning_session",
    "heat_score",
]


def _cp_premium_ratio(history: list[dict[str, Any]], days: int, asof_iso: str) -> float:
    """Call/put premium ratio over a trailing window. 1.0 when no data (neutral)."""
    from datetime import timedelta, timezone

    asof = datetime.fromisoformat(asof_iso.replace("Z", "+00:00"))
    cutoff = asof - timedelta(days=days)
    call_p, put_p = 0.0, 0.0
    for row in history:
        ts = datetime.fromisoformat(str(row["created_at"]).replace("Z", "+00:00"))
        if ts < cutoff or ts > asof:
            continue
        if row["option_type"] == "call":
            call_p += float(row["total_premium"])
        else:
            put_p += float(row["total_premium"])
    if put_p <= 0:
        return 2.0 if call_p > 0 else 1.0
    return min(call_p / put_p, 5.0)


def build_features(event: dict[str, Any], history: list[dict[str, Any]]) -> dict[str, float]:
    created = datetime.fromisoformat(str(event["created_at"]).replace("Z", "+00:00"))
    # ET hour approximation: stored UTC; ET = UTC-4/-5. Use -4 (trading season dominant).
    hour_et = (created.hour - 4) % 24
    otm = event.get("otm_percentage")
    return {
        "log_premium": math.log10(max(float(event["total_premium"]), 1.0)),
        "total_size": float(event["total_size"]),
        "days_to_expiry": float(event["days_to_expiry"]),
        "otm_percentage": float(otm) if otm is not None else 0.0,
        "is_sweep": 1.0 if event["order_type"] == "SWEEP" else 0.0,
        "is_block": 1.0 if event["order_type"] == "BLOCK" else 0.0,
        "is_call": 1.0 if event["option_type"] == "call" else 0.0,
        "is_bullish": 1.0 if event["sentiment"] == "BULLISH" else 0.0,
        "cp_ratio_5d": _cp_premium_ratio(history, 5, str(event["created_at"])),
        "cp_ratio_20d": _cp_premium_ratio(history, 20, str(event["created_at"])),
        "hour_of_day": float(hour_et),
        "is_morning_session": 1.0 if 9 <= hour_et < 12 else 0.0,
        # Heat Score added pre-model (v1.1) — safe to add now because no model.pkl
        # exists yet; changing FEATURE_ORDER after training breaks serve/fit parity.
        # Rows written before v1.1 carry heat_score=0 (column default).
        "heat_score": float(event.get("heat_score") or 0) / 100.0,
    }
