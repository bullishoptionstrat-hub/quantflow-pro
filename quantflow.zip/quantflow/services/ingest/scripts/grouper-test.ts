/** Deterministic grouper test: inject controlled ticks, assert classification.
 *  Run: npx tsx services/ingest/scripts/grouper-test.ts (env stubs on CLI) */
import { FlowGrouper } from "../src/grouper";
import type { KV } from "../src/redis";
import type { FlowEvent, RawTradeTick } from "@quantflow/shared";

// In-memory KV stub (no baseline data -> is_unusual stays false; that's fine,
// unusual flagging is baseline-driven and tested separately)
const store = new Map<string, unknown>();
const kv: KV = {
  async get<T>(k: string) { return (store.get(k) as T) ?? null; },
  async set(k, v) { store.set(k, v); },
  async del(k) { store.delete(k); },
  async keys(p) { return [...store.keys()].filter((k) => k.startsWith(p)); },
};

type Ev = Omit<FlowEvent, "id" | "created_at">;
const events: Ev[] = [];
const grouper = new FlowGrouper(kv, async (e) => { events.push(e); }, () => 737);

const now = Date.now();
const base = {
  underlying: "SPY", strike: 750, expiration: "2026-07-10",
  optionType: "call" as const, bid: 4.4, ask: 4.6, timestampMs: now,
};

async function main() {
  // Case 1: 3 fills, 3 exchanges, at the ask, same window -> SWEEP, BULLISH, hot
  for (const [exchange, size] of [["A", 40], ["B", 35], ["C", 45]] as const) {
    grouper.ingest({ ...base, symbol: "SPY260710C00750000", exchange, size, price: 4.6 });
  }
  // Case 2: single 300-lot put at the bid -> BLOCK; bid-side puts = put SELLER = BULLISH
  grouper.ingest({
    ...base, symbol: "QQQ260710P00700000", underlying: "QQQ", strike: 700,
    optionType: "put", exchange: "Q", size: 300, price: 5.1, bid: 5.1, ask: 5.3,
  });
  // Case 3: 120-lot single print above mid -> SPLIT (size>=100, one exchange)
  grouper.ingest({
    ...base, symbol: "NVDA260710C00210000", underlying: "NVDA", strike: 210,
    exchange: "N", size: 120, price: 3.55, bid: 3.4, ask: 3.6,
  });
  // Case 4: 5-lot dust -> discarded
  grouper.ingest({
    ...base, symbol: "TSLA260710C00400000", underlying: "TSLA", strike: 400,
    exchange: "T", size: 5, price: 1.0, bid: 0.9, ask: 1.1,
  });

  await new Promise((r) => setTimeout(r, 1200)); // window 500ms + flusher 100ms + margin
  grouper.stop();

  console.log(`events: ${events.length} (expect 3)`);
  for (const e of events) {
    console.log(`${e.order_type.padEnd(5)} ${e.underlying.padEnd(4)} size=${String(e.total_size).padStart(3)} prem=$${Math.round(e.total_premium).toLocaleString().padStart(7)} ${e.sentiment.padEnd(7)} heat=${e.heat_score} exch=${e.exchange_count} ${e.freshness}`);
  }
  const sweep = events.find((e) => e.underlying === "SPY");
  const block = events.find((e) => e.underlying === "QQQ");
  const split = events.find((e) => e.underlying === "NVDA");
  const checks: [string, boolean][] = [
    ["SPY is SWEEP", sweep?.order_type === "SWEEP"],
    ["SPY BULLISH (ask-side calls)", sweep?.sentiment === "BULLISH"],
    ["SPY heat == 70 (ask 40 + 3-exch 20 + prem<100K 0 + half-spread displacement 10)", sweep?.heat_score === 70],
    ["QQQ is BLOCK", block?.order_type === "BLOCK"],
    ["QQQ BULLISH (bid-side puts = put seller)", block?.sentiment === "BULLISH"],
    ["NVDA is SPLIT", split?.order_type === "SPLIT"],
    ["TSLA 5-lot discarded", !events.some((e) => e.underlying === "TSLA")],
    ["sweep premium = 120 * 4.6 * 100 = $55,200", Math.round(sweep?.total_premium ?? 0) === 55_200],
  ];
  let pass = 0;
  for (const [name, ok] of checks) { console.log((ok ? "PASS" : "FAIL") + "  " + name); if (ok) pass++; }
  console.log(`${pass}/${checks.length}`);
  process.exit(pass === checks.length ? 0 : 1);
}
void main();
