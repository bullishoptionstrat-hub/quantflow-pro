/**
 * Ingest pipeline harness: real TradierFeed -> real FlowGrouper -> console.
 * Proves tick synthesis, OCC parsing, grouping, classification, sentiment,
 * and heat scoring end-to-end WITHOUT Supabase.
 * Usage: TRADIER_API_KEY=... npx tsx services/ingest/scripts/harness.ts
 */
process.env.TRADIER_ENV = process.env.TRADIER_ENV ?? "sandbox";
process.env.WATCHLIST = process.env.WATCHLIST ?? "SPY,QQQ,NVDA,TSLA";
process.env.SUPABASE_URL = process.env.SUPABASE_URL ?? "https://example.supabase.co";
process.env.SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "harness-not-used";
process.env.ML_WEBHOOK_SECRET = process.env.ML_WEBHOOK_SECRET ?? "harness";

import { TradierFeed } from "../src/tradier";
import { FlowGrouper } from "../src/grouper";
import type { FlowEvent } from "@quantflow/shared";

const RUN_MS = Number(process.env.HARNESS_MS ?? 150_000);

async function main() {
  if (!process.env.TRADIER_API_KEY) {
    console.error("TRADIER_API_KEY required");
    process.exit(1);
  }
  const events: FlowEvent[] = [];
  let ticks = 0;

  const grouper = new FlowGrouper((e: FlowEvent) => {
    events.push(e);
    console.log(
      `EVENT ${e.order_type} ${e.underlying} ${e.strike}${e.option_type === "call" ? "C" : "P"} ` +
        `${e.expiration} size=${e.total_size} prem=$${Math.round(e.total_premium).toLocaleString()} ` +
        `${e.sentiment} heat=${e.heat_score} unusual=${e.is_unusual} ${e.freshness}`
    );
  });

  const feed = new TradierFeed((tick) => {
    ticks++;
    if (ticks <= 3) console.log(`tick: ${tick.symbol} size=${tick.size} @ ${tick.price} exch=${tick.exchange}`);
    void grouper.ingest(tick);
  });

  console.log(`starting ${process.env.TRADIER_ENV} feed for ${RUN_MS / 1000}s (sandbox needs 2 polls for deltas)...`);
  await feed.start();
  await new Promise((r) => setTimeout(r, RUN_MS));

  console.log(`\nRESULT: ${ticks} ticks synthesized, ${events.length} grouped events`);
  const byType: Record<string, number> = {};
  for (const e of events) byType[e.order_type] = (byType[e.order_type] ?? 0) + 1;
  console.log("by type:", JSON.stringify(byType));
  if (events.length > 0) {
    const top = [...events].sort((a, b) => b.total_premium - a.total_premium)[0];
    console.log(
      "largest:",
      top.underlying,
      top.strike,
      top.option_type,
      "$" + Math.round(top.total_premium).toLocaleString(),
      "heat",
      top.heat_score
    );
  }
  process.exit(0);
}
main().catch((e) => {
  console.error("HARNESS FAILED:", e);
  process.exit(1);
});
