import type { RawTradeTick, FlowEvent, OrderType, Sentiment } from "@quantflow/shared";
import { config, resolveFreshness } from "./config";
import type { KV } from "./redis";
import { log } from "./logger";

interface TickGroup {
  ticks: RawTradeTick[];
  firstSeenMs: number;
}

/**
 * Groups ticks into 500ms windows per contract, then classifies.
 *
 * Window key: {underlying}_{strike}_{expiry}_{type}_{floor(ts/windowMs)}
 *
 * Classification (after window closes):
 *   exchange_count > 1                       → SWEEP   (multi-venue liquidity take)
 *   exchange_count == 1, size >= BLOCK thr   → BLOCK   (single large negotiated print)
 *   exchange_count == 1, size >= SPLIT thr   → SPLIT   (broken-up single-venue order)
 *   below SPLIT threshold                    → discarded (retail noise)
 *
 * Sentiment: vs bid/ask midpoint at print time.
 * Unusual: window size > N× rolling 20d avg daily volume / typical-windows-per-day
 *          — pragmatic free-tier proxy; the baseline table improves as history accrues.
 */
export class FlowGrouper {
  private groups = new Map<string, TickGroup>();
  private timer: NodeJS.Timeout;

  constructor(
    private kv: KV,
    private onFlowEvent: (e: Omit<FlowEvent, "id" | "created_at">) => Promise<void>,
    private getUnderlyingPrice: (u: string) => number | null
  ) {
    this.timer = setInterval(() => void this.flushExpired(), 100);
  }

  stop(): void {
    clearInterval(this.timer);
  }

  ingest(tick: RawTradeTick): void {
    const windowBucket = Math.floor(tick.timestampMs / config.GROUP_WINDOW_MS);
    const key = `${tick.underlying}_${tick.strike}_${tick.expiration}_${tick.optionType}_${windowBucket}`;
    const existing = this.groups.get(key);
    if (existing) {
      existing.ticks.push(tick);
    } else {
      this.groups.set(key, { ticks: [tick], firstSeenMs: Date.now() });
    }
  }

  private async flushExpired(): Promise<void> {
    const now = Date.now();
    for (const [key, group] of this.groups) {
      if (now - group.firstSeenMs < config.GROUP_WINDOW_MS) continue;
      this.groups.delete(key);
      try {
        await this.finalize(group);
      } catch (err) {
        log.error({ key, err: String(err) }, "finalize failed");
      }
    }
  }

  private classify(totalSize: number, exchangeCount: number): OrderType | null {
    if (exchangeCount > 1) return "SWEEP";
    if (totalSize >= config.BLOCK_SIZE_THRESHOLD) return "BLOCK";
    if (totalSize >= config.SPLIT_SIZE_THRESHOLD) return "SPLIT";
    return null;
  }

  /** Which side of the midpoint the prints hit: buyer-initiated, seller-initiated, or ambiguous. */
  private aggressorSide(avgPrice: number, bid: number, ask: number): "BUY" | "SELL" | "MID" {
    if (bid <= 0 || ask <= 0 || ask < bid) return "MID";
    const mid = (bid + ask) / 2;
    const spread = ask - bid;
    // require conviction beyond 10% of spread from mid to avoid noise flips
    if (avgPrice > mid + spread * 0.1) return "BUY";
    if (avgPrice < mid - spread * 0.1) return "SELL";
    return "MID";
  }

  private async isUnusual(symbol: string, windowSize: number): Promise<boolean> {
    const baseline = await this.kv.get<{ avg: number }>(`baseline:${symbol}`);
    if (!baseline || baseline.avg <= 0) return false;
    // ~ 80 active windows/contract/day is a conservative divisor for free tier
    const perWindowAvg = baseline.avg / 80;
    return windowSize > perWindowAvg * config.UNUSUAL_VOLUME_MULTIPLIER;
  }

  /**
   * Heat Score (0–100): fill-aggression metric (InsiderFinance analog).
   *   ask-side fill         up to 40  (full ask-or-above 40, above-mid 20)
   *   multi-exchange sweep  up to 20  (3+ venues 20, 2 venues 10)
   *   premium magnitude     up to 20  ($1M+ 20, $250K+ 15, $100K+ 10)
   *   spread displacement   up to 20  (|fill − mid| / spread, capped)
   * DELAYED mode caveat: REST-poll fallback synthesizes ticks with a single
   * exchange code, so the multi-exchange component can never fire — DELAYED
   * heat scores top out at 80 by construction. Honest, not a bug.
   */
  private computeHeatScore(
    avgPrice: number,
    bid: number,
    ask: number,
    exchangeCount: number,
    totalPremium: number
  ): number {
    let score = 0;
    const validQuote = bid > 0 && ask > 0 && ask >= bid;
    const mid = validQuote ? (bid + ask) / 2 : 0;
    const spread = validQuote ? ask - bid : 0;

    if (validQuote) {
      if (avgPrice >= ask) score += 40;
      else if (avgPrice > mid) score += 20;
    }

    if (exchangeCount >= 3) score += 20;
    else if (exchangeCount === 2) score += 10;

    if (totalPremium >= 1_000_000) score += 20;
    else if (totalPremium >= 250_000) score += 15;
    else if (totalPremium >= 100_000) score += 10;

    if (validQuote && spread > 0) {
      score += Math.min(20, Math.round((Math.abs(avgPrice - mid) / spread) * 20));
    }

    return Math.min(100, score);
  }

  private async finalize(group: TickGroup): Promise<void> {
    const ticks = group.ticks;
    const first = ticks[0];
    const totalSize = ticks.reduce((s, t) => s + t.size, 0);
    const exchanges = new Set(ticks.map((t) => t.exchange));
    const orderType = this.classify(totalSize, exchanges.size);
    if (!orderType) return;

    const totalPremium = ticks.reduce((s, t) => s + t.price * t.size * 100, 0);
    const avgPrice = totalPremium / (totalSize * 100);

    // size-weighted bid/ask reference for sentiment
    const wBid = ticks.reduce((s, t) => s + t.bid * t.size, 0) / Math.max(totalSize, 1);
    const wAsk = ticks.reduce((s, t) => s + t.ask * t.size, 0) / Math.max(totalSize, 1);

    let sentiment: Sentiment = "NEUTRAL";
    const side = this.aggressorSide(avgPrice, wBid, wAsk);
    if (side === "BUY") {
      // ask-side call buy = bullish; ask-side put buy = bearish
      sentiment = first.optionType === "call" ? "BULLISH" : "BEARISH";
    } else if (side === "SELL") {
      // bid-side prints = seller-initiated → opposite read
      sentiment = first.optionType === "call" ? "BEARISH" : "BULLISH";
    }

    const underlyingPrice = this.getUnderlyingPrice(first.underlying);
    const otm =
      underlyingPrice && underlyingPrice > 0
        ? first.optionType === "call"
          ? ((first.strike - underlyingPrice) / underlyingPrice) * 100
          : ((underlyingPrice - first.strike) / underlyingPrice) * 100
        : null;

    const dte = Math.max(
      0,
      Math.round((new Date(first.expiration).getTime() - Date.now()) / 86_400_000)
    );

    const event: Omit<FlowEvent, "id" | "created_at"> = {
      symbol: first.symbol,
      underlying: first.underlying,
      strike: first.strike,
      expiration: first.expiration,
      option_type: first.optionType,
      order_type: orderType,
      total_size: totalSize,
      total_premium: Math.round(totalPremium),
      avg_price: Number(avgPrice.toFixed(4)),
      exchange_count: exchanges.size,
      sentiment,
      is_unusual: await this.isUnusual(first.symbol, totalSize),
      heat_score: this.computeHeatScore(avgPrice, wBid, wAsk, exchanges.size, totalPremium),
      days_to_expiry: dte,
      iv: null, // greeks not subscribed on free tier; column reserved
      underlying_price: underlyingPrice,
      otm_percentage: otm !== null ? Number(otm.toFixed(2)) : null,
      freshness: resolveFreshness(),
    };

    await this.onFlowEvent(event);

    // accumulate intraday volume for tomorrow's baseline
    const dayKey = `dayvol:${first.symbol}:${new Date().toISOString().slice(0, 10)}`;
    const cur = (await this.kv.get<number>(dayKey)) ?? 0;
    await this.kv.set(dayKey, cur + totalSize, 60 * 60 * 24 * 2);
  }
}
