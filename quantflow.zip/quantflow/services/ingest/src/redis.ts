import { Redis } from "@upstash/redis";
import { config } from "./config";
import { log } from "./logger";

/**
 * Upstash REST Redis when configured; otherwise an in-memory Map fallback
 * (clearly logged) so local dev works without an Upstash account.
 * The fallback is functionally identical for the 500ms grouping window —
 * it only loses state on process restart, which is acceptable for a buffer.
 */
export interface KV {
  get<T>(key: string): Promise<T | null>;
  set(key: string, value: unknown, ttlSeconds: number): Promise<void>;
  del(key: string): Promise<void>;
  keys(prefix: string): Promise<string[]>;
}

class UpstashKV implements KV {
  private r: Redis;
  constructor(url: string, token: string) {
    this.r = new Redis({ url, token });
  }
  async get<T>(key: string): Promise<T | null> {
    return (await this.r.get<T>(key)) ?? null;
  }
  async set(key: string, value: unknown, ttlSeconds: number): Promise<void> {
    await this.r.set(key, JSON.stringify(value), { ex: ttlSeconds });
  }
  async del(key: string): Promise<void> {
    await this.r.del(key);
  }
  async keys(prefix: string): Promise<string[]> {
    return await this.r.keys(`${prefix}*`);
  }
}

class MemoryKV implements KV {
  private store = new Map<string, { value: unknown; expiresAt: number }>();
  private sweep() {
    const now = Date.now();
    for (const [k, v] of this.store) if (v.expiresAt < now) this.store.delete(k);
  }
  async get<T>(key: string): Promise<T | null> {
    this.sweep();
    const hit = this.store.get(key);
    return hit ? (hit.value as T) : null;
  }
  async set(key: string, value: unknown, ttlSeconds: number): Promise<void> {
    this.store.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
  }
  async del(key: string): Promise<void> {
    this.store.delete(key);
  }
  async keys(prefix: string): Promise<string[]> {
    this.sweep();
    return [...this.store.keys()].filter((k) => k.startsWith(prefix));
  }
}

export function createKV(): KV {
  if (config.UPSTASH_REDIS_REST_URL && config.UPSTASH_REDIS_REST_TOKEN) {
    log.info("KV: Upstash Redis");
    return new UpstashKV(config.UPSTASH_REDIS_REST_URL, config.UPSTASH_REDIS_REST_TOKEN);
  }
  log.warn("KV: Upstash not configured — using in-memory fallback (dev only)");
  return new MemoryKV();
}
