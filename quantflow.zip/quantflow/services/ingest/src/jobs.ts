import fetch from "node-fetch";
import type { SupabaseClient } from "@supabase/supabase-js";
import { WATCHLIST } from "./config";
import type { KV } from "./redis";
import { log } from "./logger";

/**
 * FINRA ATS Transparency Data — the honest version.
 *
 * What exists for free: weekly per-symbol ATS ("dark pool") volume aggregates,
 * published on a 2–4 week delay via FINRA's open data API.
 * What does NOT exist for free: real-time or daily dark pool prints.
 *
 * Endpoint: https://api.finra.org/data/group/otcMarket/name/weeklySummary
 * No auth required for public datasets; rate-limited.
 */
const FINRA_URL = "https://api.finra.org/data/group/otcMarket/name/weeklySummary";

interface FinraRow {
  issueSymbolIdentifier: string;
  totalWeeklyShareQuantity: number;
  totalWeeklyTradeCount: number;
  weekStartDate: string;
  MPID?: string;
  marketParticipantName?: string;
}

export async function syncFinraWeekly(db: SupabaseClient): Promise<void> {
  try {
    const res = await fetch(FINRA_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        limit: 5000,
        // VERIFIED LIVE 2026-06-10: multiple EQUAL compareFilters on the same
        // field are AND (empty result), NOT OR. Multi-value matching requires
        // domainFilters. The previous EQUAL-spam version returned 0 rows, 200 OK
        // — a silently dead sync.
        domainFilters: [{ fieldName: "issueSymbolIdentifier", values: WATCHLIST }],
        compareFilters: [
          // CRITICAL: without this, the dataset mixes ATS rows with non-ATS
          // OTC (wholesaler internalization) rows and inflates "dark pool". Use the
          // per-firm code: totals match ATS_W_SMBL and MPIDs give ats_count.
          // volume with volume that is not ATS volume. Verified live 2026-06-10.
          { compareType: "EQUAL", fieldName: "summaryTypeCode", fieldValue: "ATS_W_SMBL_FIRM" },
          // Results come in arbitrary order (sorting requires partition keys),
          // so bound the window or the row budget gets spent on stale weeks.
          {
            compareType: "GTE",
            fieldName: "weekStartDate",
            fieldValue: new Date(Date.now() - 70 * 86_400_000).toISOString().slice(0, 10),
          },
        ],
      }),
    });
    if (!res.ok) {
      log.warn({ status: res.status }, "FINRA fetch failed — skipping this cycle");
      return;
    }
    const rows = (await res.json()) as FinraRow[];

    // aggregate across ATS participants per symbol/week
    const agg = new Map<string, { shares: number; trades: number; ats: Set<string> }>();
    for (const r of rows) {
      const key = `${r.issueSymbolIdentifier}|${r.weekStartDate}`;
      const cur = agg.get(key) ?? { shares: 0, trades: 0, ats: new Set<string>() };
      cur.shares += Number(r.totalWeeklyShareQuantity || 0);
      cur.trades += Number(r.totalWeeklyTradeCount || 0);
      const atsKey = r.MPID ?? r.marketParticipantName;
      if (atsKey) cur.ats.add(atsKey);
      agg.set(key, cur);
    }

    const upserts = [...agg.entries()].map(([key, v]) => {
      const [symbol, week_start] = key.split("|");
      return {
        symbol,
        week_start,
        total_shares: v.shares,
        total_trades: v.trades,
        ats_count: v.ats.size,
        avg_trade_size: v.trades > 0 ? v.shares / v.trades : 0,
        source: "FINRA_ATS_WEEKLY",
      };
    });

    if (upserts.length > 0) {
      const { error } = await db
        .from("dark_pool_weekly")
        .upsert(upserts, { onConflict: "symbol,week_start" });
      if (error) log.error({ error }, "darkpool upsert failed");
      else log.info({ rows: upserts.length }, "FINRA weekly synced");
    }
  } catch (err) {
    log.error({ err: String(err) }, "FINRA sync error");
  }
}

/**
 * Recomputes volume-at-price levels per underlying from the last 30 days of flow.
 * Bins underlying_price at print time; classifies relative to current spot:
 *   below spot → support, above → resistance, top decile of volume → accumulation.
 */
export async function recomputeLevels(
  db: SupabaseClient,
  getSpot: (u: string) => number | null
): Promise<void> {
  for (const underlying of WATCHLIST) {
    const { data, error } = await db
      .from("options_flow")
      .select("underlying_price, total_size")
      .eq("underlying", underlying)
      .gte("created_at", new Date(Date.now() - 30 * 86_400_000).toISOString())
      .not("underlying_price", "is", null);

    if (error || !data || data.length === 0) continue;

    const spot = getSpot(underlying);
    const binSize = spot && spot > 200 ? 1 : 0.5;
    const bins = new Map<number, number>();
    for (const row of data) {
      const p = Number(row.underlying_price);
      const bin = Math.round(p / binSize) * binSize;
      bins.set(bin, (bins.get(bin) ?? 0) + Number(row.total_size));
    }

    const sorted = [...bins.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20);
    const volumes = sorted.map(([, v]) => v);
    const accumThreshold = volumes.length > 0 ? volumes[Math.floor(volumes.length / 10)] : Infinity;

    const upserts = sorted.map(([price, vol]) => ({
      symbol: underlying,
      price_level: price,
      total_volume: vol,
      level_type:
        vol >= accumThreshold
          ? ("accumulation" as const)
          : spot && price < spot
            ? ("support" as const)
            : ("resistance" as const),
      last_updated: new Date().toISOString(),
    }));

    const { error: upErr } = await db
      .from("flow_levels")
      .upsert(upserts, { onConflict: "symbol,price_level,level_type" });
    if (upErr) log.error({ underlying, upErr }, "levels upsert failed");
  }
  log.info("flow levels recomputed");
}

/**
 * Nightly: roll yesterday's per-contract volume into the 20-day baseline used
 * by the unusual flag. Simple EMA so we don't need 20 stored days per contract.
 */
export async function rollBaselines(db: SupabaseClient, kv: KV): Promise<void> {
  const yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
  const keys = await kv.keys(`dayvol:`);
  let updated = 0;
  for (const key of keys) {
    if (!key.endsWith(yesterday)) continue;
    const symbol = key.split(":")[1];
    const dayVol = (await kv.get<number>(key)) ?? 0;
    const prev = await kv.get<{ avg: number; days: number }>(`baseline:${symbol}`);
    const alpha = 2 / (20 + 1); // 20-day EMA
    const avg = prev ? prev.avg * (1 - alpha) + dayVol * alpha : dayVol;
    const days = (prev?.days ?? 0) + 1;
    await kv.set(`baseline:${symbol}`, { avg, days }, 60 * 60 * 24 * 30);
    await db
      .from("contract_volume_baseline")
      .upsert(
        { symbol, avg_daily_volume: avg, sample_days: days, updated_at: new Date().toISOString() },
        { onConflict: "symbol" }
      );
    updated++;
  }
  log.info({ updated }, "baselines rolled");
}

// ============================================================
// GEX — net dealer gamma exposure per strike
// ============================================================
import { config, TRADIER_HTTP_BASE, resolveFreshness } from "./config";

interface TradierGreeks {
  gamma?: number;
}
interface TradierChainOption {
  strike: number;
  option_type: "call" | "put";
  open_interest?: number;
  greeks?: TradierGreeks | null;
}

async function tradierGet<T>(path: string): Promise<T | null> {
  if (!config.TRADIER_API_KEY) return null;
  const res = await fetch(`${TRADIER_HTTP_BASE}${path}`, {
    headers: { Authorization: `Bearer ${config.TRADIER_API_KEY}`, Accept: "application/json" },
  });
  if (!res.ok) {
    log.warn({ path, status: res.status }, "tradier GET failed");
    return null;
  }
  return (await res.json()) as T;
}

/**
 * Computes net dealer gamma exposure per strike for each watchlist symbol.
 *
 * Convention: dollar gamma per 1% underlying move —
 *   GEX(strike) = Σ gamma × OI × 100 × spot² × 0.01
 * with call legs positive and put legs negative (dealer short calls / long
 * puts heuristic — the same simplification every retail GEX product makes;
 * true dealer positioning is unobservable without OCC position data).
 *
 * Greeks come from Tradier chains with greeks=true (ORATS-computed, refreshed
 * ~hourly). GEX is therefore a positioning map, not a real-time signal — the
 * computed_at + freshness columns make that explicit.
 *
 * Skipped entirely in DEMO mode / when no Tradier key: no synthetic GEX, ever.
 */
export async function recomputeGex(
  db: SupabaseClient,
  getSpot: (u: string) => number | null
): Promise<void> {
  if (config.DEMO_MODE || !config.TRADIER_API_KEY) {
    log.info("GEX skipped — no Tradier key or demo mode (no synthetic GEX)");
    return;
  }

  for (const underlying of WATCHLIST) {
    try {
      // Spot: prefer live feed cache; fall back to REST quote.
      let spot = getSpot(underlying);
      if (!spot || spot <= 0) {
        const q = await tradierGet<{ quotes?: { quote?: { last?: number } | { last?: number }[] } }>(
          `/markets/quotes?symbols=${underlying}`
        );
        const quote = q?.quotes?.quote;
        const one = Array.isArray(quote) ? quote[0] : quote;
        spot = one?.last ?? null;
      }
      if (!spot || spot <= 0) continue;

      const expRes = await tradierGet<{ expirations?: { date?: string[] | string } }>(
        `/markets/options/expirations?symbol=${underlying}`
      );
      const dates = expRes?.expirations?.date;
      const expirations = (Array.isArray(dates) ? dates : dates ? [dates] : []).slice(0, 3);
      if (expirations.length === 0) continue;

      const byStrike = new Map<number, { call: number; put: number }>();
      for (const exp of expirations) {
        const chainRes = await tradierGet<{ options?: { option?: TradierChainOption[] | TradierChainOption } }>(
          `/markets/options/chains?symbol=${underlying}&expiration=${exp}&greeks=true`
        );
        const raw = chainRes?.options?.option;
        const options = Array.isArray(raw) ? raw : raw ? [raw] : [];
        for (const o of options) {
          const gamma = o.greeks?.gamma ?? 0;
          const oi = o.open_interest ?? 0;
          if (gamma <= 0 || oi <= 0) continue;
          const gex = gamma * oi * 100 * spot * spot * 0.01;
          const cur = byStrike.get(o.strike) ?? { call: 0, put: 0 };
          if (o.option_type === "call") cur.call += gex;
          else cur.put -= gex; // dealer long puts → negative GEX
          byStrike.set(o.strike, cur);
        }
      }
      if (byStrike.size === 0) continue;

      const levels = [...byStrike.entries()]
        .map(([strike, v]) => ({ strike, call_gex: v.call, put_gex: v.put, net_gex: v.call + v.put }))
        .sort((a, b) => a.strike - b.strike);

      // Wall = top 10% by |net| (min 2). Flip = zero-crossing nearest spot.
      const byMagnitude = [...levels].sort((a, b) => Math.abs(b.net_gex) - Math.abs(a.net_gex));
      const wallCount = Math.max(2, Math.floor(levels.length / 10));
      const walls = new Set(byMagnitude.slice(0, wallCount).map((l) => l.strike));

      let flipStrike: number | null = null;
      let flipDist = Infinity;
      for (let i = 1; i < levels.length; i++) {
        const a = levels[i - 1];
        const b = levels[i];
        if ((a.net_gex >= 0 && b.net_gex < 0) || (a.net_gex < 0 && b.net_gex >= 0)) {
          const cross = (a.strike + b.strike) / 2;
          const d = Math.abs(cross - spot);
          if (d < flipDist) {
            flipDist = d;
            flipStrike = b.strike;
          }
        }
      }

      // Keep the 40 strikes nearest spot — far wings are OI noise.
      const kept = [...levels]
        .sort((a, b) => Math.abs(a.strike - spot!) - Math.abs(b.strike - spot!))
        .slice(0, 40);

      const now = new Date().toISOString();
      const upserts = kept.map((l) => ({
        underlying,
        strike: l.strike,
        net_gex: Math.round(l.net_gex),
        call_gex: Math.round(l.call_gex),
        put_gex: Math.round(l.put_gex),
        level_type:
          l.strike === flipStrike
            ? ("flip" as const)
            : walls.has(l.strike)
              ? ("wall" as const)
              : l.net_gex >= 0
                ? ("support" as const)
                : ("resistance" as const),
        spot_price: spot,
        expirations_included: expirations.length,
        freshness: resolveFreshness(),
        computed_at: now,
      }));

      // Replace the symbol's snapshot wholesale — stale strikes must not linger.
      await db.from("gex_levels").delete().eq("underlying", underlying);
      const { error } = await db.from("gex_levels").insert(upserts);
      if (error) log.error({ underlying, error }, "gex insert failed");
    } catch (err) {
      log.error({ underlying, err: String(err) }, "gex compute error");
    }
  }
  log.info("GEX recomputed");
}
