import { EventEmitter } from "events";
import type { RawTradeTick, OptionType } from "@quantflow/shared";
import { WATCHLIST } from "./config";
import { log } from "./logger";

/**
 * DEMO feed — synthetic ticks for local UI development only.
 * config.ts refuses to start with DEMO_MODE=true in production.
 * Every event produced through this path is stamped freshness=DEMO and the
 * UI renders a persistent DEMO banner. This is never disguised as live data.
 */
const SPOTS: Record<string, number> = {
  SPY: 685, QQQ: 612, TSLA: 348, NVDA: 187, AAPL: 245,
  MSFT: 512, AMZN: 233, META: 720, AMD: 162, GOOGL: 196,
};

const EXCHANGES = ["C", "P", "Q", "B", "X", "M", "A"];

function rand(min: number, max: number): number {
  return min + Math.random() * (max - min);
}
function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export class DemoFeed extends EventEmitter {
  private timer: NodeJS.Timeout | null = null;

  getUnderlyingPrice(u: string): number | null {
    return SPOTS[u] ?? null;
  }

  start(): void {
    log.warn("DEMO FEED ACTIVE — synthetic data, freshness=DEMO");
    this.emit("status", { connected: true, provider: "DEMO" });
    this.timer = setInterval(() => this.burst(), 1800);
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
  }

  /** Emits a multi-tick burst so the grouper exercises real sweep/block paths. */
  private burst(): void {
    const underlying = pick(WATCHLIST.filter((s) => SPOTS[s]));
    const spot = SPOTS[underlying];
    const optionType: OptionType = Math.random() > 0.5 ? "call" : "put";
    const strike = Math.round(spot * rand(0.95, 1.05));
    const dte = pick([2, 5, 9, 16, 30]);
    const exp = new Date(Date.now() + dte * 86_400_000);
    const expStr = exp.toISOString().slice(0, 10);
    const occExp = expStr.slice(2).replace(/-/g, "");
    const symbol = `${underlying}${occExp}${optionType === "call" ? "C" : "P"}${String(strike * 1000).padStart(8, "0")}`;

    const price = rand(0.5, 12);
    const bid = price * rand(0.96, 0.995);
    const ask = price * rand(1.005, 1.04);
    const isSweep = Math.random() < 0.3;
    const legs = isSweep ? Math.floor(rand(2, 5)) : 1;
    const now = Date.now();

    for (let i = 0; i < legs; i++) {
      const tick: RawTradeTick = {
        symbol,
        underlying,
        strike,
        expiration: expStr,
        optionType,
        price: price * rand(0.99, 1.01),
        size: Math.floor(rand(80, isSweep ? 600 : 1500)),
        exchange: isSweep ? EXCHANGES[i % EXCHANGES.length] : pick(EXCHANGES),
        bid,
        ask,
        timestampMs: now + i * 50,
      };
      this.emit("tick", tick);
    }
  }
}
