import WebSocket from "ws";
import fetch from "node-fetch";
import { EventEmitter } from "events";
import type { RawTradeTick, OptionType } from "@quantflow/shared";
import { config, TRADIER_HTTP_BASE, TRADIER_WS_URL, WATCHLIST } from "./config";
import { log } from "./logger";

/**
 * OCC option symbol: ROOT (1-6 chars, padded) + YYMMDD + C/P + 8-digit strike*1000
 * e.g. TSLA260116C00300000
 */
export function parseOccSymbol(
  occ: string
): { underlying: string; expiration: string; optionType: OptionType; strike: number } | null {
  const m = occ.match(/^([A-Z]{1,6})(\d{2})(\d{2})(\d{2})([CP])(\d{8})$/);
  if (!m) return null;
  const [, root, yy, mm, dd, cp, strikeRaw] = m;
  return {
    underlying: root,
    expiration: `20${yy}-${mm}-${dd}`,
    optionType: cp === "C" ? "call" : "put",
    strike: parseInt(strikeRaw, 10) / 1000,
  };
}

interface TradierTimesale {
  type: string;
  symbol: string;
  exch?: string;
  price?: string | number;
  size?: string | number;
  bid?: string | number;
  ask?: string | number;
  last?: string | number;
  date?: string | number;
}

/**
 * Tradier streaming requires:
 *   1. POST /markets/events/session (HTTP, production base) → sessionid
 *   2. Connect wss://ws.tradier.com/v1/markets/events
 *   3. Send {"symbols":[...], "sessionid":"...", "filter":["timesale","quote"]}
 *
 * Constraint (documented): one simultaneous streaming session per account.
 * This service is the single relay — browsers never connect to Tradier.
 *
 * Sandbox tokens cannot create streaming sessions. In sandbox mode we fall
 * back to REST polling of option chains and synthesize ticks from volume
 * deltas — explicitly DELAYED freshness.
 */
export class TradierFeed extends EventEmitter {
  private ws: WebSocket | null = null;
  private optionSymbols: string[] = [];
  private reconnectDelay = 1000;
  private pollTimer: NodeJS.Timeout | null = null;
  private lastVolumes = new Map<string, number>();
  private quoteCache = new Map<string, { bid: number; ask: number }>();
  private underlyingPrices = new Map<string, number>();
  private stopped = false;

  async start(): Promise<void> {
    await this.refreshOptionUniverse();
    // Refresh the contract universe every 30 min (new strikes/expiries intraday)
    setInterval(() => void this.refreshOptionUniverse().catch((e) => log.error(e)), 30 * 60_000);

    if (config.TRADIER_ENV === "production") {
      await this.connectWebSocket();
    } else {
      log.warn("Tradier sandbox: streaming unavailable — REST polling (DELAYED data)");
      this.startRestPolling();
    }
  }

  stop(): void {
    this.stopped = true;
    this.ws?.close();
    if (this.pollTimer) clearInterval(this.pollTimer);
  }

  getUnderlyingPrice(underlying: string): number | null {
    return this.underlyingPrices.get(underlying) ?? null;
  }

  // ---------- universe ----------

  private async tradierGet<T>(path: string): Promise<T> {
    const res = await fetch(`${TRADIER_HTTP_BASE}${path}`, {
      headers: {
        Authorization: `Bearer ${config.TRADIER_API_KEY}`,
        Accept: "application/json",
      },
    });
    if (!res.ok) throw new Error(`Tradier ${path} → ${res.status} ${await res.text()}`);
    return (await res.json()) as T;
  }

  /** Builds the near-the-money, near-dated contract list per watchlist underlying. */
  private async refreshOptionUniverse(): Promise<void> {
    const symbols: string[] = [];
    for (const underlying of WATCHLIST) {
      try {
        const quoteRes = await this.tradierGet<{
          quotes: { quote: { last: number } | { last: number }[] };
        }>(`/markets/quotes?symbols=${underlying}`);
        const q = Array.isArray(quoteRes.quotes.quote)
          ? quoteRes.quotes.quote[0]
          : quoteRes.quotes.quote;
        const last = Number(q.last);
        if (Number.isFinite(last)) this.underlyingPrices.set(underlying, last);

        const expRes = await this.tradierGet<{ expirations: { date: string[] | string } }>(
          `/markets/options/expirations?symbol=${underlying}&includeAllRoots=true`
        );
        const dates = Array.isArray(expRes.expirations?.date)
          ? expRes.expirations.date
          : expRes.expirations?.date
            ? [expRes.expirations.date]
            : [];
        // Nearest 3 expirations is where sweep activity concentrates
        for (const exp of dates.slice(0, 3)) {
          const chainRes = await this.tradierGet<{
            options: { option: { symbol: string; strike: number }[] | null };
          }>(`/markets/options/chains?symbol=${underlying}&expiration=${exp}&greeks=false`);
          const options = chainRes.options?.option ?? [];
          // ±10% of spot keeps the WS subscription within Tradier limits
          const lo = last * 0.9;
          const hi = last * 1.1;
          for (const o of options) {
            if (o.strike >= lo && o.strike <= hi) symbols.push(o.symbol);
          }
        }
      } catch (err) {
        log.error({ underlying, err: String(err) }, "universe refresh failed for symbol");
      }
    }
    this.optionSymbols = symbols;
    log.info({ contracts: symbols.length }, "option universe refreshed");
    // If WS already connected, re-subscribe with the updated universe
    if (this.ws?.readyState === WebSocket.OPEN) await this.subscribe();
  }

  // ---------- production: websocket ----------

  private async createStreamSession(): Promise<string> {
    const res = await fetch(`${TRADIER_HTTP_BASE}/markets/events/session`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.TRADIER_API_KEY}`,
        Accept: "application/json",
      },
    });
    if (!res.ok) throw new Error(`session create failed: ${res.status} ${await res.text()}`);
    const body = (await res.json()) as { stream: { sessionid: string } };
    return body.stream.sessionid;
  }

  private async connectWebSocket(): Promise<void> {
    if (this.stopped) return;
    try {
      const sessionId = await this.createStreamSession();
      this.ws = new WebSocket(TRADIER_WS_URL);

      this.ws.on("open", () => {
        log.info("Tradier WS connected (REALTIME)");
        this.reconnectDelay = 1000;
        void this.subscribe(sessionId);
        this.emit("status", { connected: true, provider: "TRADIER_WS" });
      });

      this.ws.on("message", (raw) => this.handleMessage(raw.toString()));

      this.ws.on("close", () => {
        log.warn("Tradier WS closed — reconnecting");
        this.emit("status", { connected: false, provider: "TRADIER_WS" });
        this.scheduleReconnect();
      });

      this.ws.on("error", (err) => {
        log.error({ err: String(err) }, "Tradier WS error");
        this.ws?.close();
      });
    } catch (err) {
      log.error({ err: String(err) }, "WS connect failed");
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    if (this.stopped) return;
    setTimeout(() => void this.connectWebSocket(), this.reconnectDelay);
    this.reconnectDelay = Math.min(this.reconnectDelay * 2, 30_000); // capped exponential backoff
  }

  private sessionId: string | null = null;

  private async subscribe(sessionId?: string): Promise<void> {
    if (sessionId) this.sessionId = sessionId;
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !this.sessionId) return;
    // Tradier accepts up to ~? symbols per session; chunk defensively at 500
    const payload = {
      symbols: [...WATCHLIST, ...this.optionSymbols].slice(0, 500),
      sessionid: this.sessionId,
      filter: ["timesale", "quote", "trade"],
      linebreak: true,
    };
    this.ws.send(JSON.stringify(payload));
    log.info({ count: payload.symbols.length }, "subscribed");
  }

  private handleMessage(raw: string): void {
    for (const line of raw.split("\n")) {
      if (!line.trim()) continue;
      let msg: TradierTimesale;
      try {
        msg = JSON.parse(line) as TradierTimesale;
      } catch {
        continue;
      }

      if (msg.type === "quote" && msg.symbol) {
        this.quoteCache.set(msg.symbol, { bid: Number(msg.bid ?? 0), ask: Number(msg.ask ?? 0) });
        // underlying equity quote → track spot
        if (WATCHLIST.includes(msg.symbol)) {
          const mid = (Number(msg.bid ?? 0) + Number(msg.ask ?? 0)) / 2;
          if (mid > 0) this.underlyingPrices.set(msg.symbol, mid);
        }
        continue;
      }

      if (msg.type !== "timesale" && msg.type !== "trade") continue;

      const parsed = parseOccSymbol(msg.symbol);
      if (!parsed) continue; // equity timesale, not an option

      const quote = this.quoteCache.get(msg.symbol) ?? { bid: 0, ask: 0 };
      const tick: RawTradeTick = {
        symbol: msg.symbol,
        underlying: parsed.underlying,
        strike: parsed.strike,
        expiration: parsed.expiration,
        optionType: parsed.optionType,
        price: Number(msg.price ?? msg.last ?? 0),
        size: Number(msg.size ?? 0),
        exchange: String(msg.exch ?? "?"),
        bid: quote.bid,
        ask: quote.ask,
        timestampMs: Number(msg.date ?? Date.now()),
      };
      if (tick.size > 0 && tick.price > 0) this.emit("tick", tick);
    }
  }

  // ---------- sandbox: REST poll fallback (DELAYED) ----------

  private startRestPolling(): void {
    this.emit("status", { connected: true, provider: "TRADIER_REST_POLL" });
    this.pollTimer = setInterval(() => void this.pollOnce().catch((e) => log.error(e)), 60_000);
    void this.pollOnce().catch((e) => log.error(e));
  }

  /**
   * Synthesizes ticks from per-contract volume deltas between polls.
   * Approximate by construction; exchange attribution unavailable via REST,
   * so sweep classification degrades to size-based BLOCK/SPLIT only.
   * All events from this path carry freshness=DELAYED.
   */
  private async pollOnce(): Promise<void> {
    for (const underlying of WATCHLIST) {
      try {
        const expRes = await this.tradierGet<{ expirations: { date: string[] | string } }>(
          `/markets/options/expirations?symbol=${underlying}`
        );
        const dates = Array.isArray(expRes.expirations?.date)
          ? expRes.expirations.date
          : expRes.expirations?.date
            ? [expRes.expirations.date]
            : [];
        const exp = dates[0];
        if (!exp) continue;

        const chainRes = await this.tradierGet<{
          options: {
            option:
              | {
                  symbol: string;
                  strike: number;
                  last: number | null;
                  bid: number;
                  ask: number;
                  volume: number;
                }[]
              | null;
          };
        }>(`/markets/options/chains?symbol=${underlying}&expiration=${exp}`);

        for (const o of chainRes.options?.option ?? []) {
          const prev = this.lastVolumes.get(o.symbol) ?? o.volume;
          const delta = o.volume - prev;
          this.lastVolumes.set(o.symbol, o.volume);
          if (delta <= 0 || !o.last) continue;

          const parsed = parseOccSymbol(o.symbol);
          if (!parsed) continue;
          this.emit("tick", {
            symbol: o.symbol,
            underlying: parsed.underlying,
            strike: parsed.strike,
            expiration: parsed.expiration,
            optionType: parsed.optionType,
            price: o.last,
            size: delta,
            exchange: "POLL", // exchange attribution not available via REST
            bid: o.bid,
            ask: o.ask,
            timestampMs: Date.now(),
          } satisfies RawTradeTick);
        }
      } catch (err) {
        log.error({ underlying, err: String(err) }, "poll failed");
      }
    }
  }
}
