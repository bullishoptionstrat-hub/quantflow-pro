import { z } from "zod";
import type { DataFreshness } from "@quantflow/shared";

const EnvSchema = z.object({
  TRADIER_API_KEY: z.string().min(1).optional(),
  TRADIER_ENV: z.enum(["production", "sandbox"]).default("sandbox"),
  WATCHLIST: z.string().default("SPY,QQQ,TSLA,NVDA,AAPL,MSFT,AMZN,META,AMD,GOOGL"),
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  UPSTASH_REDIS_REST_URL: z.string().url().optional(),
  UPSTASH_REDIS_REST_TOKEN: z.string().optional(),
  PORT: z.coerce.number().default(8080),
  /**
   * DEMO mode generates synthetic ticks for local UI development.
   * Hard-blocked when NODE_ENV=production — the process exits rather than
   * serving fake data labeled as anything.
   */
  DEMO_MODE: z
    .string()
    .default("false")
    .transform((v) => v === "true"),
  NODE_ENV: z.string().default("development"),
  UNUSUAL_VOLUME_MULTIPLIER: z.coerce.number().default(3),
  GROUP_WINDOW_MS: z.coerce.number().default(500),
  BLOCK_SIZE_THRESHOLD: z.coerce.number().default(250),
  SPLIT_SIZE_THRESHOLD: z.coerce.number().default(100),
  CORS_ORIGIN: z.string().default("*"),
});

const parsed = EnvSchema.safeParse(process.env);
if (!parsed.success) {
  // eslint-disable-next-line no-console
  console.error("FATAL: invalid environment:", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const config = parsed.data;

if (config.DEMO_MODE && config.NODE_ENV === "production") {
  // eslint-disable-next-line no-console
  console.error("FATAL: DEMO_MODE=true is forbidden in production. Refusing to start.");
  process.exit(1);
}

if (!config.DEMO_MODE && !config.TRADIER_API_KEY) {
  // eslint-disable-next-line no-console
  console.error(
    "FATAL: TRADIER_API_KEY missing and DEMO_MODE=false. Provide a token or explicitly enable DEMO_MODE for local dev."
  );
  process.exit(1);
}

/** Production Tradier token + streaming session = REALTIME. Everything else is DELAYED or DEMO. */
export function resolveFreshness(): DataFreshness {
  if (config.DEMO_MODE) return "DEMO";
  return config.TRADIER_ENV === "production" ? "REALTIME" : "DELAYED";
}

export const TRADIER_HTTP_BASE =
  config.TRADIER_ENV === "production"
    ? "https://api.tradier.com/v1"
    : "https://sandbox.tradier.com/v1";

export const TRADIER_WS_URL = "wss://ws.tradier.com/v1/markets/events";

export const WATCHLIST = config.WATCHLIST.split(",")
  .map((s) => s.trim().toUpperCase())
  .filter(Boolean);
