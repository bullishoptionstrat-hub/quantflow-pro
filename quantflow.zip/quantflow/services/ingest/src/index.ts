import express from "express";
import http from "http";
import { Server as SocketIOServer } from "socket.io";
import { createClient } from "@supabase/supabase-js";
import fetch from "node-fetch";
import { WS_EVENTS, type FlowEvent, type FeedStatus } from "@quantflow/shared";
import { config, resolveFreshness } from "./config";
import { log } from "./logger";
import { createKV } from "./redis";
import { TradierFeed } from "./tradier";
import { DemoFeed } from "./demo";
import { FlowGrouper } from "./grouper";
import { syncFinraWeekly, recomputeLevels, rollBaselines, recomputeGex } from "./jobs";

const db = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});
const kv = createKV();

// ---------- HTTP + Socket.IO relay ----------
const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: { origin: config.CORS_ORIGIN, methods: ["GET", "POST"] },
});

let feedStatus: FeedStatus = {
  connected: false,
  freshness: resolveFreshness(),
  provider: config.DEMO_MODE ? "DEMO" : config.TRADIER_ENV === "production" ? "TRADIER_WS" : "TRADIER_REST_POLL",
  last_event_at: null,
  message: "starting",
};

app.get("/health", (_req, res) => {
  res.json({ ok: true, feed: feedStatus, uptime_s: Math.round(process.uptime()) });
});

// ML service → relay → all Socket.IO clients
app.use(express.json());
app.post("/internal/power-alert", (req, res) => {
  const secret = process.env.ML_WEBHOOK_SECRET ?? "";
  if (secret && req.headers["x-webhook-secret"] !== secret) {
    return res.status(401).json({ error: "bad secret" });
  }
  io.emit(WS_EVENTS.POWER_ALERT, req.body);
  return res.json({ ok: true });
});

io.on("connection", (socket) => {
  socket.emit(WS_EVENTS.FEED_STATUS, feedStatus);
});

// ---------- alert rule matching ----------
async function dispatchAlerts(event: FlowEvent): Promise<void> {
  const { data: rules, error } = await db
    .from("alert_rules")
    .select("*")
    .or(`underlying.is.null,underlying.eq.${event.underlying}`);
  if (error || !rules) return;

  for (const rule of rules) {
    if (event.total_premium < Number(rule.min_premium)) continue;
    if (rule.order_types.length > 0 && !rule.order_types.includes(event.order_type)) continue;
    if (rule.sentiments.length > 0 && !rule.sentiments.includes(event.sentiment)) continue;
    if (rule.unusual_only && !event.is_unusual) continue;

    let delivered = false;
    if (rule.webhook_url) {
      try {
        const text =
          `${event.is_unusual ? "🔶 UNUSUAL " : ""}${event.order_type} — ${event.underlying} ` +
          `$${event.strike} ${event.option_type.toUpperCase()} exp ${event.expiration} | ` +
          `${event.total_size} contracts | $${(event.total_premium / 1000).toFixed(0)}K premium | ` +
          `${event.sentiment} | data: ${event.freshness}`;
        const isDiscord = rule.webhook_url.includes("discord.com");
        await fetch(rule.webhook_url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(isDiscord ? { content: text } : { text }),
        });
        delivered = true;
      } catch (err) {
        log.warn({ rule: rule.id, err: String(err) }, "webhook delivery failed");
      }
    }

    await db.from("alert_log").insert({
      rule_id: rule.id,
      flow_event_id: event.id,
      delivered,
      channel: rule.webhook_url ? "webhook" : "browser",
    });
  }
}

// ---------- pipeline ----------
async function persistAndBroadcast(e: Omit<FlowEvent, "id" | "created_at">): Promise<void> {
  const { data, error } = await db.from("options_flow").insert(e).select().single();
  if (error) {
    log.error({ error }, "flow insert failed");
    return;
  }
  const event = data as FlowEvent;
  feedStatus = { ...feedStatus, last_event_at: event.created_at };
  io.emit(WS_EVENTS.FLOW_UPDATE, event);
  void dispatchAlerts(event).catch((err) => log.error({ err: String(err) }, "alert dispatch"));
}

const feed = config.DEMO_MODE ? new DemoFeed() : new TradierFeed();
const grouper = new FlowGrouper(
  kv,
  persistAndBroadcast,
  (u) => feed.getUnderlyingPrice(u)
);

feed.on("tick", (tick) => grouper.ingest(tick));
feed.on("status", (s: Partial<FeedStatus>) => {
  feedStatus = { ...feedStatus, ...s, freshness: resolveFreshness(), message: "ok" };
  io.emit(WS_EVENTS.FEED_STATUS, feedStatus);
});

// ---------- scheduled jobs ----------
setInterval(() => void syncFinraWeekly(db), 6 * 60 * 60_000); // 4x/day is plenty for weekly data
setInterval(() => void recomputeLevels(db, (u) => feed.getUnderlyingPrice(u)), 60 * 60_000);
// GEX hourly — ORATS greeks refresh ~hourly anyway; more often is wasted quota
setInterval(() => void recomputeGex(db, (u) => feed.getUnderlyingPrice(u)), 60 * 60_000);
// nightly baseline roll at ~00:10 ET — simple check every 5 min
setInterval(() => {
  const now = new Date();
  const et = new Date(now.toLocaleString("en-US", { timeZone: "America/New_York" }));
  if (et.getHours() === 0 && et.getMinutes() < 5) void rollBaselines(db, kv);
}, 5 * 60_000);

// ---------- start ----------
server.listen(config.PORT, () => {
  log.info(
    { port: config.PORT, env: config.TRADIER_ENV, demo: config.DEMO_MODE, freshness: resolveFreshness() },
    "quantflow-ingest up"
  );
});
void feed.start();
void syncFinraWeekly(db);
setTimeout(() => void recomputeGex(db, (u) => feed.getUnderlyingPrice(u)), 30_000); // initial GEX after feed warms

process.on("SIGTERM", () => {
  feed.stop();
  grouper.stop();
  server.close(() => process.exit(0));
});
