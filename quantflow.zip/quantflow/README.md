# QuantFlow Terminal

Options flow scanner — sweep/block/split detection, unusual-activity flagging, FINRA ATS volume, flow-derived price levels, ML power alerts, custom alert rules. Free-tier stack: Next.js 14 + Supabase + Upstash + Tradier + Socket.IO + FastAPI.

```
quantflow/
├── apps/web/              Next.js 14 frontend (Vercel)
├── services/ingest/       Node tick ingestion + Socket.IO relay + cron jobs (Render)
├── services/ml/           Python FastAPI scorer + offline trainer (Render)
├── packages/shared/       Canonical TypeScript types — every service imports from here
└── supabase/migrations/   Postgres schema, RLS, realtime publication
```

## Read this before anything else — data honesty

Two claims in the common "free FlowAlgo clone" spec are false. This build corrects both instead of papering over them:

1. **There is no free real-time (or even daily) dark pool print feed.** FINRA publishes ATS data as **weekly per-symbol aggregates, delayed 2–4 weeks**. The `/darkpool` page is labeled "ATS Volume," carries a delay banner, and the API returns a provenance block. Paid products showing "dark pool prints" license real-time TRF data — that does not exist at $0.
2. **Tradier real-time requires a funded brokerage account.** Sandbox tokens are delayed and cannot open WebSocket streaming sessions. So every event carries a first-class `freshness` field: `REALTIME` (production token, streaming), `DELAYED` (sandbox REST polling fallback — exchange attribution is degraded, so sweep-vs-split classification is weaker), or `DEMO` (synthetic, dev only). The UI shows the badge everywhere. `DEMO_MODE=true` with `NODE_ENV=production` makes the ingest process **exit on boot**.

The ML scorer never scores `DEMO` events, refuses to train on fewer than 500 real events, and refuses to export a model with walk-forward AUC < 0.55. Until a model passes, alerts run in a clearly labeled `HEURISTIC` mode with stated weights.

## How an event flows

```
Tradier WS/REST → ingest (parse OCC tick)
  → 500ms grouping window (Redis)
  → classify SWEEP / BLOCK / SPLIT, aggressor side → sentiment
  → unusual flag vs 20-day contract baseline
  → INSERT options_flow (Supabase) + Socket.IO "flow_update"
       ↓ Supabase Database Webhook
     ML /score → power_alerts INSERT → ingest /internal/power-alert → "power_alert" to clients
  → alert_rules matched → Discord/Telegram webhook + alert_log
```

Cron inside ingest: FINRA ATS sync every 6h · flow levels recompute hourly · GEX recompute hourly (Tradier chains greeks=true, skipped without a key — no synthetic GEX) · contract volume baselines roll nightly (~00:10 ET).

## Local development

Prereqs: Node 20+, Python 3.11+, a Supabase project.

```bash
# 1. Install
npm install

# 2. Database — run BOTH migrations in order in the Supabase SQL editor:
#    supabase/migrations/0001_init.sql, then supabase/migrations/0002_v1_1.sql

# 3. Environment
cp .env.example .env            # fill in Supabase values at minimum
# For UI work with no Tradier account: DEMO_MODE=true

# 4. Run ingest (terminal 1)
npm run dev:ingest              # http://localhost:4000/health

# 5. Run web (terminal 2)
npm run dev:web                 # http://localhost:3000

# 6. (Optional) ML service (terminal 3)
cd services/ml && pip install -r requirements.txt
uvicorn main:app --port 8000    # http://localhost:8000/health reports MODEL vs HEURISTIC

# Typecheck everything
npm run typecheck

# Build everything
npm run build
```

Expected results: `/health` on ingest returns feed provider + freshness; the dashboard shows the feed status bar with a `DEMO`/`DELAYED`/`REALTIME` badge; with `DEMO_MODE=true` synthetic sweeps stream within ~2s.

## Training the ML model

```bash
cd services/ml
python train.py
```

Requires ≥500 non-demo unusual events in `options_flow` (refuses below that). Labels = |underlying move| > 3% within 5 trading days (closes fetched from Tradier). Walk-forward `TimeSeriesSplit` CV — never random shuffle. Exports `model.pkl` + `metrics.json` only if mean AUC ≥ 0.55; otherwise it tells you there is no demonstrated edge and exits. Restart the service to pick up the model (`/health` flips to `MODEL`).

## Pages

| Route | What it actually is |
|---|---|
| `/` | Live flow feed, filters, watchlist, symbol detail w/ chart + levels |
| `/screener` | Top 50 watchlist symbols today by premium / unusual count / net flow, hourly sparklines |
| `/darkpool` | FINRA ATS **weekly aggregates** with delay banner — not prints |
| `/levels/[symbol]` | 90-day daily chart + flow volume-at-price levels + GEX-by-strike panel |
| `/alerts` | Rule builder (auth required), webhook delivery (Discord/Telegram only), history log |
| `/calculator` | Black-Scholes P/L modeling, position greeks, POP/EV, defined-risk optimizer (EV-ranked), saved strategies |

## Analytics models (and their honesty contracts)

**Optimizer EV/POP — market-implied density.** Candidates are ranked by expected
value under the risk-neutral density recovered from the chain's own smile
(Breeden–Lit­zenberger: f(K) = e^{rT}·∂²C/∂K²). The smile is a quadratic fit in
log-moneyness with C∞ softplus wing saturation — interpolated smiles put kinks
at every strike knot and BL turns each kink into negative-density garbage
(observed, fixed, regression-tested). Health gates: negative-mass fraction
< 5% and density mean within 3% of the forward (martingale check); failures
fall back to lognormal-at-ATM-IV **and the response says which model ran, per
expiration**. Validation: flat smile reproduces lognormal to the penny; a
fairly-priced contract shows EV ≈ carry; a mid-priced live ATM call shows
EV ≈ 0. ROI-at-target is still reported — it answers "what if my thesis is
exactly right," EV answers "across everything the market thinks can happen."
The canonical example from live testing: a 1567%-ROI butterfly with 4% POP and
negative EV — visible as the lottery ticket it is instead of topping the list.

**Quote anomalies.** Candidates priced far below model value (stale/crossed
quotes — routine on DELAYED feeds with per-contract timestamps) are ⚠-flagged,
not hidden and not silently trusted.

**Expected move.** ATM straddle mid per expiration, returned with every scan.

## Known limits (free tier)

- ~50 concurrent users before Supabase/Upstash free tiers throttle.
- Render free instances sleep after 15 min idle — keep-alive cron required (see DEPLOYMENT.md).
- Sandbox mode: 60s polling granularity, synthetic ticks from volume deltas, weaker sweep classification.
- Screener has no sector/market-cap filters — no free reference-data source; coverage = ingest `WATCHLIST`.
- Vercel SSE route (`/api/flow/live`) is capped by function duration; Socket.IO via the ingest service is the primary real-time path.

## Disclaimer

Market data tooling for research and education. Not financial advice, not a signal service, no performance claims. The heuristic scorer is explicitly unvalidated; the ML gate exists precisely because edge must be proven, not assumed.

See **DEPLOYMENT.md** for production deployment (Vercel + Render + Supabase + Upstash).
