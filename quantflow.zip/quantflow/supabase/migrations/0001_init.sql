-- QuantFlow Terminal — initial schema
-- Apply: supabase db push  (or paste into SQL editor)
-- Provenance rule: every market-data row carries a freshness/source column. Nothing untagged.

create extension if not exists "pgcrypto";

-- ============================================================
-- options_flow — finalized, grouped flow events from ingestion
-- ============================================================
create table if not exists options_flow (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  symbol text not null,                  -- OCC contract symbol
  underlying text not null,
  strike numeric not null,
  expiration date not null,
  option_type text not null check (option_type in ('call','put')),
  order_type text not null check (order_type in ('SWEEP','BLOCK','SPLIT')),
  total_size integer not null check (total_size > 0),
  total_premium numeric not null check (total_premium >= 0),
  avg_price numeric not null,
  exchange_count integer not null,
  sentiment text not null check (sentiment in ('BULLISH','BEARISH','NEUTRAL')),
  is_unusual boolean not null default false,
  days_to_expiry integer not null,
  iv numeric,
  underlying_price numeric,
  otm_percentage numeric,
  freshness text not null default 'DELAYED' check (freshness in ('REALTIME','DELAYED','DEMO'))
);

create index if not exists idx_flow_created on options_flow (created_at desc);
create index if not exists idx_flow_underlying_created on options_flow (underlying, created_at desc);
create index if not exists idx_flow_unusual on options_flow (created_at desc) where is_unusual;
create index if not exists idx_flow_premium on options_flow (total_premium desc);

-- ============================================================
-- contract_volume_baseline — rolling 20d average volume per contract
-- maintained by ingest service; used for the 3x unusual flag
-- ============================================================
create table if not exists contract_volume_baseline (
  symbol text primary key,
  avg_daily_volume numeric not null default 0,
  sample_days integer not null default 0,
  updated_at timestamptz not null default now()
);

-- ============================================================
-- dark_pool_weekly — FINRA ATS weekly aggregates.
-- HONEST LABEL: FINRA does not publish real-time prints for free.
-- This table stores weekly per-symbol ATS volume, delayed 2–4 weeks.
-- ============================================================
create table if not exists dark_pool_weekly (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  symbol text not null,
  week_start date not null,
  total_shares bigint not null,
  total_trades bigint not null,
  ats_count integer not null default 0,
  avg_trade_size numeric not null default 0,
  source text not null default 'FINRA_ATS_WEEKLY',
  unique (symbol, week_start)
);

create index if not exists idx_dp_symbol_week on dark_pool_weekly (symbol, week_start desc);

-- ============================================================
-- flow_levels — volume-at-price derived from options_flow history
-- recomputed by ingest service hourly
-- ============================================================
create table if not exists flow_levels (
  id uuid primary key default gen_random_uuid(),
  symbol text not null,
  price_level numeric not null,
  total_volume bigint not null,
  level_type text not null check (level_type in ('support','resistance','accumulation')),
  last_updated timestamptz not null default now(),
  unique (symbol, price_level, level_type)
);

create index if not exists idx_levels_symbol on flow_levels (symbol);

-- ============================================================
-- alert_rules — user-defined push/webhook alerts
-- ============================================================
create table if not exists alert_rules (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_email text not null,
  underlying text,                       -- null = all symbols
  min_premium numeric not null default 0,
  order_types text[] not null default '{}',
  sentiments text[] not null default '{}',
  unusual_only boolean not null default false,
  webhook_url text
);

create index if not exists idx_alert_rules_email on alert_rules (user_email);

-- ============================================================
-- alert_log — fired alert history
-- ============================================================
create table if not exists alert_log (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  rule_id uuid references alert_rules(id) on delete cascade,
  flow_event_id uuid references options_flow(id) on delete set null,
  delivered boolean not null default false,
  channel text not null check (channel in ('browser','webhook'))
);

-- ============================================================
-- power_alerts — ML service output, with scoring provenance
-- ============================================================
create table if not exists power_alerts (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  flow_event_id uuid not null references options_flow(id) on delete cascade,
  underlying text not null,
  score numeric not null check (score between 0 and 1),
  scoring_mode text not null check (scoring_mode in ('MODEL','HEURISTIC')),
  features jsonb not null default '{}'::jsonb
);

create index if not exists idx_power_alerts_created on power_alerts (created_at desc);

-- ============================================================
-- RLS — anon key gets read-only on market data; writes require service role
-- ============================================================
alter table options_flow enable row level security;
alter table dark_pool_weekly enable row level security;
alter table flow_levels enable row level security;
alter table power_alerts enable row level security;
alter table alert_rules enable row level security;
alter table alert_log enable row level security;
alter table contract_volume_baseline enable row level security;

create policy "public read flow" on options_flow for select using (true);
create policy "public read darkpool" on dark_pool_weekly for select using (true);
create policy "public read levels" on flow_levels for select using (true);
create policy "public read power alerts" on power_alerts for select using (true);

-- alert rules are private to the owning email; web app queries with service role
-- and enforces ownership in the API layer (NextAuth session email).
-- No anon access:
-- (no select policy for anon on alert_rules / alert_log / contract_volume_baseline)

-- Realtime publication for the ML service + cross-tab sync
alter publication supabase_realtime add table options_flow;
alter publication supabase_realtime add table power_alerts;
