-- ============================================================
-- 0002 — v1.1: Heat Score, GEX levels, saved strategies
-- Run after 0001_init.sql.
-- ============================================================

-- Heat Score: 0–100 fill-aggression metric, computed at grouping time.
alter table options_flow
  add column if not exists heat_score smallint not null default 0
  check (heat_score >= 0 and heat_score <= 100);

create index if not exists idx_flow_heat
  on options_flow (heat_score desc, created_at desc);

-- ============================================================
-- gex_levels — net dealer gamma exposure per strike
-- Source: Tradier option chains with greeks=true (ORATS-computed).
-- ORATS greeks refresh ~hourly; this is positioning context, not ticks.
-- ============================================================
create table if not exists gex_levels (
  id uuid primary key default gen_random_uuid(),
  computed_at timestamptz not null default now(),
  underlying text not null,
  strike numeric not null,
  net_gex numeric not null,
  call_gex numeric not null,
  put_gex numeric not null,
  level_type text not null check (level_type in ('wall','flip','support','resistance')),
  spot_price numeric not null,
  expirations_included integer not null,
  freshness text not null check (freshness in ('REALTIME','DELAYED','DEMO')),
  unique (underlying, strike)
);

create index if not exists idx_gex_underlying on gex_levels (underlying, strike);

-- ============================================================
-- saved_strategies — OptionStrat-style saved multi-leg positions
-- Auth model matches alert_rules: NextAuth email, service-role writes,
-- no anon access (RLS default-deny after enable).
-- ============================================================
create table if not exists saved_strategies (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  user_email text not null,
  underlying text not null,
  strategy_name text not null,
  legs jsonb not null,
  entry_cost numeric not null,
  notes text,
  status text not null default 'open' check (status in ('open','closed'))
);

create index if not exists idx_strategies_user on saved_strategies (user_email, created_at desc);

alter table gex_levels enable row level security;
alter table saved_strategies enable row level security;

-- GEX is public market context, same as flow_levels.
create policy "public read gex" on gex_levels for select using (true);
-- saved_strategies: no policies → anon/authenticated denied; service role bypasses RLS.
