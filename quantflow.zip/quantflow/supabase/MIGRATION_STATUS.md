## Migration status — quantflow-pro (hxslcxxgconuyqttzbfz)

Both migrations were applied via the Supabase MCP on 2026-06-10 and verified:

| Migration | Applied as | Verified |
|---|---|---|
| 0001_init.sql | `init_quantflow_schema` | 9 tables, RLS on all, 5 public-read policies, realtime on options_flow + power_alerts |
| 0002_v1_1.sql | `v1_1_heat_gex_strategies` | heat_score smallint default 0, gex_levels, saved_strategies (default-deny RLS) |

Smoke-tested: options_flow insert with full ingest field set + power_alerts FK +
`on delete cascade` confirmed, then cleaned (0 rows).

Do NOT re-run these files against this project; `create ... if not exists` makes
them idempotent, but the migration history table already records them.

## Data seeded 2026-06-10 (real data, not mock)

| Table | Rows | Source | Notes |
|---|---|---|---|
| gex_levels | 386 (10 symbols, 1 flip each) | Tradier sandbox chains, greeks=true | freshness=DELAYED; same formula as `recomputeGex` |
| dark_pool_weekly | 70 (10 symbols × 7 weeks, 2026-04-06 → 2026-05-18) | FINRA ATS_W_SMBL_FIRM | per-firm sums cross-checked exactly against symbol-level totals |

## FINRA sync bugs found via live API testing (fixed in jobs.ts)

1. **Multiple EQUAL compareFilters on one field are AND, not OR** → empty 200.
   The original watchlist query returned zero rows silently. Fix: `domainFilters`.
2. **Missing summaryTypeCode filter** → dataset mixes ATS rows with non-ATS OTC
   (wholesaler internalization), inflating "dark pool" volume. Fix: `ATS_W_SMBL_FIRM`
   (per-firm rows: correct totals + MPIDs for ats_count in one pass).
3. **No date bound + arbitrary ordering** (sorting requires partition keys) →
   row budget spent on stale weeks. Fix: `weekStartDate GTE now-70d`.
