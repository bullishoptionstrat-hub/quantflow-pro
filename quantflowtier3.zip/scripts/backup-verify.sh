#!/usr/bin/env bash
#
# BACKUP INTEGRITY + RESTORE DRILL
#
# WHY THIS EXISTS
# ---------------
# The Tier-2 backup workflow produced a dump and stopped there. A backup that
# has never been restored is not a backup — it is an untested assumption with a
# filename. Supabase's Free plan has NO automatic backups and NO point-in-time
# recovery, so this dump is the ONLY recovery path that exists.
#
# WHAT IT DOES
#   1. verifies the archive decompresses and is not truncated
#   2. records SHA-256 so a corrupted copy fails loudly instead of silently
#   3. RESTORES into a THROWAWAY database and asserts the schema arrived
#   4. asserts row counts are readable post-restore
#
# SAFETY: it refuses to run against any database whose name does not begin with
# `restoredrill_`, so it can never overwrite production.
#
# Usage:
#   scripts/backup-verify.sh <dump.sql.gz> [PGHOST] [PGPORT] [PGUSER]
set -euo pipefail

DUMP="${1:?usage: backup-verify.sh <dump.sql.gz> [host] [port] [user]}"
PGHOST="${2:-/tmp}"
PGPORT="${3:-54329}"
PGUSER="${4:-postgres}"
DRILL_DB="restoredrill_$(date -u +%Y%m%d%H%M%S)_$$"

fail() { echo "BACKUP-VERIFY FAILED: $*" >&2; exit 1; }

case "$DRILL_DB" in
  restoredrill_*) ;;
  *) fail "refusing to restore into '$DRILL_DB' — drill databases must be prefixed restoredrill_" ;;
esac

echo "== 1. archive integrity =="
[ -f "$DUMP" ] || fail "dump not found: $DUMP"
SIZE=$(stat -c%s "$DUMP")
[ "$SIZE" -gt 512 ] || fail "dump is only ${SIZE} bytes — treating as failed"
gunzip -t "$DUMP" || fail "gzip integrity check failed (truncated or corrupt)"
SHA=$(sha256sum "$DUMP" | cut -d' ' -f1)
echo "   size=${SIZE} bytes"
echo "   sha256=${SHA}"

echo "== 2. content sanity =="
# NOTE: do NOT use `grep -q` inside a pipe here. Under `set -o pipefail`,
# grep -q exits on the first match, gunzip takes SIGPIPE, and the pipeline
# reports failure intermittently — a flaky verifier is worse than none.
# Decompress once to a temp file and inspect that instead.
PLAIN=$(mktemp /tmp/backup-verify.XXXXXX.sql)
trap 'rm -f "$PLAIN"' EXIT
gunzip -c "$DUMP" > "$PLAIN" || fail "decompression failed"
TABLES_IN_DUMP=$(grep -cE '^CREATE TABLE' "$PLAIN" || true)
DATA_STMTS=$(grep -cE '^(COPY |INSERT INTO)' "$PLAIN" || true)
if [ "$TABLES_IN_DUMP" -eq 0 ] && [ "$DATA_STMTS" -eq 0 ]; then
  fail "dump contains no CREATE TABLE / COPY / INSERT — it is not a real backup"
fi
echo "   CREATE TABLE statements: ${TABLES_IN_DUMP}"
echo "   data statements (COPY/INSERT): ${DATA_STMTS}"

echo "== 3. restore into throwaway database ${DRILL_DB} =="
psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -q -c "CREATE DATABASE ${DRILL_DB};" \
  || fail "could not create drill database"
trap 'rm -f "$PLAIN"; psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d postgres -q -c "DROP DATABASE IF EXISTS ${DRILL_DB};" >/dev/null 2>&1 || true' EXIT

# A pg_dump taken with --schema=public emits `CREATE SCHEMA public`, which
# collides with the public schema every fresh database already has. Restoring
# into a virgin database therefore fails with ON_ERROR_STOP.
# THIS DRILL CAUGHT THAT — the Tier-2 backup workflow produced dumps that could
# not actually be restored. Drop the default schema so the dump owns it.
# TWO REAL DEFECTS THIS DRILL CAUGHT in the Tier-2 backup workflow:
#
#  (a) a `--schema=public` dump emits `CREATE SCHEMA public`, which collides
#      with the public schema every database already has;
#  (b) the same dump REFERENCES extension functions (public.uuid_generate_v4)
#      but does not carry the CREATE EXTENSION statements that define them,
#      because extensions live outside the public schema.
#
# On Supabase both are invisible: the target project already has public and has
# extensions pre-provisioned. They only surface on a genuine restore elsewhere —
# which is precisely the scenario a disaster recovery has to survive.
#
# The drill therefore reproduces a REALISTIC Supabase-like target: keep the
# default public schema, provision the extensions the dump references, and drop
# the redundant CREATE SCHEMA line from the SQL.
for ext in "uuid-ossp" pgcrypto; do
  psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -q \
    -c "CREATE EXTENSION IF NOT EXISTS \"$ext\" WITH SCHEMA public;" >/dev/null 2>&1 || true
done
EXTS=$(psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -tAc \
  "select string_agg(extname,',') from pg_extension where extname <> 'plpgsql';")
echo "   provisioned extensions: ${EXTS:-none}"

# Strip the redundant schema creation/ownership lines.
sed -i -E '/^CREATE SCHEMA public;$/d; /^ALTER SCHEMA public OWNER TO/d; /^COMMENT ON SCHEMA public IS/d' "$PLAIN"

set +e
psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -v ON_ERROR_STOP=1 -q -f "$PLAIN" > /tmp/restore.out 2>&1
RC=$?
set -e
[ $RC -eq 0 ] || { tail -20 /tmp/restore.out >&2; fail "psql restore exited ${RC}"; }
echo "   restore completed without error"

echo "== 4. post-restore assertions =="
RESTORED_TABLES=$(psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -tAc \
  "select count(*) from information_schema.tables where table_schema='public';")
echo "   tables in public schema: ${RESTORED_TABLES}"
[ "$RESTORED_TABLES" -gt 0 ] || fail "restore produced zero tables"

echo "   per-table row counts:"
psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -tAc \
  "select table_name from information_schema.tables where table_schema='public' order by 1;" |
while read -r t; do
  [ -z "$t" ] && continue
  n=$(psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$DRILL_DB" -tAc "select count(*) from public.\"$t\";")
  printf "     %-32s %s rows\n" "$t" "$n"
done

echo "== 5. integrity record =="
cat <<JSON
{
  "dump": "$(basename "$DUMP")",
  "verifiedAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "sizeBytes": ${SIZE},
  "sha256": "${SHA}",
  "createTableStatements": ${TABLES_IN_DUMP},
  "restoredTables": ${RESTORED_TABLES},
  "restoreVerified": true
}
JSON
echo "BACKUP-VERIFY PASSED"
