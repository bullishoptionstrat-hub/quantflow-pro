-- ============================================================================
-- SIGNAL + OUTCOME PERSISTENCE  (Tier-3, GATE H)
--
-- The flow-engine has shipped an OutcomeTracker since Tier-2, but it was never
-- connected to storage — it ran against an in-memory Map and every graded
-- outcome was lost on restart. The single differentiator no competitor offers
-- (published, auditable hit rates) is worthless without durable history, and
-- history cannot be back-filled: it only accrues going forward.
--
-- DESIGN RULES
--  * signals are IMMUTABLE. Corrections arrive as new rows, never UPDATEs, so
--    a signal can never be silently rewritten after its outcome is known.
--  * algorithm_version and feature_version are stored ON the signal, so a
--    threshold change does not retroactively relabel history.
--  * both event time and ingestion time are stored; research keys on event time
--    while operations key on ingestion time.
--  * outcomes record MISSING marks explicitly rather than interpolating.
-- ============================================================================

create table if not exists public.signals (
  -- Deterministic id from the engine (audit trail back to the source prints).
  id                  text primary key,

  -- WHEN. Three distinct clocks; never conflate them.
  event_at            timestamptz not null,   -- first print in the cluster
  received_at         timestamptz,            -- when our process saw it
  persisted_at        timestamptz not null default now(),

  -- WHAT
  underlying          text not null,
  kind                text not null,          -- SWEEP | BLOCK | SPLIT | MULTI_LEG | LARGE
  side                text not null,          -- BUY | SELL | *_LEAN | AMBIGUOUS
  total_premium       numeric not null,
  total_size          integer not null,
  iso                 boolean not null default false,
  legs                jsonb   not null,
  print_ids           jsonb   not null,       -- audit trail

  -- SCORING (descriptive, not predictive)
  score               numeric,
  score_breakdown     jsonb,
  classification_confidence numeric,

  -- GOVERNANCE
  algorithm_version   text not null,
  feature_version     text,

  -- PROVENANCE / QUALITY
  source              text not null,
  source_environment  text,
  synthetic           boolean not null default false,
  quality_state       text,
  quality_flags       text[] not null default '{}',
  provenance          jsonb,

  constraint signals_side_valid check (side in ('BUY','SELL','BUY_LEAN','SELL_LEAN','AMBIGUOUS')),
  constraint signals_kind_valid check (kind in ('SWEEP','BLOCK','SPLIT','MULTI_LEG','LARGE'))
);

-- Research queries key on EVENT time, not insertion time.
create index if not exists idx_signals_event_at on public.signals (event_at desc);
create index if not exists idx_signals_underlying_event on public.signals (underlying, event_at desc);
create index if not exists idx_signals_kind_event on public.signals (kind, event_at desc);
-- Synthetic events must be trivially excludable from every research query.
create index if not exists idx_signals_real_only on public.signals (event_at desc) where synthetic = false;

-- ---------------------------------------------------------------------------
-- Outcomes: one row per (signal, horizon). Immutable once graded.
-- ---------------------------------------------------------------------------
create table if not exists public.signal_outcomes (
  id                  uuid primary key default gen_random_uuid(),
  signal_id           text not null references public.signals(id) on delete cascade,

  horizon             text not null,          -- M5 M15 M30 H1 EOD D1 D3 D5 EXPIRY
  due_at              timestamptz not null,
  evaluated_at        timestamptz,

  -- Marks. NULL means UNAVAILABLE — never interpolated, never zero.
  entry_underlying    numeric,
  entry_contract      numeric,
  mark_underlying     numeric,
  mark_contract       numeric,

  underlying_move_pct numeric,
  contract_return_pct numeric,

  -- Excursions (Phase 35) — far more informative than a single final label.
  mfe_pct             numeric,                -- max favourable excursion
  mae_pct             numeric,                -- max adverse excursion

  -- Expected-move normalisation (Phase 36), when defensibly computable.
  expected_move_pct   numeric,
  move_vs_expected    numeric,

  label               text,                   -- POSITIVE NEGATIVE NEUTRAL UNGRADED
  missing_data_flags  text[] not null default '{}',
  algorithm_version   text not null,
  created_at          timestamptz not null default now(),

  constraint outcomes_label_valid check (label is null or label in ('POSITIVE','NEGATIVE','NEUTRAL','UNGRADED')),
  unique (signal_id, horizon)
);

create index if not exists idx_outcomes_signal on public.signal_outcomes (signal_id);
create index if not exists idx_outcomes_due on public.signal_outcomes (due_at) where evaluated_at is null;
create index if not exists idx_outcomes_horizon_label on public.signal_outcomes (horizon, label);

-- ---------------------------------------------------------------------------
-- Immutability: block UPDATE/DELETE on signals so history cannot be rewritten.
-- ---------------------------------------------------------------------------
create or replace function public.reject_signal_mutation() returns trigger
language plpgsql as $$
begin
  raise exception
    'signals is append-only: % on signal % is rejected. Emit a corrected signal instead.',
    tg_op, coalesce(old.id, new.id);
end;
$$;

drop trigger if exists trg_signals_immutable on public.signals;
create trigger trg_signals_immutable
  before update or delete on public.signals
  for each row execute function public.reject_signal_mutation();

-- ---------------------------------------------------------------------------
-- Honest aggregate view. Never hides UNGRADED — a hit rate that silently drops
-- the events it could not measure is a selection-biased number.
-- ---------------------------------------------------------------------------
create or replace view public.v_signal_performance as
select
  s.kind,
  o.horizon,
  count(*)                                              as n_total,
  count(*) filter (where o.label = 'UNGRADED')          as n_ungraded,
  count(*) filter (where o.label in ('POSITIVE','NEGATIVE','NEUTRAL')) as n_graded,
  count(*) filter (where o.label = 'POSITIVE')          as n_positive,
  -- Hit rate is over GRADED only, and n_ungraded sits beside it so the reader
  -- can see what was excluded.
  case when count(*) filter (where o.label in ('POSITIVE','NEGATIVE','NEUTRAL')) > 0
       then count(*) filter (where o.label = 'POSITIVE')::numeric
            / count(*) filter (where o.label in ('POSITIVE','NEGATIVE','NEUTRAL'))
  end                                                   as hit_rate_graded,
  percentile_cont(0.5) within group (order by o.contract_return_pct) as median_contract_return,
  percentile_cont(0.5) within group (order by o.mfe_pct)             as median_mfe,
  percentile_cont(0.5) within group (order by o.mae_pct)             as median_mae
from public.signals s
join public.signal_outcomes o on o.signal_id = s.id
where s.synthetic = false          -- research NEVER includes synthetic events
group by s.kind, o.horizon;

alter table public.signals enable row level security;
alter table public.signal_outcomes enable row level security;
create policy "signals_public_read" on public.signals for select using (true);
create policy "outcomes_public_read" on public.signal_outcomes for select using (true);
