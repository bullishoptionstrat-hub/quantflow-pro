# Flow Engine Consolidation (Phase 2 — GATE D)

**Date:** 2026-08-20

## The problem: four classifiers, one product

| Implementation | Location | Reachable from production? |
|---|---|---|
| `classifyPrint()` | `backend/src/ingestion/sweepDetector.ts` | yes |
| `classifyByPremium()` | same file | yes |
| `classifySweep()` | same file | yes — called by `ingestion/index.ts` |
| `FlowEngine` | `quantflow-modules/flow-engine/src/engine.ts` | **no** — library only, never imported by the backend |

The three backend functions carried **different thresholds**:

```
classifyPrint()      exchanges >= 2 -> SWEEP ; size >= 500     -> BLOCK
classifyByPremium()  exchanges >= 2 -> SWEEP ; premium >= 500k -> BLOCK
classifySweep()      exchanges >= 2 -> SWEEP ; size >= 500     -> BLOCK
```

Concrete divergence, now pinned as a regression test: **a 300-lot print worth $600,000**.
`classifyByPremium` returned `BLOCK` (premium ≥ 500k). `classifySweep` returned `SPLIT` (size < 500). Same event, same session, two labels — determined by which function a given call site happened to use.

## Feature comparison

| Dimension | backend `sweepDetector` | `quantflow-modules/flow-engine` |
|---|---|---|
| classification | SWEEP / BLOCK / SPLIT | SWEEP / BLOCK / SPLIT / MULTI_LEG / LARGE |
| NBBO inference | none — no quote context at all | `NbboBook`, quote-relative side bucketing |
| ambiguous side | not represented | **`AMBIGUOUS`** when NBBO is missing or stale — never guessed |
| burst grouping | fixed 2s window, wall-clock keyed | watermark-driven, event-time keyed |
| multi-leg | none | ≥2 contracts inside `multiLegWindowMs`, with a spread guess |
| scoring | none (a separate `heatScore.ts`) | integrated, with a `scoreBreakdown` per component |
| synthetic flag | absent | **propagated onto every signal** |
| audit trail | none | **`printIds` on every signal** |
| outcome compatibility | none | `OutcomeTracker` already built against its types |
| tests | none | 14 passing |

## Decision

**`quantflow-modules/flow-engine` is CANONICAL.** It is provider-agnostic, event-time based, honest about ambiguity, and is the only one carrying an audit trail and a synthetic flag. The mandate's default preference and the evidence agree.

## What was done, and what deliberately was not

**Done now (safe, reversible):**
- `backend/src/ingestion/sweepDetector.ts` was rewritten as a **deprecation shim**. All three legacy exports now route through a single `classifyWithConfidence()` against one exported `CANONICAL_THRESHOLDS` object. Divergence between them is now structurally impossible.
- Classification gained an **explainability contract** (Phase 41): `observedEvidence`, `inferredEvidence`, `contradictions`, `algorithmVersion`.
- SWEEP is reported as **inferred, not confirmed** (Phase 39). Without an ISO flag on the feed, venue multiplicity is evidence of a sweep, not proof of one. Confidence is capped at 0.7 and the contradiction `"no ISO flag available on this feed — intent unconfirmed"` is attached to every SWEEP.
- Six regression tests pin all of this, including the historically divergent $600k case.

**Deliberately NOT done this session:**
Replacing the legacy ingester's call sites with the `FlowEngine` itself. That requires an NBBO quote stream the legacy ingester does not currently plumb, and doing it half-way would produce signals whose side is `AMBIGUOUS` for a mechanical reason (no quotes wired) rather than a market reason (genuinely unclear tape). That would poison the outcome dataset at exactly the moment persistence is being switched on.

The correct sequence is: wire quotes → run `FlowEngine` in shadow beside the shim → compare labels on real traffic → cut over. The shim makes it safe to do that later; it does not pretend it has been done.

## Verification

```
GATE D: the historically divergent case now agrees — 300 lots worth $600k   PASS
GATE D: multi-venue is sweep-like under every entry point                    PASS
GATE D: there is exactly ONE threshold set, and it is exported for audit     PASS
Phase 39: SWEEP is reported as inferred, never as confirmed intent           PASS
Phase 41: every classification carries an explainability contract            PASS
confidence is monotonic in venue count                                       PASS
```
