# Production Readiness (Phase 140)

**Date:** 2026-08-20. Scores are honest, not promotional. Everything below 8 is explained.

| Dimension | Score | Basis |
|---|---:|---|
| Data Integrity | 8/10 | `DataResult<T>` makes absent ≠ zero a type error; 75 tests enforce it. **−2:** ~104 legacy `?? 0` / `\|\| 0` sites remain in older connectors, not yet migrated. |
| Event-Time Integrity | 7/10 | `signals` stores `event_at`, `received_at`, `persisted_at` separately; publication-lag models exist per dataset. **−3:** the legacy ingester still stamps its own events with wall-clock time and is not yet on the canonical engine. |
| Provenance | 8/10 | Universal `Provenance` kernel; every market-structure route carries a provenance block. **−2:** legacy routes (`/api/flow`, `/api/gex`, `/api/darkpool`) do not yet. |
| Flow Classification | 6/10 | One threshold set, explainability contract, SWEEP downgraded to inferred. **−4:** the canonical `FlowEngine` is still not what production runs; the shim is a containment measure, not the cutover. |
| GEX Quality | 4/10 | Synthetic GEX is now blocked in production and OI has a cross-source reconciler. **−6:** no GEX v5 engine, no gamma scenario surface, no positioning-assumption sensitivity, and production GEX currently returns nothing real when synthetic is disabled. This is the largest gap. |
| Market Structure | 7/10 | DIX (approximation, percentile-first), 0DTE, put/call, OCC account-type, OI consensus — all live-verified. **−3:** no durable history yet, so percentiles rest on ~20 sessions rather than 252. |
| Outcome Tracking | 7/10 | Immutable `signals` + `signal_outcomes`, MFE/MAE columns, honest view that surfaces UNGRADED, append-only trigger proven. **−3:** zero real rows — persistence exists but has not yet run against live traffic. |
| Statistical Research | 3/10 | Point-in-time contract with publication-lag enforcement is built and tested. **−7:** no event-study engine, no research CLI, no preregistration, and — decisively — **no data to study**. Experiments EXP-T3-001..008 cannot be run; see below. |
| ML Validity | 8/10 | Synthetic-trained artifacts are structurally unservable: manifest-gated, hash-checked, provenance-checked. A planted 0.94-AUC model was refused. **−2:** no real dataset builder yet, so the honest state is "disabled", not "trained". |
| Security | 8/10 | Wildcard-credentialed CORS removed, production boots fail-closed on blank secrets, `requireAuth` denies when auth is unconfigured, secrets never printed. **−2:** `api_keys.key_value` is still plaintext-shaped in the schema; route classification (Phase 81) not applied. |
| Reliability | 5/10 | Connector probe detects schema drift and staleness across 8 sources. **−5:** jobs are still bare `setInterval` with no lock, no last-success tracking, no startup state machine; health is still "the port opened". |
| Backup/Recovery | 9/10 | **A real restore ran**: 250/120/30 rows recovered into a live PostgreSQL 16, SHA-256 recorded, immutability verified. Two genuine blockers found and fixed. **−1:** not yet executed against the actual Supabase project. |
| UX Information Density | 3/10 | **−7:** no frontend work this session. Truth badges, unavailable-vs-zero rendering, source tooltips, sector UI and the market-structure cockpit are all unbuilt. Backend contracts for them exist. |
| Zero-Cost Sustainability | 9/10 | Everything added is free-tier: FINRA, Cboe, OCC, Yahoo v8, GitHub raw, GitHub Actions, local Postgres for drills. **−1:** Vercel Hobby remains a licensing cliff the moment the product is commercial. |
| Repository Truth | 9/10 | Report and tree reconciled; the "older archive" identified as a different product; every claim here has a command behind it. **−1:** `/root/arch2` is not under version control, so there is no commit history to audit against. |
| **Production Readiness** | **5/10** | Honest aggregate. The **truth-telling substrate** is genuinely strong — the system now refuses to lie when data disappears. The **intelligence layer on top of it is mostly unbuilt**, and the research claims it would need cannot yet be tested for want of history. |

## The single most important sentence in this document

**QuantFlow currently has no historical signal data, therefore it has no validated edge, therefore no predictive claim of any kind is currently defensible.** The Tier-3 experiments (EXP-T3-001 through EXP-T3-008) were preregistered in scope but **not executed**, because executing them on zero rows would produce exactly the small-N pseudo-result this mandate forbids. The gating item is calendar time with persistence switched on, not engineering effort.

---

## Measured capacity (Phase 77) — real numbers, not estimates

Measured on PostgreSQL 16 with the actual migration and 50,000 signals / 150,000 outcomes, after `VACUUM ANALYZE`:

| Table | Rows | Total size | Bytes/row |
|---|---:|---:|---:|
| `signals` | 50,041 | 32 MB | **679** |
| `signal_outcomes` | 150,041 | 38 MB | **262** |

At 3 outcome horizons per signal, one signal costs ≈ 679 + 3×262 = **1,465 bytes** all-in.

Projection against the 500 MB Supabase free cap, at an assumed 2,000 signals/day:

| Window | Signals | Storage | % of cap |
|---|---:|---:|---:|
| 30 days | 60,000 | 84 MB | 16.8% |
| 90 days | 180,000 | 252 MB | 50.3% |
| **180 days** | 360,000 | **503 MB** | **100.6%** ⚠ |
| 365 days | 730,000 | 1,020 MB | 204.1% |

**The cap is reached at roughly 180 days.** Retention must exist before then. Note the 2,000 signals/day figure is an ASSUMPTION — the real rate is still unmeasured, and it is the single input that moves this projection most.
