# Tier-2 Reconciliation (Phase 0 — GATE A)

**Date:** 2026-08-20
**Method:** filesystem inspection, git inspection, and re-execution of the claimed verifications.

---

## Headline: the report and the working tree DO match — but the "older archive" is a different product

Two codebases were present in the environment:

| Path | git | package name | Layout |
|---|---|---|---|
| `/root/arch2` | **not a git repo** (extracted archive) | `quantflow-pro-backend` | `backend/ frontend/ ml-service/ quantflow-modules/` |
| `/root/qf/quantflow` | git repo, branch `master`, HEAD `76297bc` | `quantflow` | `apps/web/ services/ingest/ packages/shared/` |

These are **not two versions of one project**. Different package names, different directory layouts, different service decomposition, no shared history. `/root/arch2` is the QuantFlow Pro described by this mandate (it has the `backend/src/ingestion/connectors/*` and `quantflow-modules/flow-engine/` paths the mandate names). `/root/qf/quantflow` is a separate monorepo.

**Consequence, and it matters:** an earlier audit that ran against `/root/qf/quantflow` "refuted" two bug claims — an rng-trained ML model and a `sources['simulation'] = 'connected'` line. Both claims are **TRUE of this repository**. They were refuted against the wrong tree. See CRITICAL DEFECTS in the final report.

---

## Tier-2 capability reconciliation

| Tier-2 Capability | Report Says | Filesystem Says | Git Evidence | Test Evidence | Decision |
|---|---|---|---|---|---|
| `connectors/finraDix.ts` | shipped | **PRESENT** 18,857 B | n/a (not a git repo) | re-ran live: DIX 46.856%, 503/503 matched | **PRESENT + VERIFIED** |
| `connectors/cboeStats.ts` | shipped | **PRESENT** 10,006 B | n/a | re-ran live: 156,018 rows, 0DTE 48.92% | **PRESENT + VERIFIED** |
| `connectors/occ.ts` | shipped | **PRESENT** 14,495 B | n/a | re-ran live: SPY MM share 51.1%, 7,294 OI rows | **PRESENT + VERIFIED** |
| `routes/marketStructure.ts` | shipped | **PRESENT** 8,317 B, 7 routes | n/a | mounted at `/api/market-structure` (server.ts:45) | **PRESENT + VERIFIED** |
| `/dix`, `/dix/sectors`, `/zero-dte`, `/put-call`, `/occ/volume`, `/occ/open-interest` | shipped | **PRESENT** — plus an eighth, `/dix/history` | n/a | all previously returned 200 with provenance | **PRESENT + VERIFIED** |
| `.github/workflows/supabase-keepalive.yml` | shipped | **PRESENT** 3,241 B | n/a | YAML validated | **PRESENT + VERIFIED** |
| `.github/workflows/supabase-backup.yml` | shipped | **PRESENT** 5,203 B | n/a | **produced dumps that could NOT be restored** — see below | **PRESENT + DEFECTIVE** |
| `backend/tsconfig.scripts.json` | shipped | **PRESENT** 714 B | n/a | `tsc -p` exits 0 | **PRESENT + VERIFIED** |
| Live verification vs FINRA/Cboe/OCC/Yahoo | claimed | — | — | **independently reproduced this session** | **CONFIRMED** |

**Nothing was missing. One thing was wrong.**

### The one Tier-2 claim that did not survive

The backup workflow was reported as shipped, and it was — but it had never been restored from. Running an actual restore drill against a real PostgreSQL 16 instance found **two independent blockers**, either of which makes the backup worthless in a real recovery:

1. `pg_dump --schema=public` emits `CREATE SCHEMA public`, which collides with the schema every database already has → `ERROR: schema "public" already exists`.
2. The same dump **references** extension functions (`public.uuid_generate_v4()`) but does not carry the `CREATE EXTENSION` statements that define them, because extensions live outside the public schema → `ERROR: function public.uuid_generate_v4() does not exist`.

Both are invisible on Supabase, whose projects pre-provision `public` and the extensions. They surface only during a genuine restore elsewhere — i.e. exactly the disaster-recovery scenario the backup exists for.

Both are now fixed in the workflow, and `scripts/backup-verify.sh` performs a real restore into a throwaway database. See GATE K.

---

## Decision

No merge or port was required — Tier-2 is fully present in the working tree. Tier-3 proceeded on `/root/arch2`. `/root/qf/quantflow` was left untouched, as it is a different product.
