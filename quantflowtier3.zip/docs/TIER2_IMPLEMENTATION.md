# Tier-2 Implementation Report

**Date:** 2026-08-17
**Scope:** executed the top of the Tier-2 sourcing roadmap. Every number below came from running the code against live endpoints, not from a fixture.

---

## Result

Five roadmap items shipped, one confirmed already-built, one production bug found and fixed. Backend typechecks clean (including a previously-unchecked scripts directory), production build succeeds, flow-engine tests pass 14/14, and all seven new routes return 200 against live data.

---

## 1. Production bug found and fixed

`backend/src/ingestion/connectors/cboe.ts` fetches put/call ratios from:

```
https://cdn.cboe.com/data/us/options/market_statistics/options_volume.json
```

That URL returns **HTTP 403 AccessDenied** — the entire `cdn.cboe.com/data/us/**` S3 path is not public. Verified by direct request. Because the fetch is wrapped in a bare `catch { return {}; }`, the failure was silent and **every put/call field in production has been defaulting to `0`** while being rendered as a real value.

The obvious replacement is also dead: the legacy CSVs at `cdn.cboe.com/resources/options/volume_and_call_put_ratios/` return **HTTP 200 but stopped updating on 2019-10-04**. A 200 carrying seven-year-old data is more dangerous than a 403, because nothing alerts.

Fixed in a new module rather than patched in place, so the old connector's VIX path (which does work) is untouched.

---

## 2. What was built

| # | Item | File | Status |
|---|---|---|---|
| 1 | Alert win-rate / outcome tracking | `quantflow-modules/flow-engine/src/outcome/` | **Already built** — verified 14/14 tests |
| 2 | DIX dark-pool index | `backend/src/ingestion/connectors/finraDix.ts` | Shipped, live-verified |
| 3 | Supabase keep-alive + backup | `.github/workflows/supabase-{keepalive,backup}.yml` | Shipped |
| 4 | 0DTE + real put/call | `backend/src/ingestion/connectors/cboeStats.ts` | Shipped, live-verified |
| 5 | OCC account-type + cleared OI | `backend/src/ingestion/connectors/occ.ts` | Shipped, live-verified |
| 6 | Sector rotation input | `bySector` in `finraDix.ts` + GICS map | Shipped (data layer) |
| — | API surface | `backend/src/routes/marketStructure.ts` | 7 routes, all 200 |
| — | Scripts drift guard | `backend/tsconfig.scripts.json` | Shipped |

---

## 3. Live verification output

### DIX (`finraDix.ts`) — computed in 22s

```
tradeDate             : 2026-08-14
DIX (dollar-weighted) : 46.856%
DIX (unweighted)      : 51.651%
percentile rank       : 80.0 (n=20)
matched/missing/reject: 503 / 0 / 0
approximation         : true
```

Dollar-weighted DPI by GICS sector (this is the sector-rotation input, free):

```
Real Estate              52.17%   31 names    $1.8B
Materials                51.28%   25 names    $2.1B
Industrials              49.57%   83 names   $10.6B
Energy                   48.21%   21 names    $3.7B
Health Care              48.20%   59 names    $9.0B
Consumer Discretionary   47.93%   47 names   $17.4B
Financials               47.78%   76 names   $11.4B
Utilities                47.38%   31 names    $2.4B
Information Technology   46.69%   73 names   $91.2B
Consumer Staples         44.02%   34 names    $4.1B
Communication Services   39.93%   23 names    $9.9B
```

Sanity: 46.86% sits inside the band SqueezeMetrics' own *Short is Long* paper discusses (their disclosed empirical threshold is ≥45%). Dollar-weighted coming in *below* unweighted is the expected direction — mega-caps have proportionally more lit-market participation.

### Cboe stats (`cboeStats.ts`)

```
tradeDate           : 2026-08-14
rowsParsed/rejected : 156018 / 0
totalVolume         : 11,439,501
putCallRatio        : 0.8252      <- was hardcoded 0 in production
0DTE volume         : 5,596,433
0DTE share          : 48.92%
qualityFlags        : clean

SPXW  0dte=2,504,013  share=72.9%
SPY   0dte=  795,376  share=72.1%
QQQ   0dte=  533,373  share=71.3%
```

### OCC (`occ.ts`) — the retail-vs-dealer split no competitor ships

```
SPY   2026-08-14  total=19,753,926
      customer=9,367,365 (47.4%)  firm=287,937  marketMaker=10,098,624 (51.1%)
QQQ   2026-08-14  total=13,225,402
      customer=6,310,979 (47.7%)  firm=290,187  marketMaker= 6,624,236 (50.1%)
NVDA  2026-08-14  total= 6,730,888
      customer=3,302,301 (49.1%)  firm=160,219  marketMaker= 3,268,368 (48.6%)

SPY cleared OI: rows=7,294 rejected=0 (2,516 adjusted series excluded)
                callOI=6,465,540  putOI=15,951,661  P/C=2.467
                35 expirations, 2026-08-14 .. 2028-12-15
```

### Routes

```
HTTP 200  /dix                          provenance:present
HTTP 200  /dix/sectors                  provenance:present   rows=11
HTTP 200  /zero-dte                     provenance:present
HTTP 200  /put-call                     provenance:present
HTTP 200  /occ/volume?symbol=SPY        provenance:present
HTTP 200  /occ/open-interest?symbol=SPY provenance:present
HTTP 400  /occ/open-interest            (missing symbol — correct)
```

### Build

```
tsc --noEmit -p tsconfig.json          EXIT 0
tsc --noEmit -p tsconfig.scripts.json  EXIT 0   (scripts/ now covered)
tsc (production build)                 EXIT 0
flow-engine: 14 pass / 0 fail
```

---

## 4. Bugs live testing caught that review would not have

Three of these were wrong on first write and only surfaced by hitting real endpoints:

1. **FINRA returns 403, not 404, for a missing file.** The CDN is S3-backed, so absent keys are `AccessDenied`. Tolerating only 404 made every weekend, holiday, and pre-6PM-ET run look like a hard failure and broke the backwards walk to the last trading day.

2. **OCC `series-search` has a double tab after ProductSymbol.** The header row uses a single tab, so header and data columns do not align — year is at index `[2]`, not `[1]`. First version parsed 0 of 9,812 rows. Additionally the `Dec` field is a **fixed 3-character thousandths** field: inferring the divisor from digit count turns `"010"` into `0.10` instead of `0.010`. Confirmed fixed by fractional strikes (712.5, 717.5) now parsing correctly.

3. **Stooq's quote endpoint is dead** — `https://stooq.com/q/l/?s={sym}.us&f=...&e=csv` returns **404**, with and without the `.us` suffix. The DIX price lookup silently resolved 0/503 closes. Yahoo's v7 batch endpoint is also gone (**401 Unauthorized**, crumb-gated), but the v8 chart endpoint is open and resolved 20/20 in 1.7s at concurrency 10 — ~45s for all 503 names, fine for a 4×/day job.

Worth noting: when the price lookup failed, DIX did **not** emit a plausible-looking wrong number. It returned `0.000%` with `HIGH_REJECTED_503, LOW_COVERAGE_0`. The guardrails did their job.

---

## 5. Honesty controls built in

These are load-bearing and should survive future refactors:

- **`approximation: true`** is a literal type on `DixSnapshot`, not a comment. It cannot be dropped without a type error.
- **Every route ships a `provenance` block** stating source, cadence, method, and caveat. The DIX one says plainly that it is not the licensed SqueezeMetrics product and that the **percentile, not the level**, is the usable output.
- **FINRA data is never called "dark pool prints."** The provenance text states that off-exchange volume bundles true ATS prints with wholesaler internalization.
- **OCC market-maker share is never called dealer positioning.** The provenance text states it is observed cleared volume with no direction (opening vs closing, long vs short) disclosed.
- **Adjusted series (2SPY, 4SPY) are excluded from OI**, not silently summed — 2,516 rows dropped for SPY, logged. Summing them would corrupt any GEX cross-check.
- **Quality flags** (`HIGH_MISSING_*`, `LOW_COVERAGE_*`, `TRADE_DATE_INFERENCE_LOW_CONFIDENCE`) propagate to the API rather than being logged and discarded.

---

## 6. Required secrets for the workflows

| Secret | Used by | Notes |
|---|---|---|
| `SUPABASE_URL`, `SUPABASE_ANON_KEY` | keep-alive | Must query a real table — a static `/health` route does **not** count as database activity |
| `SUPABASE_DB_URL` | backup | **Session pooler URI, port 5432.** The transaction pooler (6543) does not support pg_dump's prepared statements |
| `HEALTHCHECKS_*_URL` | both | Optional; steps skip cleanly when absent |
| `R2_*` | backup | Optional off-site copy; R2 is 10 GB free with free egress |

Cost: keep-alive ~10 min/month, backup ~5 min/day against GitHub Free's 2,000 min/month. Comfortable.

---

## 7. Not done, and why

- **Congressional trade correlation** — blocked on the 5 U.S.C. § 13107 commercial-use question, not on engineering. Unresolved legal exposure.
- **SMT divergence as a scored signal** — no rigorous open-source implementation exists; shipping it as anything but a visual overlay would be unsubstantiated.
- **Sector rotation *UI*** — the data layer ships here (`/dix/sectors`, 11 GICS sectors live). The flow-premium-weighted version needs the options-flow side joined to the same GICS map; that is a frontend + aggregation task, not a sourcing one.
- **ML stack deployment** — the ARM64 verification is done and documented, but nothing was installed on the VM this session.

## 8. Next

1. Set the four GitHub secrets and let one backup run, then **test a restore** — an untested backup is not a backup.
2. Cross-check OCC cleared OI against your Tradier/Cboe OI in the GEX engine; disagreement is a data-quality signal worth surfacing.
3. Join options flow to the GICS map already fetched in `finraDix.ts` for the flow-native sector rotation heatmap.
4. Let DIX accumulate history — the percentile is currently over n=20; it wants 252.
