"""
ML MODEL GOVERNANCE — the honesty gate.

THE DEFECT THIS EXISTS TO PREVENT
---------------------------------
train.py generates its own labels:

    is_unusual = rng.random() < 0.25

then fits a GradientBoostingClassifier on features drawn from other rng calls,
reports an AUC, and writes models/flow_scorer.pkl. main.py loads that file and
serves its output as `scoring_mode="model"`.

That AUC measures nothing but the generator's internal consistency. The model
has never seen a real market event. Serving it as predictive intelligence is
the most serious honesty failure a trading product can commit, because the
number looks exactly like a real one.

THE RULE
--------
A model artifact may only be served in production if its manifest proves it was
trained on REAL, outcome-labelled QuantFlow events. Synthetic training remains
permitted for pipeline smoke tests — it just can never be promoted.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional

ModelStatus = Literal[
    "CANDIDATE", "SHADOW", "CHALLENGER", "PRODUCTION", "REJECTED", "RETIRED",
    "DISABLED_SYNTHETIC_ONLY", "DISABLED_INSUFFICIENT_DATA",
]

DataProvenance = Literal["REAL_OUTCOMES", "SYNTHETIC", "MIXED"]

# A model fitted on fewer real events than this cannot be promoted regardless of
# its metrics. Chosen so a single unusual week cannot mint a "validated" model.
MIN_REAL_TRAINING_SAMPLES = 500
MIN_REAL_HOLDOUT_SAMPLES = 100


@dataclass
class ModelManifest:
    """Immutable record describing exactly what a model artifact is."""
    model_id: str
    target: str
    feature_version: str
    algorithm: str

    data_provenance: DataProvenance
    n_train: int
    n_holdout: int
    train_range: Optional[str] = None
    validation_range: Optional[str] = None
    holdout_range: Optional[str] = None

    metrics: dict[str, Any] = field(default_factory=dict)
    baseline_metrics: dict[str, Any] = field(default_factory=dict)
    calibration: dict[str, Any] = field(default_factory=dict)

    status: ModelStatus = "CANDIDATE"
    artifact_sha256: Optional[str] = None
    git_sha: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    notes: list[str] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)


class ModelPromotionError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def assert_promotable(m: ModelManifest) -> None:
    """
    Raise unless this manifest may be served as production intelligence.
    Called by the serving layer BEFORE a model is loaded, not after.
    """
    if m.data_provenance != "REAL_OUTCOMES":
        raise ModelPromotionError(
            f"Model {m.model_id} has data_provenance={m.data_provenance}. "
            "Only models trained on REAL outcome-labelled events may serve production "
            "predictions. Synthetic-trained artifacts are for pipeline tests only."
        )
    if m.n_train < MIN_REAL_TRAINING_SAMPLES:
        raise ModelPromotionError(
            f"Model {m.model_id} trained on {m.n_train} real samples; "
            f"minimum is {MIN_REAL_TRAINING_SAMPLES}."
        )
    if m.n_holdout < MIN_REAL_HOLDOUT_SAMPLES:
        raise ModelPromotionError(
            f"Model {m.model_id} has {m.n_holdout} holdout samples; "
            f"minimum is {MIN_REAL_HOLDOUT_SAMPLES}."
        )
    if not m.baseline_metrics:
        raise ModelPromotionError(
            f"Model {m.model_id} has no baseline comparison. A model that has not "
            "beaten a trivial baseline has not demonstrated value."
        )


def is_promotable(m: ModelManifest) -> tuple[bool, str]:
    """Non-throwing variant for status reporting."""
    try:
        assert_promotable(m)
        return True, "promotable"
    except ModelPromotionError as e:
        return False, str(e)


def load_manifest(path: Path) -> Optional[ModelManifest]:
    if not path.exists():
        return None
    data = json.loads(path.read_text())
    return ModelManifest(**data)
