/**
 * CONNECTOR CANARY PROBE  (Phase 5)
 *
 * Detects provider schema drift and silent staleness BEFORE production corrupts
 * data with it. The Cboe put/call endpoint is the reason this exists: it went
 * 403 and nothing noticed for an unknown length of time, because the failure
 * was swallowed and rendered as 0.
 *
 * For each source: HTTP status, schema validity, latest effective date,
 * freshness verdict, latency, row count, quality flags.
 *
 * Run: npm run connectors:probe
 * Exit code is non-zero if any PRODUCTION-critical source is UNAVAILABLE.
 */
import axios from 'axios';
import {
  defaultContract, validatePayload, currentEtDate, previousTradingDay,
  type Quality,
} from '@quantflow/domain';

interface ProbeResult {
  source: string;
  dataset: string;
  url: string;
  httpStatus: number | string;
  schemaOk: boolean;
  latestEffective?: string;
  rowCount?: number;
  latencyMs: number;
  quality: Quality;
  critical: boolean;
  note?: string;
}

const results: ProbeResult[] = [];

async function probe(
  source: string, dataset: string, url: string, critical: boolean,
  check: (body: string, status: number) => {
    schemaOk: boolean; latestEffective?: string; rowCount?: number; note?: string;
  },
  cadence: Parameters<typeof defaultContract>[0] = 'DAILY',
  minRows = 1
): Promise<void> {
  const t0 = Date.now();
  try {
    const res = await axios.get<string>(url, {
      timeout: 60_000, responseType: 'text',
      maxContentLength: 128 * 1024 * 1024,
      validateStatus: () => true,
      headers: { 'User-Agent': 'QuantFlowPro/1.0 (connector probe)' },
    });
    const latencyMs = Date.now() - t0;

    if (res.status !== 200) {
      results.push({
        source, dataset, url, httpStatus: res.status, schemaOk: false, latencyMs, critical,
        quality: { state: 'UNAVAILABLE', flags: [], note: `HTTP ${res.status}` },
      });
      return;
    }

    const body = typeof res.data === 'string' ? res.data : JSON.stringify(res.data);
    const c = check(body, res.status);

    if (!c.schemaOk) {
      results.push({
        source, dataset, url, httpStatus: 200, schemaOk: false, latencyMs, critical,
        rowCount: c.rowCount,
        quality: { state: 'QUARANTINED', flags: ['SCHEMA_DRIFT'], note: c.note ?? 'schema check failed' },
        note: c.note,
      });
      return;
    }

    // THE POINT OF THIS TOOL: HTTP 200 does not mean the data is current.
    const v = validatePayload(c.latestEffective, c.rowCount ?? 0, defaultContract(cadence, minRows));
    results.push({
      source, dataset, url, httpStatus: 200, schemaOk: true,
      latestEffective: c.latestEffective, rowCount: c.rowCount,
      latencyMs, quality: v.quality, critical, note: c.note,
    });
  } catch (e) {
    results.push({
      source, dataset, url, httpStatus: 'ERR', schemaOk: false, latencyMs: Date.now() - t0, critical,
      quality: { state: 'UNAVAILABLE', flags: [], note: (e as Error).message.slice(0, 90) },
    });
  }
}

function yyyymmdd(iso: string): string { return iso.replace(/-/g, ''); }

(async () => {
  const today = currentEtDate();
  const lastSession = previousTradingDay(today);

  // ---- FINRA CNMS (DIX input) --------------------------------------------
  await probe('FINRA', 'CNMS daily short volume',
    `https://cdn.finra.org/equity/regsho/daily/CNMSshvol${yyyymmdd(lastSession)}.txt`, true,
    (b) => {
      const lines = b.split('\n');
      const schemaOk = lines[0]?.startsWith('Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume');
      const first = lines[1]?.split('|')[0];
      const eff = /^\d{8}$/.test(first ?? '')
        ? `${first!.slice(0,4)}-${first!.slice(4,6)}-${first!.slice(6,8)}` : undefined;
      return { schemaOk: !!schemaOk, latestEffective: eff, rowCount: lines.length - 2,
               note: schemaOk ? undefined : `header was: ${lines[0]?.slice(0,60)}` };
    }, 'DAILY', 1000);

  // ---- Cboe strike-level (0DTE + put/call) --------------------------------
  await probe('Cboe', 'symbol_data daily CSV (mkt=cone)',
    'https://www.cboe.com/us/options/market_statistics/symbol_data/csv/?mkt=cone', true,
    (b) => {
      const lines = b.split('\n');
      const schemaOk = lines[0]?.startsWith('Symbol,Call/Put,Expiration,Strike Price,Volume');
      let minExp: string | undefined;
      for (let i = 1; i < Math.min(lines.length, 5000); i++) {
        const e = lines[i].split(',')[2];
        if (/^\d{4}-\d{2}-\d{2}$/.test(e) && (!minExp || e < minExp)) minExp = e;
      }
      return { schemaOk: !!schemaOk, latestEffective: minExp, rowCount: lines.length - 2 };
    }, 'DAILY', 1000);

  // ---- Cboe LEGACY put/call: the canary that must report STALE ------------
  await probe('Cboe', 'LEGACY put/call CSV (known dead since 2019-10-04)',
    'https://cdn.cboe.com/resources/options/volume_and_call_put_ratios/equitypc.csv', false,
    (b) => {
      const lines = b.trim().split('\n');
      const last = lines[lines.length - 1]?.split(',')[0];
      const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(last ?? '');
      const eff = m ? `${m[3]}-${m[1]}-${m[2]}` : undefined;
      return { schemaOk: lines.length > 1, latestEffective: eff, rowCount: lines.length - 1,
               note: 'expected STALE — this is the regression canary for the 200-OK defense' };
    }, 'DAILY', 1);

  // ---- OCC cleared OI ------------------------------------------------------
  await probe('OCC', 'series-search cleared open interest',
    'https://marketdata.theocc.com/series-search?symbolType=U&symbol=SPY', true,
    (b) => {
      const schemaOk = b.includes('Series Search Results') && b.includes('ProductSymbol');
      const rows = b.split('\n').filter((l) => l.includes('\t') && /^SPY\s/.test(l)).length;
      // OCC publishes no as-of date on this endpoint.
      return { schemaOk, rowCount: rows, latestEffective: lastSession,
               note: 'no as-of date published by OCC; effective date assumed = last session' };
    }, 'DAILY', 100);

  // ---- Cboe delayed chain (Greeks source for GEX) --------------------------
  await probe('Cboe', 'delayed_quotes chain SPY (GEX Greeks source)',
    'https://cdn.cboe.com/api/global/delayed_quotes/options/SPY.json', true,
    (b) => {
      try {
        const j = JSON.parse(b);
        const opts = j?.data?.options;
        const schemaOk = Array.isArray(opts) && opts.length > 0 &&
          typeof opts[0].open_interest === 'number' && typeof opts[0].gamma === 'number';
        const ts: string | undefined = j?.timestamp;
        return { schemaOk, rowCount: opts?.length ?? 0,
                 latestEffective: ts ? ts.slice(0, 10) : undefined };
      } catch { return { schemaOk: false, note: 'invalid JSON' }; }
    }, 'DELAYED', 100);

  // ---- Yahoo v8 (DIX price weights) ---------------------------------------
  await probe('Yahoo', 'v8 chart (DIX dollar weights)',
    'https://query1.finance.yahoo.com/v8/finance/chart/SPY?interval=1d&range=1d', false,
    (b) => {
      try {
        const j = JSON.parse(b);
        const px = j?.chart?.result?.[0]?.meta?.regularMarketPrice;
        return { schemaOk: typeof px === 'number' && px > 0, rowCount: 1,
                 latestEffective: currentEtDate() };
      } catch { return { schemaOk: false, note: 'invalid JSON' }; }
    }, 'REALTIME', 1);

  // ---- Stooq: DEAD. Probed so the classification stays honest. -------------
  await probe('Stooq', 'quote endpoint (DEAD — 404 since 2026)',
    'https://stooq.com/q/l/?s=aapl.us&f=sd2t2ohlcv&h&e=csv', false,
    (b) => ({ schemaOk: b.startsWith('Symbol,Date'), rowCount: b.split('\n').length - 1,
              note: 'expected DEAD — retained as a probe so the connector registry cannot drift' }),
    'REALTIME', 1);

  // ---- S&P constituents (DIX universe + GICS sectors) ---------------------
  await probe('GitHub datasets', 'S&P 500 constituents + GICS sectors',
    'https://raw.githubusercontent.com/datasets/s-and-p-500-companies/main/data/constituents.csv', true,
    (b) => {
      const lines = b.trim().split('\n');
      return { schemaOk: lines[0]?.startsWith('Symbol,Security,GICS Sector'),
               rowCount: lines.length - 1, latestEffective: currentEtDate() };
    }, 'HISTORICAL', 400);

  // ---------------------------------------------------------------- report
  const pad = (s: string, n: number) => s.length > n ? s.slice(0, n - 1) + '…' : s.padEnd(n);
  console.log('\nCONNECTOR PROBE  ' + new Date().toISOString());
  console.log(`ET date ${today}  |  last session ${lastSession}\n`);
  console.log(
    pad('SOURCE', 10) + pad('DATASET', 44) + pad('HTTP', 6) + pad('SCHEMA', 8) +
    pad('EFFECTIVE', 12) + pad('ROWS', 9) + pad('ms', 7) + 'QUALITY'
  );
  console.log('-'.repeat(120));
  for (const r of results) {
    console.log(
      pad(r.source, 10) + pad(r.dataset, 44) + pad(String(r.httpStatus), 6) +
      pad(r.schemaOk ? 'ok' : 'FAIL', 8) + pad(r.latestEffective ?? '—', 12) +
      pad(r.rowCount === undefined ? '—' : r.rowCount.toLocaleString(), 9) +
      pad(String(r.latencyMs), 7) +
      r.quality.state + (r.quality.flags.length ? ` [${r.quality.flags.join(',')}]` : '')
    );
    if (r.quality.note) console.log(' '.repeat(10) + '↳ ' + r.quality.note.slice(0, 105));
  }

  const brokenCritical = results.filter(
    (r) => r.critical && (r.quality.state === 'UNAVAILABLE' || r.quality.state === 'QUARANTINED')
  );
  console.log('\nsummary: ' + results.map((r) => `${r.source}/${r.quality.state}`).join('  '));
  if (brokenCritical.length > 0) {
    console.error(`\nFAIL: ${brokenCritical.length} PRODUCTION-CRITICAL source(s) broken: ` +
      brokenCritical.map((r) => `${r.source}:${r.dataset}`).join(', '));
    process.exit(1);
  }
  console.log('\nAll production-critical sources reachable and schema-valid.');
})();
