/**
 * PARSER REGRESSION FIXTURES
 *
 * Every string here reproduces a defect that was found by hitting a live
 * endpoint, not by reading code. Comments alone did not stop these from
 * recurring; tests do.
 */

/** FINRA CNMS: real header + rows. Pipe-delimited, fractional volumes. */
export const FINRA_CNMS_VALID = `Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market
20260814|A|135784.061110|7|239279.073275|B,Q,N
20260814|AA|506041.443755|644|1066348.187037|B,Q,N
20260814|AAPL|18234567.5|120|39872341.25|B,Q,N
`;

/**
 * FINRA returns HTTP 403 (S3 AccessDenied), NOT 404, for a date with no file.
 * Treating only 404 as "absent" made every weekend and holiday look like a hard
 * failure and broke the walk back to the last trading session.
 */
export const FINRA_MISSING_STATUS = 403;

/**
 * OCC series-search. Note the DOUBLE TAB after ProductSymbol: the header row
 * uses a single tab, so header and data columns do NOT align. Year is at
 * index [2], not [1]. First parser scored 0 of 9,812 rows.
 * `Dec` is a FIXED 3-char thousandths field: "010" is 0.010, not 0.10.
 */
export const OCC_SERIES_SEARCH = [
  'Series Search Results for SPY',
  '',
  'Products for this underlying symbol are traded on: ',
  'AMEX ARCA BATS BOX C2 CBOE EDGX EMLD GEM ISE MCRY MEMX MIAX MPRL NOBO NSDQ PHLX SPHR ',
  '',
  '\t\tSeries/contract\t\tStrike\t\t\tOpen Interest\t\t\t',
  'ProductSymbol\tyear\tMonth\tDay\tInteger\tDec\tC/P\tCall\tPut\tPosition Limit\t',
  // adjusted / non-standard series — NOT fungible with the standard contract
  '2SPY  \t\t2026\t08\t14\t0\t010\tC   \t0\t0\t360000000',
  '4SPY  \t\t2026\t08\t14\t0\t010\tC   \t0\t0\t360000000',
  // standard series
  'SPY   \t\t2026\t08\t14\t500\t000\tC P \t0\t3320\t360000000',
  'SPY   \t\t2026\t08\t14\t505\t000\tC P \t120\t1035\t360000000',
  // fractional strike — proves the thousandths divisor
  'SPY   \t\t2026\t09\t18\t712\t500\tC P \t44\t91\t360000000',
].join('\r\n');

/** Cboe strike-level CSV — the WORKING replacement for the dead put/call CSVs. */
export const CBOE_SYMBOL_DATA_VALID =
  `Symbol,Call/Put,Expiration,Strike Price,Volume,Matched,Routed,Bid Size,Bid Price,Ask Size,Ask Price,Last Price
SPXW,P,2026-08-14,7780.0000,222361,222361,0,0,0.0,0,0.0,0.0300
SPXW,C,2026-08-14,7800.0000,180000,180000,0,0,0.0,0,0.0,0.0500
SPY,P,2026-08-21,600.0000,50000,50000,0,0,0.0,0,0.0,1.2000
SPY,C,2026-08-14,605.0000,75000,75000,0,0,0.0,0,0.0,0.4500
`;

/**
 * Cboe legacy put/call CSV. Returns HTTP 200 and parses cleanly — with data
 * frozen at 2019-10-04. A 200 carrying seven-year-old data is more dangerous
 * than a 403 because every naive health check calls it HEALTHY.
 */
export const CBOE_STALE_PUTCALL = `DATE,CALL,PUT,TOTAL,P/C Ratio
10/02/2019,1051234,682341,1733575,0.65
10/03/2019,1123456,712345,1835801,0.63
10/04/2019,998877,655443,1654320,0.66
`;
export const CBOE_STALE_LAST_DATE = '2019-10-04';

/** Provider returns 200 with an empty body — must not parse as "zero volume". */
export const EMPTY_RESPONSE = '';

/** Truncated mid-row: the last line is incomplete. */
export const TRUNCATED_CNMS = `Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market
20260814|A|135784.06|7|239279.07|B,Q,N
20260814|AA|506041.44|64`;

/** Schema drift: provider renamed a column. Must be detected, not silently mapped. */
export const CNMS_SCHEMA_DRIFT = `TradeDate|Ticker|ShortVol|ShortExemptVol|TotalVol|Venue
20260814|A|135784.06|7|239279.07|B,Q,N
`;

/** Yahoo v8 chart — the working price path after Stooq (404) and v7 (401) died. */
export const YAHOO_V8_CHART = JSON.stringify({
  chart: { result: [{ meta: { symbol: 'AAPL', regularMarketPrice: 305.93, previousClose: 304.10 } }], error: null },
});

/** Yahoo v7 batch quote — now permanently 401. */
export const YAHOO_V7_UNAUTHORIZED = JSON.stringify({
  finance: { result: null, error: { code: 'Unauthorized', description: 'User is unable to access this feature' } },
});
