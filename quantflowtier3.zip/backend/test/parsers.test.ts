/**
 * PHASE 6 — PARSER TORTURE TESTS
 * Each case is a defect discovered against a live endpoint, now permanently
 * pinned so it cannot silently return.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseSymbolDataCsv, inferTradeDate, computeStats } from '../src/ingestion/connectors/cboeStats';
import { parseCboeOptionSymbol } from '../src/ingestion/connectors/oiConsensus';
import * as F from './fixtures/parsers';

// ------------------------------------------------------------ Cboe

test('Cboe: valid strike-level CSV parses with zero rejects', () => {
  const { rows, rejected } = parseSymbolDataCsv(F.CBOE_SYMBOL_DATA_VALID);
  assert.equal(rejected, 0);
  assert.equal(rows.length, 4);
});

test('Cboe: 0DTE share is DERIVED from expirations, not taken on trust', () => {
  const { rows, rejected } = parseSymbolDataCsv(F.CBOE_SYMBOL_DATA_VALID);
  const s = computeStats(rows, rejected, 'cone');
  assert.equal(s.tradeDate, '2026-08-14');
  // 222361 + 180000 + 75000 expire on the trade date; 50000 does not.
  assert.equal(s.zeroDteVolume, 477361);
  assert.equal(s.totalVolume, 527361);
  assert.ok(Math.abs(s.zeroDteShare - 477361 / 527361) < 1e-9);
});

test('Cboe: put/call ratio is computed, never defaulted to 0 on failure', () => {
  const { rows, rejected } = parseSymbolDataCsv(F.CBOE_SYMBOL_DATA_VALID);
  const s = computeStats(rows, rejected, 'cone');
  assert.ok(s.putCallRatio > 0, 'a real ratio must be non-zero here');
  assert.equal(s.putVolume, 272361);
  assert.equal(s.callVolume, 255000);
});

test('Cboe: an empty body throws rather than parsing as zero volume', () => {
  assert.throws(() => parseSymbolDataCsv(F.EMPTY_RESPONSE), /unexpected Cboe CSV header/);
});

test('Cboe: schema drift is detected by the header guard', () => {
  assert.throws(() => parseSymbolDataCsv('Ticker,Right,Expiry\nSPY,C,2026-08-14\n'),
    /unexpected Cboe CSV header/);
});

test('Cboe: trade-date inference reports LOW CONFIDENCE rather than guessing silently', () => {
  const rows = [
    { symbol: 'SPY', isCall: true, expiration: '2026-08-14', volume: 1 },
    { symbol: 'SPY', isCall: true, expiration: '2026-09-18', volume: 100000 },
  ];
  const r = inferTradeDate(rows as never);
  assert.equal(r.tradeDate, '2026-08-14');
  assert.equal(r.confident, false, 'a 0.001% share must not be reported as confident');
});

// ------------------------------------------------------------ OCC symbology

test('OCC/Cboe option symbol: strike is thousandths — 00500000 is 500.000', () => {
  const k = parseCboeOptionSymbol('SPY260814C00500000');
  assert.deepEqual(k, { underlying: 'SPY', expiration: '2026-08-14', strike: 500, right: 'C' });
});

test('OCC/Cboe option symbol: fractional strike 712.500 survives the divisor', () => {
  const k = parseCboeOptionSymbol('SPY260918P00712500');
  assert.equal(k?.strike, 712.5);
  assert.equal(k?.right, 'P');
});

test('OCC/Cboe option symbol: malformed input returns null, never a partial guess', () => {
  assert.equal(parseCboeOptionSymbol('NOTASYMBOL'), null);
  assert.equal(parseCboeOptionSymbol(''), null);
});

// ------------------------------------------------------------ documented invariants

test('FINRA: absent files are 403 (S3 AccessDenied), not 404 — pinned as a constant', () => {
  assert.equal(F.FINRA_MISSING_STATUS, 403,
    'if this ever changes, fetchCnmsDay validateStatus must change with it');
});

test('OCC fixture preserves the double-tab that desynchronised the first parser', () => {
  const dataLine = F.OCC_SERIES_SEARCH.split('\r\n').find((l) => l.startsWith('SPY   '));
  assert.ok(dataLine, 'fixture must contain a standard SPY row');
  const cols = dataLine!.split('\t');
  assert.equal(cols[1], '', 'index [1] must be the empty field created by the double tab');
  assert.equal(cols[2], '2026', 'year lives at index [2], NOT [1]');
});

test('OCC fixture contains adjusted series that must be excluded from OI', () => {
  const adjusted = F.OCC_SERIES_SEARCH.split('\r\n').filter((l) => /^[24]SPY/.test(l));
  assert.equal(adjusted.length, 2, '2SPY/4SPY are different deliverables and must not be summed');
});

test('Cboe stale fixture is pinned at the real freeze date 2019-10-04', () => {
  // The CSV publishes US-style MM/DD/YYYY; the constant is ISO. Assert they
  // describe the same day rather than comparing the raw strings.
  const dates = F.CBOE_STALE_PUTCALL.trim().split('\n').slice(1).map((l) => l.split(',')[0]);
  const last = dates[dates.length - 1];
  assert.equal(last, '10/04/2019');
  const [mm, dd, yyyy] = last.split('/');
  assert.equal(`${yyyy}-${mm}-${dd}`, F.CBOE_STALE_LAST_DATE);
  // And the whole point: this file would pass any HTTP-200 health check.
  assert.ok(Date.now() - Date.parse(F.CBOE_STALE_LAST_DATE) > 5 * 365 * 86400000,
    'fixture must remain years stale to keep exercising the staleness defense');
});

test('Yahoo: v7 batch is a 401 envelope; v8 chart carries the price', () => {
  assert.equal(JSON.parse(F.YAHOO_V7_UNAUTHORIZED).finance.error.code, 'Unauthorized');
  assert.equal(JSON.parse(F.YAHOO_V8_CHART).chart.result[0].meta.regularMarketPrice, 305.93);
});

test('truncated payload does not yield a plausible partial row', () => {
  const lines = F.TRUNCATED_CNMS.trim().split('\n');
  const last = lines[lines.length - 1].split('|');
  assert.ok(last.length < 6, 'the final row is incomplete and must be rejected by a column-count guard');
});
