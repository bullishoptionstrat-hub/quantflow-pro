/**
 * GATE D ENFORCEMENT TEST
 * Proves the legacy classification functions can no longer disagree with each
 * other. Before consolidation classifyByPremium and classifySweep genuinely
 * returned different labels for the same event.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  classifySweep, classifyByPremium, classifyWithConfidence, CANONICAL_THRESHOLDS,
} from '../src/ingestion/sweepDetector';

test('GATE D: the historically divergent case now agrees — 300 lots worth $600k', () => {
  // Pre-consolidation: classifyByPremium -> BLOCK (premium >= 500k)
  //                    classifySweep     -> SPLIT (size 300 < 500)
  const premium = 600_000;
  const byPremium = classifyByPremium(premium, 1);
  const bySweep = classifySweep({ size: 300, exchanges: ['C'], premium });
  assert.equal(byPremium, bySweep, `divergence: byPremium=${byPremium} bySweep=${bySweep}`);
  assert.equal(byPremium, 'BLOCK');
});

test('GATE D: multi-venue is sweep-like under every entry point', () => {
  const ev = { exchangeCount: 3, totalSize: 120, totalPremium: 55_200, printCount: 3 };
  assert.equal(classifyWithConfidence(ev).orderType, 'SWEEP');
  assert.equal(classifySweep({ size: 120, exchanges: ['A', 'B', 'C'], premium: 55_200 }), 'SWEEP');
  assert.equal(classifyByPremium(55_200, 3), 'SWEEP');
});

test('GATE D: there is exactly ONE threshold set, and it is exported for audit', () => {
  assert.equal(CANONICAL_THRESHOLDS.minExchangesForSweepLike, 2);
  assert.equal(CANONICAL_THRESHOLDS.blockMinSize, 500);
  assert.equal(CANONICAL_THRESHOLDS.blockMinPremium, 500_000);
});

test('Phase 39: SWEEP is reported as inferred, never as confirmed intent', () => {
  const r = classifyWithConfidence({ exchangeCount: 2, totalSize: 100, totalPremium: 10_000, printCount: 2 });
  assert.equal(r.orderType, 'SWEEP');
  assert.ok(r.confidence < 0.8, 'venue multiplicity alone must not yield high confidence');
  assert.ok(r.contradictions.some((c) => /ISO flag/.test(c)),
    'must state that intermarket-sweep intent is unconfirmed');
  assert.ok(r.inferredEvidence.some((c) => /SWEEP_LIKE/.test(c)));
});

test('Phase 41: every classification carries an explainability contract', () => {
  const r = classifyWithConfidence({ exchangeCount: 4, totalSize: 900, totalPremium: 2_000_000, printCount: 6 });
  assert.ok(Array.isArray(r.observedEvidence) && r.observedEvidence.length > 0);
  assert.ok(Array.isArray(r.inferredEvidence));
  assert.ok(Array.isArray(r.contradictions));
  assert.ok(typeof r.algorithmVersion === 'string' && r.algorithmVersion.length > 0);
});

test('confidence is monotonic in venue count — more venues, stronger evidence', () => {
  const c2 = classifyWithConfidence({ exchangeCount: 2, totalSize: 100, totalPremium: 1, printCount: 1 }).confidence;
  const c3 = classifyWithConfidence({ exchangeCount: 3, totalSize: 100, totalPremium: 1, printCount: 1 }).confidence;
  const c4 = classifyWithConfidence({ exchangeCount: 5, totalSize: 100, totalPremium: 1, printCount: 1 }).confidence;
  assert.ok(c2 < c3 && c3 < c4, `expected monotonic, got ${c2} ${c3} ${c4}`);
});
