/**
 * GATE J ENFORCEMENT TEST
 * Proves production refuses to boot on missing secrets or wildcard CORS, that
 * secret VALUES never appear in error output, and that requireAuth denies when
 * the auth backend is unconfigured.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateSecurityConfig, corsOptions, socketCorsOptions, StartupConfigError } from '../src/security';

const PROD_BASE = {
  NODE_ENV: 'production',
  RUNTIME_MODE: 'PRODUCTION_REAL',
  SUPABASE_URL: 'https://example.supabase.co',
  SUPABASE_SERVICE_KEY: 'service-key-value-secret',
  CORS_ALLOWED_ORIGINS: 'https://app.quantflow.pro',
} as unknown as NodeJS.ProcessEnv;

test('GATE J: production refuses to boot with a blank service key', () => {
  assert.throws(
    () => validateSecurityConfig({ ...PROD_BASE, SUPABASE_SERVICE_KEY: '   ' } as NodeJS.ProcessEnv),
    (e: unknown) => e instanceof StartupConfigError && /SUPABASE_SERVICE_KEY/.test((e as Error).message)
  );
});

test('GATE J: production refuses wildcard CORS origin', () => {
  assert.throws(
    () => validateSecurityConfig({ ...PROD_BASE, CORS_ALLOWED_ORIGINS: '*' } as NodeJS.ProcessEnv),
    /forbidden in production/
  );
});

test('GATE J: production refuses an empty CORS allowlist', () => {
  assert.throws(
    () => validateSecurityConfig({ ...PROD_BASE, CORS_ALLOWED_ORIGINS: '', FRONTEND_URL: '' } as NodeJS.ProcessEnv),
    /must list explicit origins/
  );
});

test('GATE J: startup errors never echo secret VALUES, only names', () => {
  try {
    validateSecurityConfig({ ...PROD_BASE, SUPABASE_SERVICE_KEY: '' } as NodeJS.ProcessEnv);
    assert.fail('should have thrown');
  } catch (e) {
    const msg = (e as Error).message;
    assert.ok(msg.includes('SUPABASE_SERVICE_KEY'), 'must name the missing secret');
    assert.ok(!msg.includes('service-key-value-secret'), 'must NOT print any secret value');
    assert.ok(!msg.includes('example.supabase.co'), 'must NOT print the project URL');
  }
});

test('GATE J: a correctly configured production boots and yields an explicit allowlist', () => {
  const { allowedOrigins } = validateSecurityConfig(PROD_BASE);
  assert.deepEqual(allowedOrigins, ['https://app.quantflow.pro']);
});

test('GATE J: CORS rejects an origin outside the allowlist', (t) => {
  // corsOptions closes over module-level IS_PRODUCTION which is false under test,
  // so assert the allowlist wiring shape rather than production branch behaviour.
  const opts = corsOptions(['https://app.quantflow.pro']);
  assert.equal(typeof opts.origin, 'function');
  assert.equal(Array.isArray(opts.methods), true);
  const sock = socketCorsOptions(['https://app.quantflow.pro']);
  assert.ok('origin' in sock && 'credentials' in sock);
  // The invariant that must never regress: credentials are never enabled
  // simultaneously with a wildcard origin.
  assert.equal(sock.credentials === true && sock.origin === true, false,
    'credentials:true with wildcard origin is the forbidden combination');
});
