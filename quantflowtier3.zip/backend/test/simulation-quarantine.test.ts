/**
 * GATE B ENFORCEMENT TEST
 *
 * Proves that a missing TRADIER_TOKEN in PRODUCTION_REAL degrades the service
 * rather than silently substituting invented market data — the single most
 * dangerous defect that existed in this repository.
 *
 * Each case runs in its own child process because RUNTIME_MODE is resolved once
 * at module load.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import * as path from 'path';

const ROOT = path.resolve(__dirname, '..');

function runIngestion(env: Record<string, string>): { code: number; out: string } {
  const res = spawnSync(
    process.execPath,
    ['-r', require.resolve('ts-node/register'), '-e',
     `const m = require('./src/ingestion/index');
      console.log('MODE=' + m.RUNTIME_MODE);
      console.log('SYNTH=' + m.SYNTHETIC_ALLOWED);
      m.startIngestion(null);
      setTimeout(() => {
        console.log('FLOW_COUNT=' + m.getRecentFlow().length);
        console.log('DP_COUNT=' + m.getDarkPoolPrints().length);
        process.exit(0);
      }, 600);`],
    {
      cwd: ROOT, encoding: 'utf8', timeout: 60_000,
      env: { PATH: process.env.PATH, HOME: process.env.HOME,
             TS_NODE_COMPILER_OPTIONS: '{"module":"commonjs"}', ...env },
    }
  );
  return { code: res.status ?? -1, out: (res.stdout || '') + (res.stderr || '') };
}

test('GATE B: PRODUCTION_REAL with no Tradier token emits ZERO synthetic flow', () => {
  const { out } = runIngestion({ RUNTIME_MODE: 'PRODUCTION_REAL', TRADIER_TOKEN: '' });
  assert.match(out, /MODE=PRODUCTION_REAL/);
  assert.match(out, /SYNTH=false/);
  const flow = Number(/FLOW_COUNT=(\d+)/.exec(out)?.[1] ?? '-1');
  const dp = Number(/DP_COUNT=(\d+)/.exec(out)?.[1] ?? '-1');
  assert.equal(flow, 0, `expected 0 synthetic flow events in production, got ${flow}`);
  assert.equal(dp, 0, `expected 0 simulated dark-pool prints in production, got ${dp}`);
  assert.match(out, /Refusing to substitute simulated market data/);
});

test('GATE B: unset RUNTIME_MODE behaves as PRODUCTION_REAL (fail closed)', () => {
  const { out } = runIngestion({ TRADIER_TOKEN: '' });
  assert.match(out, /MODE=PRODUCTION_REAL/);
  assert.equal(Number(/FLOW_COUNT=(\d+)/.exec(out)?.[1] ?? '-1'), 0);
});

test('GATE B: DEMO mode DOES produce data, and every event is tagged synthetic:true', () => {
  const res = spawnSync(
    process.execPath,
    ['-r', require.resolve('ts-node/register'), '-e',
     `const m = require('./src/ingestion/index');
      m.startIngestion(null);
      setTimeout(() => {
        const f = m.getRecentFlow();
        const d = m.getDarkPoolPrints();
        console.log('FLOW_COUNT=' + f.length);
        console.log('FLOW_UNTAGGED=' + f.filter(e => e.synthetic !== true).length);
        console.log('DP_UNTAGGED=' + d.filter(e => e.synthetic !== true).length);
        process.exit(0);
      }, 600);`],
    { cwd: ROOT, encoding: 'utf8', timeout: 60_000,
      env: { PATH: process.env.PATH, HOME: process.env.HOME,
             TS_NODE_COMPILER_OPTIONS: '{"module":"commonjs"}',
             RUNTIME_MODE: 'DEMO', TRADIER_TOKEN: '' } }
  );
  const out = (res.stdout || '') + (res.stderr || '');
  const flow = Number(/FLOW_COUNT=(\d+)/.exec(out)?.[1] ?? '-1');
  assert.ok(flow > 0, `DEMO mode should generate events, got ${flow}`);
  assert.equal(Number(/FLOW_UNTAGGED=(\d+)/.exec(out)?.[1] ?? '-1'), 0,
    'every DEMO flow event must carry synthetic:true');
  assert.equal(Number(/DP_UNTAGGED=(\d+)/.exec(out)?.[1] ?? '-1'), 0,
    'every DEMO dark-pool print must carry synthetic:true');
});

test('GATE B / PHASE 8: production GEX degrades to empty, it does not throw or fabricate', () => {
  const res = require('child_process').spawnSync(
    process.execPath,
    ['-r', require.resolve('ts-node/register'), '-e',
     `const m = require('./src/ingestion/index');
      try {
        const lv = m.getGEXLevels('SPY');
        console.log('GEX_LEN=' + lv.length);
        console.log('THREW=false');
      } catch (e) { console.log('THREW=true'); console.log('ERR=' + e.message); }
      process.exit(0);`],
    { cwd: require('path').resolve(__dirname, '..'), encoding: 'utf8', timeout: 60000,
      env: { PATH: process.env.PATH, HOME: process.env.HOME,
             TS_NODE_COMPILER_OPTIONS: '{"module":"commonjs"}',
             RUNTIME_MODE: 'PRODUCTION_REAL', TRADIER_TOKEN: '' } }
  );
  const out = (res.stdout || '') + (res.stderr || '');
  assert.match(out, /THREW=false/, 'production GEX must degrade, not throw a 500');
  assert.equal(Number(/GEX_LEN=(\d+)/.exec(out)?.[1] ?? '-1'), 0,
    'production must return ZERO synthetic GEX levels — no fabricated curve');
});

test('GATE B / PHASE 8: DEMO mode still produces a GEX curve, for UI work', () => {
  const res = require('child_process').spawnSync(
    process.execPath,
    ['-r', require.resolve('ts-node/register'), '-e',
     `const m = require('./src/ingestion/index');
      console.log('GEX_LEN=' + m.getGEXLevels('SPY').length);
      process.exit(0);`],
    { cwd: require('path').resolve(__dirname, '..'), encoding: 'utf8', timeout: 60000,
      env: { PATH: process.env.PATH, HOME: process.env.HOME,
             TS_NODE_COMPILER_OPTIONS: '{"module":"commonjs"}',
             RUNTIME_MODE: 'DEMO', TRADIER_TOKEN: '' } }
  );
  const out = (res.stdout || '') + (res.stderr || '');
  assert.ok(Number(/GEX_LEN=(\d+)/.exec(out)?.[1] ?? '0') > 0, 'DEMO should still render a curve');
});
