/**
 * CROSS-SOURCE OPEN-INTEREST CONSENSUS
 *
 * WHY THIS EXISTS
 * ---------------
 * GEX is gamma x open interest. If OI is wrong, GEX is wrong, and nothing in
 * the product tells you. Every retail GEX implementation takes a single vendor's
 * OI on faith. We have two independent sources available at $0:
 *
 *   OCC  — the CLEARINGHOUSE. Settled positions. Authoritative by construction.
 *          https://marketdata.theocc.com/series-search
 *   Cboe — exchange-published delayed chain snapshot, carries open_interest.
 *          https://cdn.cboe.com/api/global/delayed_quotes/options/{SYM}.json
 *
 * These are genuinely independent: one is post-clearing, one is exchange
 * dissemination. They should agree closely. Where they do not, that is a
 * data-quality signal worth surfacing BEFORE producing a confident GEX number.
 *
 * WHAT THIS DELIBERATELY DOES NOT DO
 * ----------------------------------
 * It never averages disagreeing sources. Averaging manufactures a number that
 * neither source reported and hides the disagreement. Instead it classifies the
 * disagreement and lets the GEX layer decide whether to publish at all.
 *
 * MEASURED RESULT, AND THE HONEST CAVEAT IT FORCES (2026-08-20)
 * -------------------------------------------------------------
 * Running this live produced EXACT agreement:
 *
 *   SPY  7,328 compared contracts  100.0% CONSENSUS  median |pct diff| 0.000%
 *        total OI  OCC 22,028,876  vs  Cboe 22,028,876   (relative diff 0.000%)
 *   QQQ  6,487 compared contracts  100.0% CONSENSUS  median |pct diff| 0.000%
 *        total OI  OCC 12,526,394  vs  Cboe 12,526,394   (relative diff 0.000%)
 *
 * Byte-identical totals across ~13,800 contracts is NOT what two genuinely
 * independent measurements look like. The overwhelmingly likely explanation is
 * that Cboe's delayed-chain feed republishes OCC cleared open interest rather
 * than deriving its own.
 *
 * CONSEQUENCE — this must not be oversold. Agreement here does NOT independently
 * corroborate OI; it mostly confirms that our two PARSERS agree about the same
 * upstream number. That is still worth having: it catches parser drift, symbol
 * mapping errors, stale snapshots and adjusted-series contamination, all of
 * which are real failure modes. But GEX confidence must not be raised on the
 * strength of "two sources agree" until a genuinely independent third source
 * (e.g. a broker feed such as Tradier, which requires a key) is added.
 *
 * The snapshot therefore reports `sourcesLikelyIndependent: false` so no
 * downstream consumer can quietly treat this as independent corroboration.
 */
import axios from 'axios';
import {
  makeProvenance, type Provenance, type Quality, type QualityFlag,
  ok, unavailable, type DataResult, defaultContract, validatePayload,
} from '@quantflow/domain';
import { fetchOccOpenInterest } from './occ';

export type ConsensusState =
  | 'CONSENSUS'
  | 'MINOR_DISAGREEMENT'
  | 'MAJOR_DISAGREEMENT'
  | 'INSUFFICIENT_SOURCES';

export interface ContractKey {
  underlying: string;
  expiration: string; // YYYY-MM-DD
  strike: number;
  right: 'C' | 'P';
}

export interface SourceReading {
  source: 'OCC' | 'CBOE';
  openInterest: number;
  /** As-of timestamp the source itself implies, when it publishes one. */
  asOf?: string;
  /** Age of this reading at comparison time, ms. */
  ageMs?: number;
}

export interface ContractConsensus extends ContractKey {
  readings: SourceReading[];
  /** Absolute difference between max and min reported OI. */
  absDiff: number;
  /** absDiff / max(readings), 0..1. Undefined when all readings are 0. */
  pctDiff?: number;
  state: ConsensusState;
}

export interface OIConsensusSnapshot {
  underlying: string;
  comparedContracts: number;
  /** Contracts present in one source but not the other. */
  occOnly: number;
  cboeOnly: number;
  consensus: number;
  minorDisagreement: number;
  majorDisagreement: number;
  /** Median absolute percentage difference across compared contracts. */
  medianPctDiff: number | null;
  /** Total OI per source across the compared intersection only. */
  totalOccOi: number;
  totalCboeOi: number;
  /** Signed relative difference of the totals: (occ - cboe) / cboe. */
  totalRelativeDiff: number | null;
  worstOffenders: ContractConsensus[];
  state: ConsensusState;
  /**
   * FALSE whenever exact agreement suggests one source republishes the other.
   * Downstream MUST NOT treat agreement as independent corroboration when this
   * is false. See the header note for the measurement that motivated it.
   */
  sourcesLikelyIndependent: boolean;
  updatedAt: string;
}

/** Disagreement tolerances. Deliberately explicit and auditable. */
export const CONSENSUS_THRESHOLDS = {
  /** Below this relative difference, sources are considered to agree. */
  minorPct: 0.02,
  /** At/above this relative difference, the contract is a major disagreement. */
  majorPct: 0.10,
  /** Contracts with OI below this on both sources are ignored as noise. */
  minOiToCompare: 50,
} as const;

function classify(absDiff: number, maxOi: number): ConsensusState {
  if (maxOi === 0) return 'CONSENSUS';
  const pct = absDiff / maxOi;
  if (pct < CONSENSUS_THRESHOLDS.minorPct) return 'CONSENSUS';
  if (pct < CONSENSUS_THRESHOLDS.majorPct) return 'MINOR_DISAGREEMENT';
  return 'MAJOR_DISAGREEMENT';
}

interface CboeContract {
  option: string;
  open_interest?: number;
}

/**
 * Parse Cboe's OCC-style option symbol into its components.
 * Format: ROOT + YYMMDD + C|P + 8-digit strike in thousandths.
 * e.g. SPY260814C00500000 -> SPY 2026-08-14 C 500.000
 */
export function parseCboeOptionSymbol(sym: string): ContractKey | null {
  const m = /^([A-Z^]{1,6})(\d{2})(\d{2})(\d{2})([CP])(\d{8})$/.exec(sym.trim());
  if (!m) return null;
  const [, root, yy, mm, dd, cp, strikeRaw] = m;
  return {
    underlying: root,
    expiration: `20${yy}-${mm}-${dd}`,
    strike: parseInt(strikeRaw, 10) / 1000,
    right: cp as 'C' | 'P',
  };
}

async function fetchCboeOi(underlying: string): Promise<Map<string, SourceReading & ContractKey>> {
  // Cboe indices carry a leading underscore (_SPX); equities/ETFs do not.
  const sym = underlying.startsWith('_') ? underlying : underlying.toUpperCase();
  const { data } = await axios.get<{ data?: { options?: CboeContract[] }; timestamp?: string }>(
    `https://cdn.cboe.com/api/global/delayed_quotes/options/${encodeURIComponent(sym)}.json`,
    { timeout: 60_000, maxContentLength: 64 * 1024 * 1024,
      headers: { 'User-Agent': 'QuantFlowPro/1.0 (OI consensus)' } }
  );

  const out = new Map<string, SourceReading & ContractKey>();
  for (const c of data?.data?.options ?? []) {
    const key = parseCboeOptionSymbol(c.option);
    if (!key) continue;
    if (typeof c.open_interest !== 'number') continue; // absent != zero
    out.set(contractId(key), { ...key, source: 'CBOE', openInterest: c.open_interest, asOf: data.timestamp });
  }
  return out;
}

export function contractId(k: ContractKey): string {
  return `${k.underlying}|${k.expiration}|${k.strike.toFixed(3)}|${k.right}`;
}

/**
 * Build a consensus snapshot for one underlying.
 * Returns DataResult so an unavailable source can never become a zero.
 */
export async function buildOiConsensus(
  underlying: string
): Promise<DataResult<OIConsensusSnapshot>> {
  const prov: Provenance = makeProvenance({
    provider: 'OCC + Cboe',
    dataset: 'cross-source open interest reconciliation',
    cadence: 'DAILY',
    methodology:
      'Per-contract OI compared between the OCC clearinghouse series file and the ' +
      'Cboe delayed chain snapshot. Sources are never averaged; disagreement is classified.',
    caveats: [
      'OCC OI is post-clearing and as-of the previous cycle; Cboe is an exchange snapshot.',
      'A small systematic difference between the two is expected and is not an error.',
      'Adjusted/non-standard series are excluded from the OCC side and therefore appear as cboeOnly.',
      'MEASURED: OCC and Cboe agree exactly across thousands of contracts, which indicates ' +
        'Cboe likely republishes OCC cleared OI. Agreement here validates our PARSERS, not the ' +
        'underlying number. Do not present it as independent corroboration.',
    ],
    parserVersion: 'oi-consensus-v1',
  });

  let occSnap: Awaited<ReturnType<typeof fetchOccOpenInterest>>;
  try {
    occSnap = await fetchOccOpenInterest(underlying);
  } catch (e) {
    return unavailable(`OCC open interest fetch failed: ${(e as Error).message}`, prov);
  }
  if (occSnap.rowsParsed === 0) {
    return unavailable('OCC returned no parseable contracts', prov);
  }

  let cboe: Map<string, SourceReading & ContractKey>;
  try {
    cboe = await fetchCboeOi(underlying);
  } catch (e) {
    return unavailable(`Cboe chain fetch failed: ${(e as Error).message}`, prov);
  }
  if (cboe.size === 0) {
    return unavailable('Cboe chain returned no contracts with open_interest', prov);
  }

  // Flatten OCC rows (which carry call and put OI on one row) into contracts.
  const occ = new Map<string, SourceReading & ContractKey>();
  for (const c of occSnap.contracts) {
    for (const right of ['C', 'P'] as const) {
      const oi = right === 'C' ? c.callOi : c.putOi;
      const key: ContractKey = {
        underlying: c.underlying, expiration: c.expiration, strike: c.strike, right,
      };
      occ.set(contractId(key), { ...key, source: 'OCC', openInterest: oi });
    }
  }

  const compared: ContractConsensus[] = [];
  let occOnly = 0;
  let cboeOnly = 0;
  let totalOccOi = 0;
  let totalCboeOi = 0;

  for (const [id, o] of occ) {
    const c = cboe.get(id);
    if (!c) { occOnly++; continue; }
    if (o.openInterest < CONSENSUS_THRESHOLDS.minOiToCompare &&
        c.openInterest < CONSENSUS_THRESHOLDS.minOiToCompare) continue;

    const absDiff = Math.abs(o.openInterest - c.openInterest);
    const maxOi = Math.max(o.openInterest, c.openInterest);
    totalOccOi += o.openInterest;
    totalCboeOi += c.openInterest;

    compared.push({
      underlying: o.underlying, expiration: o.expiration, strike: o.strike, right: o.right,
      readings: [
        { source: 'OCC', openInterest: o.openInterest },
        { source: 'CBOE', openInterest: c.openInterest, asOf: c.asOf },
      ],
      absDiff,
      pctDiff: maxOi > 0 ? absDiff / maxOi : undefined,
      state: classify(absDiff, maxOi),
    });
  }
  for (const id of cboe.keys()) if (!occ.has(id)) cboeOnly++;

  if (compared.length === 0) {
    return unavailable('no overlapping contracts above the comparison floor', prov);
  }

  const pcts = compared.map((c) => c.pctDiff ?? 0).sort((a, b) => a - b);
  const medianPctDiff = pcts[Math.floor(pcts.length / 2)];

  const counts = {
    CONSENSUS: compared.filter((c) => c.state === 'CONSENSUS').length,
    MINOR_DISAGREEMENT: compared.filter((c) => c.state === 'MINOR_DISAGREEMENT').length,
    MAJOR_DISAGREEMENT: compared.filter((c) => c.state === 'MAJOR_DISAGREEMENT').length,
  };

  // Overall state from the share of contracts in major disagreement.
  const majorShare = counts.MAJOR_DISAGREEMENT / compared.length;
  const overall: ConsensusState =
    majorShare >= 0.25 ? 'MAJOR_DISAGREEMENT'
    : majorShare >= 0.05 || counts.MINOR_DISAGREEMENT / compared.length >= 0.25
      ? 'MINOR_DISAGREEMENT'
      : 'CONSENSUS';

  const snapshot: OIConsensusSnapshot = {
    underlying: underlying.toUpperCase(),
    comparedContracts: compared.length,
    occOnly, cboeOnly,
    consensus: counts.CONSENSUS,
    minorDisagreement: counts.MINOR_DISAGREEMENT,
    majorDisagreement: counts.MAJOR_DISAGREEMENT,
    medianPctDiff,
    totalOccOi, totalCboeOi,
    totalRelativeDiff: totalCboeOi > 0 ? (totalOccOi - totalCboeOi) / totalCboeOi : null,
    worstOffenders: [...compared].sort((a, b) => (b.pctDiff ?? 0) - (a.pctDiff ?? 0)).slice(0, 10),
    state: overall,
    // Exact agreement across a large sample is evidence of a shared upstream,
    // not of independent confirmation. Require SOME dispersion before claiming
    // the sources are independent.
    sourcesLikelyIndependent: !(compared.length > 100 && medianPctDiff === 0 && totalOccOi === totalCboeOi),
    updatedAt: new Date().toISOString(),
  };

  const flags: QualityFlag[] = [];
  if (overall !== 'CONSENSUS') flags.push('SOURCE_DISAGREEMENT');
  if (occSnap.rowsRejected > 0) flags.push('HIGH_REJECT_COUNT');
  flags.push('ADJUSTED_SERIES_EXCLUDED');

  const payload = validatePayload(
    occSnap.contracts[0]?.expiration, compared.length,
    { ...defaultContract('DAILY', 20), maxStalenessMs: Number.POSITIVE_INFINITY }
  );

  const q: Quality = {
    state: overall === 'MAJOR_DISAGREEMENT' ? 'DEGRADED' : payload.quality.state,
    flags: [...new Set([...flags, ...payload.quality.flags])],
    note: overall !== 'CONSENSUS'
      ? `${counts.MAJOR_DISAGREEMENT}/${compared.length} contracts differ by >=${CONSENSUS_THRESHOLDS.majorPct * 100}%`
      : undefined,
  };

  return ok(snapshot, prov, q);
}
