/**
 * SUPABASE OUTCOME STORE — connects the flow-engine's OutcomeTracker to durable
 * storage. Implements the OutcomeStore interface the tracker already defines.
 *
 * Until this existed the tracker ran against an in-memory Map: every graded
 * outcome was discarded on restart, so the one differentiator no competitor
 * ships (published, auditable hit rates) had no history behind it. History
 * cannot be back-filled — it only accrues forward from the moment persistence
 * is switched on, which is why this is worth wiring before anything cosmetic.
 *
 * Writes are append-only by construction: `signals` carries a DB trigger that
 * rejects UPDATE and DELETE, so a signal cannot be rewritten once its outcome
 * is known. See supabase/migrations/20260820_signals_outcomes.sql.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';

export interface PersistedSignal {
  id: string;
  event_at: string;
  received_at?: string;
  underlying: string;
  kind: string;
  side: string;
  total_premium: number;
  total_size: number;
  iso?: boolean;
  legs: unknown;
  print_ids: unknown;
  score?: number;
  score_breakdown?: unknown;
  classification_confidence?: number;
  algorithm_version: string;
  feature_version?: string;
  source: string;
  source_environment?: string;
  synthetic: boolean;
  quality_state?: string;
  quality_flags?: string[];
  provenance?: unknown;
}

export interface PersistedOutcome {
  signal_id: string;
  horizon: string;
  due_at: string;
  evaluated_at?: string;
  entry_underlying?: number | null;
  entry_contract?: number | null;
  mark_underlying?: number | null;
  mark_contract?: number | null;
  underlying_move_pct?: number | null;
  contract_return_pct?: number | null;
  mfe_pct?: number | null;
  mae_pct?: number | null;
  expected_move_pct?: number | null;
  move_vs_expected?: number | null;
  label?: string | null;
  missing_data_flags?: string[];
  algorithm_version: string;
}

export class SupabaseOutcomeStore {
  private readonly db: SupabaseClient;

  constructor(url?: string, serviceKey?: string) {
    const u = url ?? process.env.SUPABASE_URL ?? '';
    const k = serviceKey ?? process.env.SUPABASE_SERVICE_KEY ?? '';
    if (!u || !k) {
      // Fail loudly at construction rather than silently no-op'ing writes.
      // A store that quietly drops every signal is worse than no store.
      throw new Error(
        'SupabaseOutcomeStore requires SUPABASE_URL and SUPABASE_SERVICE_KEY. ' +
          'Refusing to construct a store that would silently discard signals.'
      );
    }
    this.db = createClient(u, k, { auth: { persistSession: false } });
  }

  /**
   * Insert a signal. Uses insert (not upsert) because the table is append-only;
   * a duplicate id is a genuine bug and should surface, not be papered over.
   * A 23505 unique violation is tolerated as an idempotent replay.
   */
  async insertSignal(s: PersistedSignal): Promise<void> {
    const { error } = await this.db.from('signals').insert(s);
    if (error && error.code !== '23505') {
      throw new Error(`signal insert failed (${error.code}): ${error.message}`);
    }
  }

  /** Register the pending checkpoints for a signal, unevaluated. */
  async registerOutcomes(rows: PersistedOutcome[]): Promise<void> {
    if (rows.length === 0) return;
    const { error } = await this.db
      .from('signal_outcomes')
      .upsert(rows, { onConflict: 'signal_id,horizon' });
    if (error) throw new Error(`outcome register failed: ${error.message}`);
  }

  /**
   * Grade a due checkpoint. NULL marks are written as NULL — never coerced to
   * zero and never interpolated. `missing_data_flags` records why.
   */
  async gradeOutcome(row: PersistedOutcome): Promise<void> {
    const { error } = await this.db
      .from('signal_outcomes')
      .upsert(row, { onConflict: 'signal_id,horizon' });
    if (error) throw new Error(`outcome grade failed: ${error.message}`);
  }

  /** Checkpoints whose due time has passed and which are still ungraded. */
  async listDue(now: Date = new Date()): Promise<PersistedOutcome[]> {
    const { data, error } = await this.db
      .from('signal_outcomes')
      .select('*')
      .is('evaluated_at', null)
      .lte('due_at', now.toISOString())
      .limit(1000);
    if (error) throw new Error(`listDue failed: ${error.message}`);
    return (data ?? []) as PersistedOutcome[];
  }

  /**
   * Honest performance aggregate. Reads the view that excludes synthetic
   * signals and reports n_ungraded alongside the hit rate.
   */
  async performance(): Promise<Array<Record<string, unknown>>> {
    const { data, error } = await this.db.from('v_signal_performance').select('*');
    if (error) throw new Error(`performance query failed: ${error.message}`);
    return data ?? [];
  }
}
