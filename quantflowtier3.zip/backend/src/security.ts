/**
 * PRODUCTION SECURITY CONFIGURATION — fail closed.
 *
 * DEFECTS THIS EXISTS TO FIX
 * --------------------------
 * 1. `cors({ origin: '*', credentials: true })` on both Express and Socket.IO.
 *    Wildcard origin combined with credentials is the classic misconfiguration:
 *    browsers reject the combination for fetch, but it also means every origin
 *    is trusted for the non-credentialed paths, and the Socket.IO server will
 *    hand the full live flow feed to any page on the internet.
 *
 * 2. `requireAuth` delegates to `optionalAuth`, which returns `next()` early
 *    when `supabase` is null — i.e. when SUPABASE_URL/SUPABASE_SERVICE_KEY are
 *    unset. A missing credential therefore made authentication PERMISSIVE.
 *    That is inverted: absent security configuration must deny, not allow.
 */
import { resolveRuntimeMode } from '@quantflow/domain';

export const RUNTIME_MODE = resolveRuntimeMode();
export const IS_PRODUCTION =
  process.env.NODE_ENV === 'production' || RUNTIME_MODE === 'PRODUCTION_REAL';

/** Secrets that must be present and non-blank before production may serve. */
const REQUIRED_IN_PRODUCTION = ['SUPABASE_URL', 'SUPABASE_SERVICE_KEY'] as const;

export class StartupConfigError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'StartupConfigError';
  }
}

/**
 * Validate configuration at boot. Throws — the process must not open a port
 * with a security configuration it cannot satisfy.
 * Secret NAMES are reported; values never are.
 */
export function validateSecurityConfig(env: NodeJS.ProcessEnv = process.env): {
  allowedOrigins: string[];
} {
  const origins = parseOrigins(env.CORS_ALLOWED_ORIGINS ?? env.FRONTEND_URL ?? '');

  if (IS_PRODUCTION) {
    const missing = REQUIRED_IN_PRODUCTION.filter((k) => (env[k] ?? '').trim() === '');
    if (missing.length > 0) {
      throw new StartupConfigError(
        `Missing or blank required secret(s) in production: ${missing.join(', ')}. ` +
          'Refusing to start — a blank service key would make authentication permissive.'
      );
    }
    if (origins.length === 0) {
      throw new StartupConfigError(
        'CORS_ALLOWED_ORIGINS (or FRONTEND_URL) must list explicit origins in production. ' +
          'Wildcard CORS with credentials is not permitted.'
      );
    }
    if (origins.includes('*')) {
      throw new StartupConfigError(
        'CORS origin "*" is forbidden in production. List explicit origins.'
      );
    }
  }

  return { allowedOrigins: origins };
}

function parseOrigins(raw: string): string[] {
  return raw.split(',').map((s) => s.trim()).filter(Boolean);
}

/**
 * CORS origin callback.
 * - Production: strict allowlist, credentials permitted only for listed origins.
 * - Non-production: permissive, but credentials are DISABLED so a dev config
 *   can never be promoted into a credentialed wildcard by accident.
 */
export function corsOptions(allowedOrigins: string[]) {
  return {
    origin(origin: string | undefined, cb: (err: Error | null, allow?: boolean) => void) {
      // Same-origin / curl / server-to-server requests send no Origin header.
      if (!origin) return cb(null, true);
      if (!IS_PRODUCTION) return cb(null, true);
      if (allowedOrigins.includes(origin)) return cb(null, true);
      return cb(new Error(`Origin ${origin} is not in the CORS allowlist`));
    },
    credentials: IS_PRODUCTION,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  };
}

/** Socket.IO CORS — same allowlist, never wildcard-with-credentials. */
export function socketCorsOptions(allowedOrigins: string[]) {
  return {
    origin: IS_PRODUCTION ? allowedOrigins : true,
    methods: ['GET', 'POST'],
    credentials: IS_PRODUCTION,
  };
}
