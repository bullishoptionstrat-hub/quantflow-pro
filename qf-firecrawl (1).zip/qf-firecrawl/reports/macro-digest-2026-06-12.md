# Macro / News Context Digest — 2026-06-12

> **Context layer only — never a trade trigger.** Macro regime informs
> risk posture; bias is earned exclusively through price confirmation
> (external sweep + reclaim, HTF break + retest + acceptance, or
> displacement + retest + rejection). Default state: Neutral — waiting.

## Fed / Rates

**FAILED**: INSUFFICIENT_CREDITS: Firecrawl account is out of credits for this cycle

> Run aborted: Firecrawl account out of credits.

---

## Regime read (manual)

Classify after reviewing sources: risk-on / inflationary / stagflationary / liquidity-supportive.
Regime never overrides price confirmation.

## Rerun inputs

```
command: npx tsx scripts/research/macro-digest.ts
queries: Fed / Rates | Inflation / CPI | S&P 500 Futures (ES) | Nasdaq Futures (NQ) | Gold (GC) | Silver (SI)
env: FIRECRAWL_API_KEY
```
