// =====================================================================
// execution-sim.ts — THE single deterministic execution simulator.
//
// Every research path (backtest, shadow/counterfactual, replay) MUST use this
// module. Ad-hoc fill logic elsewhere is how the E000 trigger-bar-fill defect
// happened; one engine makes that class of bug impossible to reintroduce
// quietly.
//
// CAUSAL ORDER — never reversed:
//   confirmation bar CLOSES  -> permission exists
//   order may then EXIST     -> ORDER_WORKING
//   price may later reach it -> FILLED (position begins here)
//   only then                -> stop / target / MAE / MFE / PnL
//
// FOUR DISTINCT PRICES. These are separate fields on purpose; a generic
// `entry` field is banned because conflating them is exactly the defect this
// module repairs:
//   decisionPrice    close of the confirmation bar (what we knew at decision)
//   limitPrice       the God's Plan order level (FVG edge) — the strategy's
//                    intended entry, NOT the decision price
//   fillPrice        conservative simulated execution price
//   stopPrice        structural invalidation
//
// CONSERVATIVE POLICIES (documented, never silently favourable):
//  • First eligible execution bar = decisionIndex + 1. The confirmation bar's
//    own high/low CANNOT fill an order that did not exist during that bar.
//  • fillPrice = limitPrice always. Gap-through price improvement is measured
//    and reported separately but never credited to the baseline.
//  • On the FILL bar only adverse events resolve. A target touch on the fill
//    bar is NOT granted, because OHLC cannot establish that it happened after
//    the fill. Targets are eligible from the bar after the fill.
//  • Same-bar stop+target after fill resolves to STOP.
//  • R is computed from the ACTUAL fill: |fillPrice - stopPrice|.
// =====================================================================

export type Direction = "LONG" | "SHORT";

export interface ExecBar {
  barTime: string;
  open: number; high: number; low: number; close: number;
}

export interface OrderIntent {
  orderId: string;
  setupId: string;
  symbol: string;
  direction: Direction;
  /** Index of the confirmation bar whose CLOSE granted permission. */
  decisionIndex: number;
  decisionTime: string;
  decisionPrice: number;
  /** The God's Plan intended entry level (FVG edge). NOT the decision price. */
  limitPrice: number;
  stopPrice: number;
  /** Target expressed as an R multiple of the risk measured at FILL. */
  targetR: number;
}

export interface ExecConfig {
  /** Bars an unfilled order may remain working (from the decision bar). */
  orderMaxBars: number;
  /** Bars a filled position may be held before mark-to-market timeout. */
  maxHoldBars: number;
  /** Round-trip cost in R. */
  costR: number;
  /** Cancel a working order if price reaches the structural stop pre-fill. */
  cancelOnStopBeforeFill: boolean;
}

export const DEFAULT_EXEC: ExecConfig = {
  orderMaxBars: 24, maxHoldBars: 24, costR: 0.05, cancelOnStopBeforeFill: true,
};

export type OrderStatus =
  | "FILLED" | "EXPIRED" | "INVALIDATED_BEFORE_FILL" | "CANCELLED" | "NO_DATA";

export type PositionOutcome = "STOPPED" | "TARGET" | "TIMEOUT" | "OPEN_AT_DATA_END";

export type CancelReason =
  | "ORDER_MAX_BARS" | "STOP_REACHED_BEFORE_FILL" | "DATA_END" | null;

export interface OrderRecord {
  orderId: string; setupId: string; symbol: string; direction: Direction;
  decisionIndex: number; decisionTime: string; decisionPrice: number;
  limitPrice: number; stopPrice: number;
  /** True when the limit was already through the market at submission. */
  marketableAtSubmission: boolean;
  firstEligibleExecutionIndex: number;
  firstEligibleExecutionTime: string | null;
  status: OrderStatus;
  cancelReason: CancelReason;
  fillIndex: number | null;
  fillTime: string | null;
  fillPrice: number | null;
  barsToFill: number | null;
  /** Favourable gap-through at the fill bar's open, in price. Reported only. */
  theoreticalPriceImprovement: number | null;
  /** |fillPrice - stopPrice| — the R unit, from the ACTUAL fill. */
  riskPrice: number | null;
  /** Distance decision->limit, in price (sign-free). */
  distanceDecisionToLimit: number;
  // ---- position, only when status === FILLED ----
  outcome: PositionOutcome | null;
  grossR: number | null;
  netR: number | null;
  maeR: number | null;
  mfeR: number | null;
  barsHeld: number | null;
  exitTime: string | null;
}

/** Was the limit already through the market when the order was submitted? */
export function isMarketableAtSubmission(o: OrderIntent): boolean {
  // BUY limit is marketable when the market is at/below the limit.
  return o.direction === "LONG"
    ? o.decisionPrice <= o.limitPrice
    : o.decisionPrice >= o.limitPrice;
}

/**
 * Run one order through its full lifecycle over `bars`.
 * `bars` is the whole series; indices are absolute.
 */
export function simulateOrder(
  o: OrderIntent, bars: readonly ExecBar[], cfg: ExecConfig = DEFAULT_EXEC,
): OrderRecord {
  const isLong = o.direction === "LONG";
  const firstIdx = o.decisionIndex + 1; // HARD INVARIANT: never the decision bar
  const rec: OrderRecord = {
    orderId: o.orderId, setupId: o.setupId, symbol: o.symbol, direction: o.direction,
    decisionIndex: o.decisionIndex, decisionTime: o.decisionTime, decisionPrice: o.decisionPrice,
    limitPrice: o.limitPrice, stopPrice: o.stopPrice,
    marketableAtSubmission: isMarketableAtSubmission(o),
    firstEligibleExecutionIndex: firstIdx,
    firstEligibleExecutionTime: firstIdx < bars.length ? bars[firstIdx]!.barTime : null,
    status: "NO_DATA", cancelReason: null,
    fillIndex: null, fillTime: null, fillPrice: null, barsToFill: null,
    theoreticalPriceImprovement: null, riskPrice: null,
    distanceDecisionToLimit: Math.abs(o.decisionPrice - o.limitPrice),
    outcome: null, grossR: null, netR: null, maeR: null, mfeR: null, barsHeld: null, exitTime: null,
  };
  if (firstIdx >= bars.length) { rec.cancelReason = "DATA_END"; return rec; }

  // ---------------- working-order phase ----------------
  const lastWorking = Math.min(bars.length - 1, o.decisionIndex + cfg.orderMaxBars);
  for (let i = firstIdx; i <= lastWorking; i++) {
    const b = bars[i]!;
    const touchesLimit = isLong ? b.low <= o.limitPrice : b.high >= o.limitPrice;
    const touchesStop = isLong ? b.low <= o.stopPrice : b.high >= o.stopPrice;

    // A bar that reaches the structural stop without ever offering the limit
    // means the idea broke before we could be in it.
    if (cfg.cancelOnStopBeforeFill && touchesStop && !touchesLimit) {
      rec.status = "INVALIDATED_BEFORE_FILL"; rec.cancelReason = "STOP_REACHED_BEFORE_FILL";
      return rec;
    }
    if (touchesLimit) {
      rec.status = "FILLED";
      rec.fillIndex = i; rec.fillTime = b.barTime;
      rec.fillPrice = o.limitPrice;                 // never grant improvement
      rec.barsToFill = i - o.decisionIndex;
      // Report (do not credit) any favourable gap at the open.
      const imp = isLong ? o.limitPrice - b.open : b.open - o.limitPrice;
      rec.theoreticalPriceImprovement = imp > 0 ? imp : 0;
      break;
    }
  }
  if (rec.status !== "FILLED") {
    if (rec.status === "NO_DATA") {
      rec.status = lastWorking >= bars.length - 1 ? "EXPIRED" : "EXPIRED";
      rec.cancelReason = lastWorking >= bars.length - 1 ? "DATA_END" : "ORDER_MAX_BARS";
    }
    return rec;
  }

  // ---------------- position phase ----------------
  const fillIdx = rec.fillIndex!;
  const fill = rec.fillPrice!;
  const risk = Math.abs(fill - o.stopPrice);
  rec.riskPrice = risk;
  if (!(risk > 0)) { // degenerate geometry: refuse to invent a trade
    rec.status = "CANCELLED"; rec.cancelReason = null;
    rec.outcome = null; return rec;
  }
  const target = isLong ? fill + o.targetR * risk : fill - o.targetR * risk;
  const favR = (p: number) => (isLong ? p - fill : fill - p) / risk;

  let mae = 0, mfe = 0;
  const lastHold = Math.min(bars.length - 1, fillIdx + cfg.maxHoldBars - 1);
  for (let i = fillIdx; i <= lastHold; i++) {
    const b = bars[i]!;
    // On the FILL bar we cannot show that the bar's favourable extreme
    // post-dates the fill, so favourable excursion is NOT credited there.
    // Adverse excursion IS counted on the fill bar (conservative both ways).
    if (i > fillIdx) mfe = Math.max(mfe, isLong ? favR(b.high) : favR(b.low));
    mae = Math.min(mae, isLong ? favR(b.low) : favR(b.high));

    const hitStop = isLong ? b.low <= o.stopPrice : b.high >= o.stopPrice;
    const hitTarget = isLong ? b.high >= target : b.low <= target;

    if (hitStop) return finish("STOPPED", -1, i, b.barTime);
    // On the FILL bar a target touch cannot be shown to post-date the fill.
    if (hitTarget && i > fillIdx) return finish("TARGET", o.targetR, i, b.barTime);
  }
  const last = bars[lastHold]!;
  return finish(bars.length - 1 > lastHold ? "TIMEOUT" : "OPEN_AT_DATA_END", favR(last.close), lastHold, last.barTime);

  function finish(outcome: PositionOutcome, grossR: number, idx: number, t: string): OrderRecord {
    rec.outcome = outcome; rec.grossR = grossR; rec.netR = grossR - cfg.costR;
    rec.maeR = mae; rec.mfeR = mfe; rec.barsHeld = idx - fillIdx + 1; rec.exitTime = t;
    return rec;
  }
}

// ------------------------------ funnel --------------------------------------

export interface ExecutionFunnel {
  ordersSubmitted: number;
  marketable: number;
  passive: number;
  filled: number;
  expired: number;
  invalidatedBeforeFill: number;
  cancelled: number;
  noData: number;
  stopped: number;
  targets: number;
  timeouts: number;
  openAtDataEnd: number;
  fillRate: number;
  medianBarsToFill: number | null;
  p90BarsToFill: number | null;
}

export function summarizeFunnel(records: readonly OrderRecord[]): ExecutionFunnel {
  const f: ExecutionFunnel = {
    ordersSubmitted: records.length, marketable: 0, passive: 0, filled: 0, expired: 0,
    invalidatedBeforeFill: 0, cancelled: 0, noData: 0, stopped: 0, targets: 0,
    timeouts: 0, openAtDataEnd: 0, fillRate: 0, medianBarsToFill: null, p90BarsToFill: null,
  };
  const btf: number[] = [];
  for (const r of records) {
    r.marketableAtSubmission ? f.marketable++ : f.passive++;
    switch (r.status) {
      case "FILLED": f.filled++; if (r.barsToFill !== null) btf.push(r.barsToFill); break;
      case "EXPIRED": f.expired++; break;
      case "INVALIDATED_BEFORE_FILL": f.invalidatedBeforeFill++; break;
      case "CANCELLED": f.cancelled++; break;
      case "NO_DATA": f.noData++; break;
    }
    switch (r.outcome) {
      case "STOPPED": f.stopped++; break;
      case "TARGET": f.targets++; break;
      case "TIMEOUT": f.timeouts++; break;
      case "OPEN_AT_DATA_END": f.openAtDataEnd++; break;
      default: break;
    }
  }
  f.fillRate = records.length ? f.filled / records.length : 0;
  if (btf.length) {
    const s = [...btf].sort((a, b) => a - b);
    f.medianBarsToFill = s[Math.floor(s.length / 2)]!;
    f.p90BarsToFill = s[Math.min(s.length - 1, Math.floor(0.9 * s.length))]!;
  }
  return f;
}
