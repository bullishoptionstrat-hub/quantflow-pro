// =====================================================================
// registry.ts — typed experiment registry with schema validation.
//
// The CSV was hand-appended across sessions and drifted: rows gained extra
// columns (status/reason/supersedes) that the header never declared, and one
// append lost a newline and merged two records. A registry that can silently
// go malformed is not research provenance. JSONL is now the source of truth;
// CSV is a generated export.
// =====================================================================

export const REGISTRY_FIELDS = [
  "experiment_id", "parent_experiment", "hypothesis", "conceptual_change", "split",
  "sample_size", "trades", "expectancy_r", "profit_factor", "max_dd_r",
  "status", "reason", "supersedes", "code_hash", "config_hash", "dataset_hash",
  "created_at", "conclusion",
] as const;
export type RegistryField = (typeof REGISTRY_FIELDS)[number];

export type ExperimentStatus =
  | "ACTIVE" | "REJECTED" | "INVALIDATED_METHODOLOGY" | "SUPERSEDED"
  | "LEGACY_CONTAMINATED_EXECUTION";

export interface ExperimentRecord {
  experiment_id: string;
  parent_experiment: string | null;
  hypothesis: string;
  conceptual_change: string;
  split: string;
  sample_size: number | null;
  trades: number | null;
  expectancy_r: number | null;
  profit_factor: number | null;
  max_dd_r: number | null;
  status: ExperimentStatus;
  reason: string | null;
  supersedes: string | null;
  code_hash: string | null;
  config_hash: string | null;
  dataset_hash: string | null;
  created_at: string;
  conclusion: string;
}

const STATUSES = new Set<string>([
  "ACTIVE", "REJECTED", "INVALIDATED_METHODOLOGY", "SUPERSEDED", "LEGACY_CONTAMINATED_EXECUTION",
]);

/** Throws on any schema violation. Fail closed — a bad row must never ship. */
export function validateRecord(r: unknown, where = "record"): ExperimentRecord {
  if (typeof r !== "object" || r === null) throw new Error(`${where}: not an object`);
  const o = r as Record<string, unknown>;
  const keys = Object.keys(o);
  for (const f of REGISTRY_FIELDS) if (!(f in o)) throw new Error(`${where}: missing field '${f}'`);
  for (const k of keys) if (!(REGISTRY_FIELDS as readonly string[]).includes(k)) throw new Error(`${where}: unknown field '${k}'`);
  const str = (f: RegistryField) => { const v = o[f]; if (typeof v !== "string" || !v) throw new Error(`${where}: '${f}' must be a non-empty string`); return v; };
  const nul = (f: RegistryField) => { const v = o[f]; if (v !== null && typeof v !== "string") throw new Error(`${where}: '${f}' must be string|null`); return v as string | null; };
  const num = (f: RegistryField) => { const v = o[f]; if (v !== null && typeof v !== "number") throw new Error(`${where}: '${f}' must be number|null`); return v as number | null; };
  const status = str("status");
  if (!STATUSES.has(status)) throw new Error(`${where}: invalid status '${status}'`);
  const created = str("created_at");
  if (Number.isNaN(Date.parse(created))) throw new Error(`${where}: created_at is not a date`);
  return {
    experiment_id: str("experiment_id"), parent_experiment: nul("parent_experiment"),
    hypothesis: str("hypothesis"), conceptual_change: str("conceptual_change"), split: str("split"),
    sample_size: num("sample_size"), trades: num("trades"), expectancy_r: num("expectancy_r"),
    profit_factor: num("profit_factor"), max_dd_r: num("max_dd_r"),
    status: status as ExperimentStatus, reason: nul("reason"), supersedes: nul("supersedes"),
    code_hash: nul("code_hash"), config_hash: nul("config_hash"), dataset_hash: nul("dataset_hash"),
    created_at: created, conclusion: str("conclusion"),
  };
}

export function parseJsonl(text: string): ExperimentRecord[] {
  return text.split("\n").filter((l) => l.trim())
    .map((l, i) => validateRecord(JSON.parse(l), `line ${i + 1}`));
}

export function toJsonl(records: readonly ExperimentRecord[]): string {
  return records.map((r) => JSON.stringify(validateRecord(r))).join("\n") + "\n";
}

/** RFC4180-safe CSV export generated FROM validated records. */
export function toCsv(records: readonly ExperimentRecord[]): string {
  const esc = (v: unknown) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [REGISTRY_FIELDS.join(",")];
  for (const r of records) {
    validateRecord(r);
    lines.push(REGISTRY_FIELDS.map((f) => esc((r as unknown as Record<string, unknown>)[f])).join(","));
  }
  return lines.join("\n") + "\n";
}
