# EXECUTION SEMANTICS AUDIT

Traced from source, not inferred from prior reports.

## 1. The intended entry model

| question | answer | evidence |
|---|---|---|
| what is `entry`? | a LIMIT price at the FVG edge | `proposer.ts:77` `const entry = g.top` (long, retest into the gap from above); `:89` `g.bottom` (short) |
| when does permission exist? | CLOSE of the confirmation bar | `evaluator.ts:159` `AWAITING_CONFIRMATION → TRIGGERED` when `allGatesSatisfied`; `:169` runs only on `EventType.BAR_CLOSED` |
| what does confirmation read? | the just-closed bar | `mechanical.ts:288` `const b = ctx.bar` |
| stop | protected swing ± ATR buffer, floored at `minStopAtrFraction` | `proposer.ts:78-80` |
| target | `entry ± rr * risk`, rr = 2 | `proposer.ts:84` |

## 2. The structural consequence (decisive)

Two gates jointly constrain where price is at confirmation:

- `noFirstTouchGate` (`mechanical.ts:242`) requires `priorTouches >= 1` — the POI
  must already have been touched on an earlier bar.
- `retestGate` (`mechanical.ts:266`) requires `b.low <= poi.top && b.high >= poi.bottom`
  — **the confirmation bar itself is inside the POI**.

So at the moment permission is granted, price is already at or through the FVG
edge. The intended limit is therefore frequently already marketable. Measured
empirically (not assumed): **29.2% of orders marketable at submission in
DEV-TRAIN, 20.3% in DEV-VALIDATION**; the remainder are genuinely passive
(the confirmation candle closed back out of the gap).

This is why the legacy trigger-bar fill looked plausible and was so damaging:
the limit is usually inside the confirmation bar's own range.

## 3. Four prices, now structurally distinct

`execution-sim.ts` keeps these as separate fields; a generic `entry` is banned.

| field | meaning |
|---|---|
| `decisionTime` / `decisionPrice` | close timestamp / close of the confirmation bar |
| `limitPrice` | God's Plan order level (FVG edge) — the strategy's intended entry |
| `fillPrice` | conservative simulated execution price |
| `stopPrice` | structural invalidation |

Also recorded: `cancelTime`, `cancelReason`, `barsToFill`,
`marketableAtSubmission`, `theoreticalPriceImprovement`, `riskPrice`.

## 4. Order lifecycle

```
SIGNAL_CONFIRMED -> ORDER_WORKING -> { FILLED | EXPIRED | INVALIDATED_BEFORE_FILL | CANCELLED }
FILLED -> POSITION_OPEN -> { STOPPED | TARGET | TIMEOUT | OPEN_AT_DATA_END }
```
No trade PnL exists before FILLED.

## 5. Conservative policies (documented, never silently favourable)

1. First eligible execution bar = `decisionIndex + 1`. Hard invariant.
2. `fillPrice = limitPrice` always. Gap-through improvement measured
   (`theoreticalPriceImprovement`) but never credited. 37 such fills in
   DEV-TRAIN, 14 in DEV-VALIDATION.
3. On the FILL bar, only adverse events resolve. A target touch on the fill bar
   is not granted (OHLC cannot show it post-dates the fill). Favourable
   excursion is likewise not credited on the fill bar; adverse excursion is.
4. Same-bar stop+target after fill → STOP.
5. R recomputed from the actual fill: `|fillPrice - stopPrice|`.

## 6. Expiry and pre-fill invalidation (from existing doctrine, not invented)

- `ORDER_MAX_BARS` = 24, matching the existing `maturityBars` window.
- `STOP_REACHED_BEFORE_FILL`: price reaches structural invalidation without ever
  offering the limit → the idea broke before we could be in it.

Observed: 0 pre-fill invalidations in either split (the limit sits between the
decision price and the stop by construction, so the stop is rarely reached
without touching the limit first).

## 7. 1-minute execution: NOT YET SAFE

Verified, two independent blockers:

1. **Price space** — the 1m file is raw unadjusted DBN. In the overlap window
   the offset against the 5m continuous series is exactly 0.00 (that window has
   `rollAdjustment = 0`, i.e. front contract). So the spaces agree *there* — but
   this cannot be generalised across rolls, where the 5m series carries a
   non-zero back-adjustment.
2. **The overlap is inside LOCKED TEST.** 1m span is 2026-07-06 → 2026-07-31;
   LOCKED_TEST begins 2026-01-23. Coverage is 3.6% of the research span and
   100% of it is off-limits.

Conclusion: conservative next-5M-bar execution is used for E000R. Using the
current 1m data would breach the locked test. Acquiring 1m data over the
DEV-TRAIN/DEV-VALIDATION window, back-adjusted with the identical roll schedule,
is the prerequisite.
