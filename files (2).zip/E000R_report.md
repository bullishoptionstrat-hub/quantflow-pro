# E000R — EXECUTION SEMANTICS REPAIR

Parent **E000 → INVALIDATED_METHODOLOGY** (ILLEGAL_TRIGGER_BAR_FILL_CONTAMINATION).
E000 preserved. LOCKED TEST untouched. No promotion claims.

Conceptual change: **an order cannot fill before it legally exists.** Every
strategy rule held constant (structure, liquidity, SMT, compression, EQ,
session, HTF, FVG definition, confirmation, one-attempt, stop/target
definitions, timeout, costs).

## E000 legacy defect

| split | legacy trades | illegal trigger-bar fills | contaminated |
|---|---|---|---|
| DEV-TRAIN | 123 | **12** | 9.8% |
| DEV-VALIDATION | 62 | **10** | 16.1% |

## E000R funnel

| | DEV-TRAIN | DEV-VALIDATION |
|---|---|---|
| proposals | 14,929 | 7,289 |
| confirmed setups (orders submitted) | 144 | 69 |
| marketable at submission | 42 (29.2%) | 14 (20.3%) |
| passive | 102 (70.8%) | 55 (79.7%) |
| **FILLED** | **132 (91.7%)** | **59 (85.5%)** |
| expired | 12 | 10 |
| invalidated before fill | 0 | 0 |
| stopped / target / timeout | 71 / 28 / 33 | 32 / 6 / 21 |
| bars to fill (median / p90) | 1 / 9 | 1 / 9 |

Fill rate by direction — TRAIN LONG 88.0%, SHORT 96.7%; VAL LONG 79.4%, SHORT 91.4%.
By RTH/ETH — TRAIN 92.3% / 91.4%; VAL 81.8% / 87.2%.
Marketable orders fill 100% of the time; passive 88.2% / 81.8%.
Median |decision − limit| distance: 2.00 / 2.50 pts.

## E000 → E000R delta

| metric | DEV-TRAIN | DEV-VALIDATION |
|---|---|---|
| trades | 123 → 132 | 62 → 59 |
| expectancy | −0.033 → **−0.137** | −0.107 → **−0.438** |
| profit factor | 0.94 → **0.78** | 0.81 → **0.36** |
| net R | −4.0 → −18.1 | −6.7 → −25.8 |
| max DD R | 12.7 → 19.6 | 11.7 → 25.8 |
| avg MFE | 1.46 → 1.01 | 1.23 → 0.83 |

Causal reasons for the change:
1. **12 / 10 legacy trades were fills that could not legally happen** — they used
   the confirmation bar's own range.
2. **The trade population changed, not just shrank.** TRAIN gains 9 net trades:
   some legacy no-fills do fill legally on a later bar, while illegal fills drop
   out. This is a different (correct) sample, not a subset.
3. **Favourable excursion collapses** (MFE 1.46 → 1.01). Under the legacy path,
   the confirmation bar's own favourable range was credited to the position.
   Removing it removes borrowed profit — the same defect class as E006.
4. Fill-bar target suppression converts some legacy instant winners into
   later stops or timeouts.

## Verdict

**EXECUTION_PIPELINE_REPAIRED — baseline is more negative under legal execution.**

Performance is not the goal here (directive §29); truthfulness is. The strategy
under causally-legal execution has expectancy −0.137R (TRAIN) and −0.438R
(VALIDATION), materially worse than the contaminated baseline reported before.

Regarding the FVG-limit question specifically: `FVG_LIMIT_SIGNAL_NOT_DEMONSTRATED`
at the intention-to-trade level. A dedicated conditional-on-fill study with a
fill-process-matched null (`FVG_LIMIT_FILL_INFORMATION`) has NOT yet been run —
that is a separate experiment and is not claimed here.

## Branch selection

Fill rate is 85–92%, so this is **not** Branch B (execution architecture is not
the binding constraint — the orders do get filled). The filled cohort is large
enough to study.

**NEXT: FILLED_ENTRY_REPLICATION_NEXT** — run `FVG_LIMIT_FILL_INFORMATION` on the
legally-filled cohort, observation beginning only after fill, against a null that
undergoes the *same* waiting-and-fill mechanism (synthetic limit at matched
ATR-distance from a matched decision price, same expiry and fill rules), reporting
both intention-to-trade and conditional-on-fill. Selection bias is the central
risk: a subsequent FVG retest is itself a market event, so an unconditional
random-timestamp null would mistake fill selection for strategy alpha.

The shadow/blocker engine follows after that, and will reuse this same execution
simulator — it must not pretend a blocked setup traded at the confirmation close.
